-- MySQL dump 10.13  Distrib 8.4.9, for Linux (x86_64)
--
-- Host: localhost    Database: cordys-crm-1.7.0
-- ------------------------------------------------------
-- Server version	8.4.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `cordys-crm-1.7.0`
--

/*!40000 DROP DATABASE IF EXISTS `cordys-crm-1.7.0`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `cordys-crm-1.7.0` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `cordys-crm-1.7.0`;

--
-- Table structure for table `QRTZ_BLOB_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_BLOB_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_BLOB_TRIGGERS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `BLOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `SCHED_NAME` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_blob_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_BLOB_TRIGGERS`
--

LOCK TABLES `QRTZ_BLOB_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_BLOB_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_BLOB_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_CALENDARS`
--

DROP TABLE IF EXISTS `QRTZ_CALENDARS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_CALENDARS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `CALENDAR_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `CALENDAR` blob NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`CALENDAR_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_CALENDARS`
--

LOCK TABLES `QRTZ_CALENDARS` WRITE;
/*!40000 ALTER TABLE `QRTZ_CALENDARS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_CALENDARS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_CRON_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_CRON_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_CRON_TRIGGERS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `CRON_EXPRESSION` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `TIME_ZONE_ID` varchar(80) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_cron_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_CRON_TRIGGERS`
--

LOCK TABLES `QRTZ_CRON_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_CRON_TRIGGERS` DISABLE KEYS */;
INSERT INTO `QRTZ_CRON_TRIGGERS` VALUES ('cordys-crm-quartz','dataEaseSyncService.syncDataEase','DEFAULT','0 0 0 * * ?','Asia/Shanghai'),('cordys-crm-quartz','noticeExpireJob.onEvent','DEFAULT','0 0 8 * * ?','Asia/Shanghai'),('cordys-crm-quartz','notifyOnJob.onEvent','DEFAULT','0 0/5 * * * ?','Asia/Shanghai'),('cordys-crm-quartz','serialNumGenerator.clean','DEFAULT','0 0 1 1,16 * ?','Asia/Shanghai'),('cordys-crm-quartz','sessionJob.cleanSession','DEFAULT','0 2 0 * * ?','Asia/Shanghai'),('cordys-crm-quartz','taskCleanupJob.execute','DEFAULT','0 0 3 * * ?','Asia/Shanghai');
/*!40000 ALTER TABLE `QRTZ_CRON_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_FIRED_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_FIRED_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_FIRED_TRIGGERS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `ENTRY_ID` varchar(95) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `INSTANCE_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `FIRED_TIME` bigint NOT NULL,
  `SCHED_TIME` bigint NOT NULL,
  `PRIORITY` int NOT NULL,
  `STATE` varchar(16) COLLATE utf8mb4_general_ci NOT NULL,
  `JOB_NAME` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `JOB_GROUP` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `IS_NONCONCURRENT` varchar(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `REQUESTS_RECOVERY` varchar(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`ENTRY_ID`),
  KEY `IDX_QRTZ_FT_TRIG_INST_NAME` (`SCHED_NAME`,`INSTANCE_NAME`),
  KEY `IDX_QRTZ_FT_INST_JOB_REQ_RCVRY` (`SCHED_NAME`,`INSTANCE_NAME`,`REQUESTS_RECOVERY`),
  KEY `IDX_QRTZ_FT_J_G` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_FT_JG` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_FT_T_G` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_FT_TG` (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_FIRED_TRIGGERS`
--

LOCK TABLES `QRTZ_FIRED_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_FIRED_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_FIRED_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_JOB_DETAILS`
--

DROP TABLE IF EXISTS `QRTZ_JOB_DETAILS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_JOB_DETAILS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `JOB_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `JOB_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `DESCRIPTION` varchar(250) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `JOB_CLASS_NAME` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  `IS_DURABLE` varchar(1) COLLATE utf8mb4_general_ci NOT NULL,
  `IS_NONCONCURRENT` varchar(1) COLLATE utf8mb4_general_ci NOT NULL,
  `IS_UPDATE_DATA` varchar(1) COLLATE utf8mb4_general_ci NOT NULL,
  `REQUESTS_RECOVERY` varchar(1) COLLATE utf8mb4_general_ci NOT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_J_REQ_RECOVERY` (`SCHED_NAME`,`REQUESTS_RECOVERY`),
  KEY `IDX_QRTZ_J_GRP` (`SCHED_NAME`,`JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_JOB_DETAILS`
--

LOCK TABLES `QRTZ_JOB_DETAILS` WRITE;
/*!40000 ALTER TABLE `QRTZ_JOB_DETAILS` DISABLE KEYS */;
INSERT INTO `QRTZ_JOB_DETAILS` VALUES ('cordys-crm-quartz','6da64b5bd2ee-28dc5b1d-f601-4331-a553-314fa9c23207','DEFAULT',NULL,'cn.cordys.quartz.config.ClusterQuartzJobBean','1','0','1','0',_binary '�\�\0sr\0org.quartz.JobDataMap���迩�\�\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�\�\��\�](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap\�.�(v\n\�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap\��\�`\�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0targetObjectt\0noticeExpireJobt\0targetMethodt\0onEventx\0'),('cordys-crm-quartz','6da64b5bd2ee-503b4566-c9c8-4acd-a964-cb48ae989118','DEFAULT',NULL,'cn.cordys.quartz.config.ClusterQuartzJobBean','1','0','1','0',_binary '�\�\0sr\0org.quartz.JobDataMap���迩�\�\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�\�\��\�](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap\�.�(v\n\�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap\��\�`\�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0targetObjectt\0taskCleanupJobt\0targetMethodt\0executex\0'),('cordys-crm-quartz','6da64b5bd2ee-82e53928-9444-49fa-9cbc-ecdbf1fcedbc','DEFAULT',NULL,'cn.cordys.quartz.config.ClusterQuartzJobBean','1','0','1','0',_binary '�\�\0sr\0org.quartz.JobDataMap���迩�\�\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�\�\��\�](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap\�.�(v\n\�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap\��\�`\�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0targetObjectt\0\nsessionJobt\0targetMethodt\0cleanSessionx\0'),('cordys-crm-quartz','6da64b5bd2ee-b15dda85-dcd7-447e-91fc-18804099198c','DEFAULT',NULL,'cn.cordys.quartz.config.ClusterQuartzJobBean','1','0','1','0',_binary '�\�\0sr\0org.quartz.JobDataMap���迩�\�\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�\�\��\�](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap\�.�(v\n\�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap\��\�`\�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0targetObjectt\0dataEaseSyncServicet\0targetMethodt\0syncDataEasex\0'),('cordys-crm-quartz','6da64b5bd2ee-b979239b-35ec-46b3-b726-1fd356dd4af2','DEFAULT',NULL,'cn.cordys.quartz.config.ClusterQuartzJobBean','1','0','1','0',_binary '�\�\0sr\0org.quartz.JobDataMap���迩�\�\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�\�\��\�](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap\�.�(v\n\�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap\��\�`\�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0targetObjectt\0serialNumGeneratort\0targetMethodt\0cleanx\0'),('cordys-crm-quartz','6da64b5bd2ee-fd9ef203-c7fa-42db-b573-5036e19e4e70','DEFAULT',NULL,'cn.cordys.quartz.config.ClusterQuartzJobBean','1','0','1','0',_binary '�\�\0sr\0org.quartz.JobDataMap���迩�\�\0\0xr\0&org.quartz.utils.StringKeyDirtyFlagMap�\�\��\�](\0Z\0allowsTransientDataxr\0org.quartz.utils.DirtyFlagMap\�.�(v\n\�\0Z\0dirtyL\0mapt\0Ljava/util/Map;xpsr\0java.util.HashMap\��\�`\�\0F\0\nloadFactorI\0	thresholdxp?@\0\0\0\0\0w\0\0\0\0\0\0t\0targetObjectt\0notifyOnJobt\0targetMethodt\0onEventx\0');
/*!40000 ALTER TABLE `QRTZ_JOB_DETAILS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_LOCKS`
--

DROP TABLE IF EXISTS `QRTZ_LOCKS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_LOCKS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `LOCK_NAME` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`LOCK_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_LOCKS`
--

LOCK TABLES `QRTZ_LOCKS` WRITE;
/*!40000 ALTER TABLE `QRTZ_LOCKS` DISABLE KEYS */;
INSERT INTO `QRTZ_LOCKS` VALUES ('cordys-crm-quartz','STATE_ACCESS'),('cordys-crm-quartz','TRIGGER_ACCESS');
/*!40000 ALTER TABLE `QRTZ_LOCKS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_PAUSED_TRIGGER_GRPS`
--

DROP TABLE IF EXISTS `QRTZ_PAUSED_TRIGGER_GRPS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_PAUSED_TRIGGER_GRPS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_PAUSED_TRIGGER_GRPS`
--

LOCK TABLES `QRTZ_PAUSED_TRIGGER_GRPS` WRITE;
/*!40000 ALTER TABLE `QRTZ_PAUSED_TRIGGER_GRPS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_PAUSED_TRIGGER_GRPS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_SCHEDULER_STATE`
--

DROP TABLE IF EXISTS `QRTZ_SCHEDULER_STATE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_SCHEDULER_STATE` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `INSTANCE_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `LAST_CHECKIN_TIME` bigint NOT NULL,
  `CHECKIN_INTERVAL` bigint NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`INSTANCE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_SCHEDULER_STATE`
--

LOCK TABLES `QRTZ_SCHEDULER_STATE` WRITE;
/*!40000 ALTER TABLE `QRTZ_SCHEDULER_STATE` DISABLE KEYS */;
INSERT INTO `QRTZ_SCHEDULER_STATE` VALUES ('cordys-crm-quartz','8bfa4e44a2e61780554924076',1780561390569,20000);
/*!40000 ALTER TABLE `QRTZ_SCHEDULER_STATE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_SIMPLE_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_SIMPLE_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_SIMPLE_TRIGGERS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `REPEAT_COUNT` bigint NOT NULL,
  `REPEAT_INTERVAL` bigint NOT NULL,
  `TIMES_TRIGGERED` bigint NOT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simple_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_SIMPLE_TRIGGERS`
--

LOCK TABLES `QRTZ_SIMPLE_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_SIMPLE_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_SIMPLE_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_SIMPROP_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_SIMPROP_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_SIMPROP_TRIGGERS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `STR_PROP_1` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `STR_PROP_2` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `STR_PROP_3` varchar(512) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `INT_PROP_1` int DEFAULT NULL,
  `INT_PROP_2` int DEFAULT NULL,
  `LONG_PROP_1` bigint DEFAULT NULL,
  `LONG_PROP_2` bigint DEFAULT NULL,
  `DEC_PROP_1` decimal(13,4) DEFAULT NULL,
  `DEC_PROP_2` decimal(13,4) DEFAULT NULL,
  `BOOL_PROP_1` varchar(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `BOOL_PROP_2` varchar(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  CONSTRAINT `qrtz_simprop_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`) REFERENCES `QRTZ_TRIGGERS` (`SCHED_NAME`, `TRIGGER_NAME`, `TRIGGER_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_SIMPROP_TRIGGERS`
--

LOCK TABLES `QRTZ_SIMPROP_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_SIMPROP_TRIGGERS` DISABLE KEYS */;
/*!40000 ALTER TABLE `QRTZ_SIMPROP_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `QRTZ_TRIGGERS`
--

DROP TABLE IF EXISTS `QRTZ_TRIGGERS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `QRTZ_TRIGGERS` (
  `SCHED_NAME` varchar(120) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `JOB_NAME` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `JOB_GROUP` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `DESCRIPTION` varchar(250) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `NEXT_FIRE_TIME` bigint DEFAULT NULL,
  `PREV_FIRE_TIME` bigint DEFAULT NULL,
  `PRIORITY` int DEFAULT NULL,
  `TRIGGER_STATE` varchar(16) COLLATE utf8mb4_general_ci NOT NULL,
  `TRIGGER_TYPE` varchar(8) COLLATE utf8mb4_general_ci NOT NULL,
  `START_TIME` bigint NOT NULL,
  `END_TIME` bigint DEFAULT NULL,
  `CALENDAR_NAME` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `MISFIRE_INSTR` smallint DEFAULT NULL,
  `JOB_DATA` blob,
  PRIMARY KEY (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_J` (`SCHED_NAME`,`JOB_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_T_JG` (`SCHED_NAME`,`JOB_GROUP`),
  KEY `IDX_QRTZ_T_C` (`SCHED_NAME`,`CALENDAR_NAME`),
  KEY `IDX_QRTZ_T_G` (`SCHED_NAME`,`TRIGGER_GROUP`),
  KEY `IDX_QRTZ_T_STATE` (`SCHED_NAME`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_N_STATE` (`SCHED_NAME`,`TRIGGER_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_N_G_STATE` (`SCHED_NAME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_NEXT_FIRE_TIME` (`SCHED_NAME`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_ST` (`SCHED_NAME`,`TRIGGER_STATE`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`),
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_STATE`),
  KEY `IDX_QRTZ_T_NFT_ST_MISFIRE_GRP` (`SCHED_NAME`,`MISFIRE_INSTR`,`NEXT_FIRE_TIME`,`TRIGGER_GROUP`,`TRIGGER_STATE`),
  CONSTRAINT `qrtz_triggers_ibfk_1` FOREIGN KEY (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`) REFERENCES `QRTZ_JOB_DETAILS` (`SCHED_NAME`, `JOB_NAME`, `JOB_GROUP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `QRTZ_TRIGGERS`
--

LOCK TABLES `QRTZ_TRIGGERS` WRITE;
/*!40000 ALTER TABLE `QRTZ_TRIGGERS` DISABLE KEYS */;
INSERT INTO `QRTZ_TRIGGERS` VALUES ('cordys-crm-quartz','dataEaseSyncService.syncDataEase','DEFAULT','6da64b5bd2ee-b15dda85-dcd7-447e-91fc-18804099198c','DEFAULT',NULL,1780588800000,-1,5,'WAITING','CRON',1780554924000,0,NULL,0,''),('cordys-crm-quartz','noticeExpireJob.onEvent','DEFAULT','6da64b5bd2ee-28dc5b1d-f601-4331-a553-314fa9c23207','DEFAULT',NULL,1780617600000,-1,5,'WAITING','CRON',1780554924000,0,NULL,0,''),('cordys-crm-quartz','notifyOnJob.onEvent','DEFAULT','6da64b5bd2ee-fd9ef203-c7fa-42db-b573-5036e19e4e70','DEFAULT',NULL,1780561500000,1780561200000,5,'WAITING','CRON',1780554924000,0,NULL,0,''),('cordys-crm-quartz','serialNumGenerator.clean','DEFAULT','6da64b5bd2ee-b979239b-35ec-46b3-b726-1fd356dd4af2','DEFAULT',NULL,1781542800000,-1,5,'WAITING','CRON',1780554924000,0,NULL,0,''),('cordys-crm-quartz','sessionJob.cleanSession','DEFAULT','6da64b5bd2ee-82e53928-9444-49fa-9cbc-ecdbf1fcedbc','DEFAULT',NULL,1780588920000,-1,5,'WAITING','CRON',1780554924000,0,NULL,0,''),('cordys-crm-quartz','taskCleanupJob.execute','DEFAULT','6da64b5bd2ee-503b4566-c9c8-4acd-a964-cb48ae989118','DEFAULT',NULL,1780599600000,-1,5,'WAITING','CRON',1780554924000,0,NULL,0,'');
/*!40000 ALTER TABLE `QRTZ_TRIGGERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent`
--

DROP TABLE IF EXISTS `agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `agent_module_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '文件id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `pos` bigint NOT NULL DEFAULT '0' COMMENT '同一节点下顺序',
  `scope_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '应用范围',
  `script` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '嵌入脚本',
  `description` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '描述',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `workspace_id` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '工作空间id',
  `application_id` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '智能体应用id',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_agent_module_id` (`agent_module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='智能体';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent`
--

LOCK TABLES `agent` WRITE;
/*!40000 ALTER TABLE `agent` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_collection`
--

DROP TABLE IF EXISTS `agent_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_collection` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户id',
  `agent_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '智能体id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='智能体收藏';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_collection`
--

LOCK TABLES `agent_collection` WRITE;
/*!40000 ALTER TABLE `agent_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agent_module`
--

DROP TABLE IF EXISTS `agent_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agent_module` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `parent_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NONE' COMMENT '父节点id',
  `pos` bigint NOT NULL DEFAULT '0' COMMENT '同一节点下顺序',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_name` (`name`),
  KEY `idx_pos` (`pos`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='智能体模块';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agent_module`
--

LOCK TABLES `agent_module` WRITE;
/*!40000 ALTER TABLE `agent_module` DISABLE KEYS */;
INSERT INTO `agent_module` VALUES ('101927171227910458','100001','默认文件夹','NONE',0,1780392058000,1780392058000,'admin','admin');
/*!40000 ALTER TABLE `agent_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_add_sign_task`
--

DROP TABLE IF EXISTS `approval_add_sign_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_add_sign_task` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键ID',
  `type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '加签方式;{before: 在我之前、after: 在我之后',
  `task_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '加签任务ID',
  `sign_task_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '被加签的任务ID',
  `root_task_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '根任务ID',
  `sort` bigint NOT NULL COMMENT '顺序;排序越小越往前',
  `comment` text COLLATE utf8mb4_general_ci COMMENT '加签意见',
  PRIMARY KEY (`id`),
  KEY `idx_task_id` (`task_id`),
  KEY `idx_sign_task_id` (`sign_task_id`),
  KEY `idx_root_task_id` (`root_task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='加签任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_add_sign_task`
--

LOCK TABLES `approval_add_sign_task` WRITE;
/*!40000 ALTER TABLE `approval_add_sign_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `approval_add_sign_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_flow`
--

DROP TABLE IF EXISTS `approval_flow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_flow` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `current_version_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '当前版本ID',
  `number` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '流程编码;流程编码，自增，格式：CTR-APV-001（合同），INV-APV-001（发票），ORD-APV-001（订单）',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '流程名称;流程名称',
  `form_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '表单类型;表单类型：QUOTATION(报价)、CONTRACT(合同)、INVOICE(发票)、ORDER(订单)',
  `create_execute` tinyint(1) NOT NULL DEFAULT '1' COMMENT '新建时执行;新建时是否执行审批流',
  `update_execute` tinyint(1) NOT NULL DEFAULT '1' COMMENT '编辑时执行;编辑时是否执行审批流',
  `submitter_can_revoke` tinyint(1) NOT NULL DEFAULT '1' COMMENT '允许提交人撤销;允许提交人撤销审批中的申请',
  `allow_batch_process` tinyint(1) NOT NULL DEFAULT '0' COMMENT '允许批量处理;允许审批人批量处理此流程的多个任务',
  `allow_withdraw` tinyint(1) NOT NULL DEFAULT '0' COMMENT '允许撤回;允许审批人撤回审批',
  `allow_add_sign` tinyint(1) NOT NULL DEFAULT '0' COMMENT '允许加签',
  `duplicate_approver_rule` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'FIRST_ONLY' COMMENT '重复审批人：FIRST_ONLY/SEQUENTIAL_ALL/EACH',
  `require_comment` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否必须填写审批意见',
  `enable` tinyint(1) NOT NULL DEFAULT '1' COMMENT '启用状态：0-禁用，1-启用',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除：0-未删除，1-已删除',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `status_permissions` varchar(4000) COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态权限配置（JSON格式）',
  `description` varchar(3000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '流程描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='审批流主表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_flow`
--

LOCK TABLES `approval_flow` WRITE;
/*!40000 ALTER TABLE `approval_flow` DISABLE KEYS */;
INSERT INTO `approval_flow` VALUES ('384847838728691712','384906001175814144','CTR-APV-00001','合同审批流程','contract',1,1,1,1,1,1,'FIRST_ONLY',1,1,0,1780462985778,1780469756703,'admin','admin','100001','[{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true}]','');
/*!40000 ALTER TABLE `approval_flow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_flow_version`
--

DROP TABLE IF EXISTS `approval_flow_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_flow_version` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `flow_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批流ID',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  PRIMARY KEY (`id`),
  KEY `idx_flow_id` (`flow_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='审批流版本表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_flow_version`
--

LOCK TABLES `approval_flow_version` WRITE;
/*!40000 ALTER TABLE `approval_flow_version` DISABLE KEYS */;
INSERT INTO `approval_flow_version` VALUES ('384847838728691713','384847838728691712',1780462985779,'admin','100001'),('384849814413647872','384847838728691712',1780463215244,'admin','100001'),('384850011982143488','384847838728691712',1780463238544,'admin','100001'),('384898596652195840','384847838728691712',1780468894349,'admin','100001'),('384899713343692800','384847838728691712',1780469024965,'admin','100001'),('384900185790095360','384847838728691712',1780469079923,'admin','100001'),('384906001175814144','384847838728691712',1780469756703,'admin','100001');
/*!40000 ALTER TABLE `approval_flow_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_instance`
--

DROP TABLE IF EXISTS `approval_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_instance` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `flow_version_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批流版本ID',
  `type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '表单类型',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批的业务数据ID',
  `submitter_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '提交人ID',
  `current_node_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '当前节点ID',
  `approval_status` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批状态',
  `submit_time` bigint DEFAULT NULL COMMENT '提审时间',
  `approval_time` bigint DEFAULT NULL COMMENT '审批完成时间',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_flow_version_id` (`flow_version_id`),
  KEY `idx_resource_id` (`resource_id`),
  KEY `idx_submitter_id` (`submitter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='审批实例表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_instance`
--

LOCK TABLES `approval_instance` WRITE;
/*!40000 ALTER TABLE `approval_instance` DISABLE KEYS */;
INSERT INTO `approval_instance` VALUES ('384898124205793282','384850011982143488','contract','384848921060450304','384244868270006280','384850011982143491','APPROVED',1780468839373,1780469907056,1780468839373,1780469907056,'384244868270006280','384244868270006274'),('384898931659644930','384898596652195840','contract','384832694674006016','384244868270006280','384898596652195843','APPROVED',1780468933602,1780469654085,1780468933602,1780469654085,'384244868270006280','384244868270006274');
/*!40000 ALTER TABLE `approval_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_instance_attachment`
--

DROP TABLE IF EXISTS `approval_instance_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_instance_attachment` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `instance_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批实例ID',
  `element_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批节点ID',
  `attachment_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '附件ID',
  PRIMARY KEY (`id`),
  KEY `idx_instance_id` (`instance_id`),
  KEY `idx_element_id` (`element_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='审批实例附件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_instance_attachment`
--

LOCK TABLES `approval_instance_attachment` WRITE;
/*!40000 ALTER TABLE `approval_instance_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `approval_instance_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_node`
--

DROP TABLE IF EXISTS `approval_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_node` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `flow_version_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批流版本ID',
  `number` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '节点编码;格式：PN001、PN002',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '节点名称',
  `node_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '节点类型：STARTCONDITIONDEFAULTEND',
  `sort` int NOT NULL DEFAULT '0' COMMENT '排序序号',
  PRIMARY KEY (`id`),
  KEY `idx_flow_version_id` (`flow_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='审批节点配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_node`
--

LOCK TABLES `approval_node` WRITE;
/*!40000 ALTER TABLE `approval_node` DISABLE KEYS */;
INSERT INTO `approval_node` VALUES ('384847838728691714','384847838728691713','PN001','开始','START',0),('384847838728691715','384847838728691713','PN002','审批人','APPROVER',1),('384847838728691716','384847838728691713','PN003','结束','END',2),('384849814413647873','384849814413647872','PN001','开始','START',0),('384849814413647874','384849814413647872','PN002','审批人','APPROVER',1),('384849814413647875','384849814413647872','PN003','结束','END',2),('384850011982143489','384850011982143488','PN001','开始','START',0),('384850011982143490','384850011982143488','PN002','审批人','APPROVER',1),('384850011982143491','384850011982143488','PN003','结束','END',2),('384898596652195841','384898596652195840','PN001','开始','START',0),('384898596652195842','384898596652195840','PN002','审批人','APPROVER',1),('384898596652195843','384898596652195840','PN003','结束','END',2),('384899713343692801','384899713343692800','PN001','开始','START',0),('384899713343692802','384899713343692800','PN002','审批人','APPROVER',1),('384899713343692803','384899713343692800','PN003','结束','END',2),('384900185790095361','384900185790095360','PN001','开始','START',0),('384900185790095362','384900185790095360','PN002','审批人','APPROVER',1),('384900185790095363','384900185790095360','PN003','结束','END',2),('384906001175814145','384906001175814144','PN001','开始','START',0),('384906001175814146','384906001175814144','PN002','审批人','APPROVER',1),('384906001175814147','384906001175814144','PN003','结束','END',2);
/*!40000 ALTER TABLE `approval_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_node_approver`
--

DROP TABLE IF EXISTS `approval_node_approver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_node_approver` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `flow_version_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批流版本ID;流程ID',
  `approval_type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'AUTO_PASS' COMMENT '审批类型;审批类型：MANUAL(人工审批)、AUTO_PASS(自动通过)、AUTO_REJECT(自动拒绝)',
  `multi_approver_mode` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '多人审批方式;多人审批方式：ALL(会签)/ANY(或签)/SEQUENTIAL(依次审批)',
  `empty_approver_action` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'AUTO_PASS' COMMENT '审批人为空时动作：AUTO_PASS(自动通过)/ASSIGN_SPECIFIC(指定人员审批)/ASSIGN_ADMIN(转交给审批管理员)',
  `fallback_approver` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审批人为空时，兜底审批人',
  `same_submitter_action` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'SKIP' COMMENT '审批人与提交人相同时动作：SKIP(自动跳过)/ALLOW(由提交人审批)/ASSIGN_SUPERIOR(转交给直属上级审批)',
  `approver_type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审批人类型',
  `approver_direction` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'BOTTOM_UP' COMMENT '审批人方向：BOTTOM_UP(从下往上)/TOP_DOWN(从上往下)，仅MULTIPLE_SUPERIOR/MULTIPLE_DEPT_HEAD生效',
  `cc_type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '抄送人类型',
  `cc_direction` varchar(20) COLLATE utf8mb4_general_ci DEFAULT 'BOTTOM_UP' COMMENT '抄送人方向：BOTTOM_UP(从下往上)/TOP_DOWN(从上往下)，仅MULTIPLE_SUPERIOR/MULTIPLE_DEPT_HEAD生效',
  `cc_list` text COLLATE utf8mb4_general_ci COMMENT '抄送人列表（JSON数组）',
  `approver_list` text COLLATE utf8mb4_general_ci COMMENT '审批人列表（JSON数组）',
  `pass_post_config` varchar(4000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审批通过后配置（JSON格式）',
  `reject_post_config` varchar(4000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审批驳回后配置（JSON格式）',
  `field_permissions` varchar(4000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '字段权限配置（JSON格式）',
  PRIMARY KEY (`id`),
  KEY `idx_flow_version_id` (`flow_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='审批人节点配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_node_approver`
--

LOCK TABLES `approval_node_approver` WRITE;
/*!40000 ALTER TABLE `approval_node_approver` DISABLE KEYS */;
INSERT INTO `approval_node_approver` VALUES ('384847838728691715','384847838728691713','MANUAL','ALL','AUTO_PASS','','SKIP','MULTIPLE_SUPERIOR','BOTTOM_UP',NULL,'BOTTOM_UP','[]','[\"1\"]','null','null','[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]'),('384849814413647874','384849814413647872','MANUAL','ALL','AUTO_PASS','','SKIP','ROLE','BOTTOM_UP',NULL,'BOTTOM_UP','[]','[\"org_admin\"]','null','null','[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]'),('384850011982143490','384850011982143488','MANUAL','ALL','AUTO_PASS','','SKIP','ROLE','BOTTOM_UP',NULL,'BOTTOM_UP','[]','[\"org_admin\"]','null','null','[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]'),('384898596652195842','384898596652195840','MANUAL','SEQUENTIAL','AUTO_PASS','','SKIP','ROLE','BOTTOM_UP',NULL,'BOTTOM_UP','[]','[\"org_admin\"]','null','null','[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]'),('384899713343692802','384899713343692800','MANUAL','ALL','AUTO_PASS','','SKIP','MULTIPLE_SUPERIOR','BOTTOM_UP',NULL,'BOTTOM_UP','[]','[\"2\"]','null','null','[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]'),('384900185790095362','384900185790095360','MANUAL','SEQUENTIAL','AUTO_PASS','','SKIP','MULTIPLE_SUPERIOR','BOTTOM_UP',NULL,'BOTTOM_UP','[]','[\"2\"]','null','null','[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]'),('384906001175814146','384906001175814144','MANUAL','ANY','AUTO_PASS','','SKIP','ROLE','BOTTOM_UP',NULL,'BOTTOM_UP','[]','[\"org_admin\"]','null','null','[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]');
/*!40000 ALTER TABLE `approval_node_approver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_node_condition`
--

DROP TABLE IF EXISTS `approval_node_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_node_condition` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `flow_version_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批流版本ID',
  `condition_config` varchar(4000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '条件配置JSON',
  PRIMARY KEY (`id`),
  KEY `idx_flow_version_id` (`flow_version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='条件节点配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_node_condition`
--

LOCK TABLES `approval_node_condition` WRITE;
/*!40000 ALTER TABLE `approval_node_condition` DISABLE KEYS */;
/*!40000 ALTER TABLE `approval_node_condition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_node_link`
--

DROP TABLE IF EXISTS `approval_node_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_node_link` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `flow_version_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批流版本ID',
  `from_node_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '源节点ID',
  `to_node_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '目标节点ID',
  `sort` int NOT NULL DEFAULT '0' COMMENT '分支评估顺序',
  PRIMARY KEY (`id`),
  KEY `idx_flow_version_id_from_id` (`flow_version_id`,`from_node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='节点连接表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_node_link`
--

LOCK TABLES `approval_node_link` WRITE;
/*!40000 ALTER TABLE `approval_node_link` DISABLE KEYS */;
INSERT INTO `approval_node_link` VALUES ('384847838728691717','384847838728691713','384847838728691714','384847838728691715',0),('384847838728691718','384847838728691713','384847838728691715','384847838728691716',1),('384849814413647876','384849814413647872','384849814413647873','384849814413647874',0),('384849814413647877','384849814413647872','384849814413647874','384849814413647875',1),('384850011982143492','384850011982143488','384850011982143489','384850011982143490',0),('384850011982143493','384850011982143488','384850011982143490','384850011982143491',1),('384898596652195844','384898596652195840','384898596652195841','384898596652195842',0),('384898596652195845','384898596652195840','384898596652195842','384898596652195843',1),('384899713343692804','384899713343692800','384899713343692801','384899713343692802',0),('384899713343692805','384899713343692800','384899713343692802','384899713343692803',1),('384900185790095364','384900185790095360','384900185790095361','384900185790095362',0),('384900185790095365','384900185790095360','384900185790095362','384900185790095363',1),('384906001175814148','384906001175814144','384906001175814145','384906001175814146',0),('384906001175814149','384906001175814144','384906001175814146','384906001175814147',1);
/*!40000 ALTER TABLE `approval_node_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_record`
--

DROP TABLE IF EXISTS `approval_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_record` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `instance_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批实例ID',
  `task_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '任务ID',
  `node_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '节点ID',
  `node_round` int NOT NULL COMMENT '节点轮次',
  `result` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审批结果',
  `comment` text COLLATE utf8mb4_general_ci COMMENT '审批意见',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_instance_task_id` (`instance_id`,`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='审批记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_record`
--

LOCK TABLES `approval_record` WRITE;
/*!40000 ALTER TABLE `approval_record` DISABLE KEYS */;
INSERT INTO `approval_record` VALUES ('384904927433990144','384898931659644930','384898931659644931','384898596652195842',1,NULL,'ok',1780469631443,1780469631443,'384244868270006272','384244868270006272'),('384905125002485760','384898931659644930','384904927433990145','384898596652195842',1,NULL,'ok',1780469654074,1780469654074,'384244868270006274','384244868270006274'),('384906490802085888','384898124205793282','384898124205793283','384850011982143490',1,NULL,'ok',1780469813789,1780469813789,'384244868270006272','384244868270006272'),('384907298255937536','384898124205793282','384898124205793284','384850011982143490',1,NULL,'11',1780469907051,1780469907051,'384244868270006274','384244868270006274');
/*!40000 ALTER TABLE `approval_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_return_back_record`
--

DROP TABLE IF EXISTS `approval_return_back_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_return_back_record` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键ID',
  `instance_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批实例ID',
  `task_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '当前任务ID',
  `return_to_node_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '退回至任务ID',
  `return_reason` text COLLATE utf8mb4_general_ci COMMENT '退回原因',
  `return_user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '退回操作人',
  PRIMARY KEY (`id`),
  KEY `idx_instance_id` (`instance_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='退回记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_return_back_record`
--

LOCK TABLES `approval_return_back_record` WRITE;
/*!40000 ALTER TABLE `approval_return_back_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `approval_return_back_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `approval_task`
--

DROP TABLE IF EXISTS `approval_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `approval_task` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `node_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '节点ID',
  `node_round` int NOT NULL COMMENT '节点轮次',
  `instance_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批实例ID',
  `approver_id` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批人ID',
  `status` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务状态; 待审批: PENDING, 审批中: APPROVING, 已通过: APPROVED, 已驳回: UNAPPROVED, 已撤销: REVOKED',
  `type` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '任务类型; 抄送: CC; 加签: SN; 退回: BK; 普通: NL;',
  `action` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '执行操作; 同意: APPROVE;驳回: REJECT;加签: SIGN;退回: BACK;',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_instance_node_id` (`instance_id`,`node_id`),
  KEY `idx_approver_id` (`approver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='审批任务表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `approval_task`
--

LOCK TABLES `approval_task` WRITE;
/*!40000 ALTER TABLE `approval_task` DISABLE KEYS */;
INSERT INTO `approval_task` VALUES ('384898124205793283','384850011982143490',1,'384898124205793282','384244868270006272','APPROVED','NL','APPROVE',1780468839424,1780469813788,'384244868270006280','384244868270006272'),('384898124205793284','384850011982143490',1,'384898124205793282','384244868270006274','APPROVED','NL','APPROVE',1780468839425,1780469907050,'384244868270006280','384244868270006274'),('384898931659644931','384898596652195842',1,'384898931659644930','384244868270006272','APPROVED','NL','APPROVE',1780468933613,1780469631440,'384244868270006280','384244868270006272'),('384904927433990145','384898596652195842',1,'384898931659644930','384244868270006274','APPROVED','NL','APPROVE',1780469631451,1780469654073,'384244868270006272','384244868270006274');
/*!40000 ALTER TABLE `approval_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_title`
--

DROP TABLE IF EXISTS `business_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_title` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公司名称',
  `type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '来源类型',
  `identification_number` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '纳税人识别号',
  `opening_bank` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '开户银行',
  `bank_account` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '银行账号',
  `registration_address` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '注册地址',
  `phone_number` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '注册电话',
  `registered_capital` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '注册资本',
  `company_size` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '公司规模',
  `registration_number` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '工商注册号',
  `approval_status` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审核状态',
  `unapproved_reason` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '不通过原因',
  `organization_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `province` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '省',
  `scale` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '企业规模',
  `industry` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '国标行业',
  `city` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '市',
  `remark` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='工商抬头';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_title`
--

LOCK TABLES `business_title` WRITE;
/*!40000 ALTER TABLE `business_title` DISABLE KEYS */;
/*!40000 ALTER TABLE `business_title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_title_config`
--

DROP TABLE IF EXISTS `business_title_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_title_config` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `field` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '字段',
  `required` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否必填',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='工商抬头配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_title_config`
--

LOCK TABLES `business_title_config` WRITE;
/*!40000 ALTER TABLE `business_title_config` DISABLE KEYS */;
INSERT INTO `business_title_config` VALUES ('101927171227910563','name',_binary '','100001'),('101927171227910564','identification_number',_binary '','100001'),('101927171227910565','opening_bank',_binary '\0','100001'),('101927171227910566','bank_account',_binary '\0','100001'),('101927171227910567','registration_address',_binary '\0','100001'),('101927171227910568','phone_number',_binary '\0','100001'),('101927171227910569','registered_capital',_binary '\0','100001'),('101927171227910570','company_size',_binary '\0','100001'),('101927171227910571','registration_number',_binary '\0','100001'),('101927171227910619','province',_binary '\0','100001'),('101927171227910620','scale',_binary '\0','100001'),('101927171227910621','industry',_binary '\0','100001'),('101927171227910636','city',_binary '\0','100001'),('101927171227910637','remark',_binary '\0','100001');
/*!40000 ALTER TABLE `business_title_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue`
--

DROP TABLE IF EXISTS `clue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户名称',
  `owner` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '负责人',
  `last_stage` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '上次修改前的线索状态',
  `stage` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT '线索状态',
  `collection_time` bigint DEFAULT NULL COMMENT '领取时间',
  `contact` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '联系人名称',
  `phone` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '联系人电话',
  `products` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '意向产品',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `transition_type` varchar(30) COLLATE utf8mb4_general_ci DEFAULT 'NONE' COMMENT '转移成客户或者商机',
  `transition_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '客户id或者商机id',
  `in_shared_pool` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否在线索池',
  `follower` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '最新跟进人',
  `follow_time` bigint DEFAULT NULL COMMENT '最新跟进时间',
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '线索池ID',
  `reason_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '线索池原因ID',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_pool_id` (`pool_id`),
  KEY `idx_follower` (`follower`),
  KEY `idx_follow_time` (`follow_time`),
  KEY `idx_reason_id` (`reason_id`),
  KEY `idx_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue`
--

LOCK TABLES `clue` WRITE;
/*!40000 ALTER TABLE `clue` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue_capacity`
--

DROP TABLE IF EXISTS `clue_capacity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue_capacity` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织架构ID',
  `scope_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '范围ID',
  `capacity` int DEFAULT NULL COMMENT '库容;NULL:不限制',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索池库容设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue_capacity`
--

LOCK TABLES `clue_capacity` WRITE;
/*!40000 ALTER TABLE `clue_capacity` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue_capacity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue_field`
--

DROP TABLE IF EXISTS `clue_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '线索id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id_field_id_field_value` (`resource_id`,`field_id`,`field_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue_field`
--

LOCK TABLES `clue_field` WRITE;
/*!40000 ALTER TABLE `clue_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue_field_blob`
--

DROP TABLE IF EXISTS `clue_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户联系人id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue_field_blob`
--

LOCK TABLES `clue_field_blob` WRITE;
/*!40000 ALTER TABLE `clue_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue_owner`
--

DROP TABLE IF EXISTS `clue_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue_owner` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `clue_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '线索id',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '责任人',
  `collection_time` bigint NOT NULL COMMENT '领取时间',
  `end_time` bigint NOT NULL COMMENT '结束时间',
  `operator` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作人',
  `reason_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '线索池原因ID',
  PRIMARY KEY (`id`),
  KEY `idx_clue_id` (`clue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索历史责任人';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue_owner`
--

LOCK TABLES `clue_owner` WRITE;
/*!40000 ALTER TABLE `clue_owner` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue_pool`
--

DROP TABLE IF EXISTS `clue_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue_pool` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '线索池名称',
  `scope_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '成员id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织架构id',
  `owner_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '管理员id',
  `enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '启用/禁用',
  `auto` bit(1) NOT NULL DEFAULT b'0' COMMENT '自动回收',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索池';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue_pool`
--

LOCK TABLES `clue_pool` WRITE;
/*!40000 ALTER TABLE `clue_pool` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue_pool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue_pool_hidden_field`
--

DROP TABLE IF EXISTS `clue_pool_hidden_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue_pool_hidden_field` (
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '线索池ID',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '字段ID',
  PRIMARY KEY (`pool_id`,`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索池隐藏字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue_pool_hidden_field`
--

LOCK TABLES `clue_pool_hidden_field` WRITE;
/*!40000 ALTER TABLE `clue_pool_hidden_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue_pool_hidden_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue_pool_pick_rule`
--

DROP TABLE IF EXISTS `clue_pool_pick_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue_pool_pick_rule` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '线索池ID',
  `limit_on_number` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否限制领取数量',
  `pick_number` int DEFAULT NULL COMMENT '领取数量',
  `limit_pre_owner` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否限制前归属人领取',
  `pick_interval_days` int DEFAULT NULL COMMENT '领取间隔天数',
  `limit_new` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否限制新数据',
  `new_pick_interval` int DEFAULT NULL COMMENT '新数据领取保护',
  `limit_daily_view` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否限制每日可看',
  `daily_view_count` int DEFAULT '0' COMMENT '每日可看数量上限',
  `limit_monthly_view` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否限制每月可看',
  `monthly_view_count` int DEFAULT '0' COMMENT '每月可看数量上限',
  `limit_monthly_pick` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否限制每月领取',
  `monthly_pick_count` int DEFAULT '0' COMMENT '每月领取数量上限',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_pool_id` (`pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索池领取规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue_pool_pick_rule`
--

LOCK TABLES `clue_pool_pick_rule` WRITE;
/*!40000 ALTER TABLE `clue_pool_pick_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue_pool_pick_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clue_pool_recycle_rule`
--

DROP TABLE IF EXISTS `clue_pool_recycle_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clue_pool_recycle_rule` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '线索池ID',
  `operator` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作符',
  `condition` text COLLATE utf8mb4_general_ci COMMENT '回收条件',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_pool_id` (`pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='线索池回收规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clue_pool_recycle_rule`
--

LOCK TABLES `clue_pool_recycle_rule` WRITE;
/*!40000 ALTER TABLE `clue_pool_recycle_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `clue_pool_recycle_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同名称',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户id',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同负责人',
  `amount` decimal(20,10) DEFAULT NULL COMMENT '金额',
  `number` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '编号',
  `approval_status` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审核状态',
  `stage` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同状态',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `void_reason` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '作废原因',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `start_time` bigint NOT NULL COMMENT '合同开始时间',
  `end_time` bigint NOT NULL COMMENT '合同结束时间',
  `pos` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_owner` (`owner`),
  KEY `idx_number` (`number`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_approval_status` (`approval_status`),
  KEY `idx_status` (`stage`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES ('384832694674006016','Yundy-Al-Futtaim Auto','384831827090612224','384244868270006280',0.0000000000,'Con-202606-000001','APPROVED','PENDING_SIGNING','100001',NULL,1780461222707,1780468933572,'384244868270006280','384244868270006280',1746201600000,1781712000000,1),('384848921060450304','Yundy-Zahid Tractor','384831079766302720','384244868270006280',0.0000000000,'Con-202606-000002','APPROVED','PENDING_SIGNING','100001',NULL,1780463111066,1780468839335,'384244868270006280','384244868270006280',1782316800000,1813852800000,2);
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_field`
--

DROP TABLE IF EXISTS `contract_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  `ref_sub_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '引用子表格ID;关联的子表格字段ID',
  `row_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子表格行实例ID;行实例数据ID',
  `biz_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '唯一业务行ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contract_field_cell` (`resource_id`,`ref_sub_id`,`row_id`,`field_id`),
  KEY `idx_resource_id` (`resource_id`),
  KEY `idx_ref_sub_id` (`ref_sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_field`
--

LOCK TABLES `contract_field` WRITE;
/*!40000 ALTER TABLE `contract_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_field_blob`
--

DROP TABLE IF EXISTS `contract_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  `ref_sub_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '引用子表格ID;关联的子表格字段ID',
  `row_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子表格行实例ID;行实例数据ID',
  `biz_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '唯一业务行ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contract_field_blob_cell` (`resource_id`,`ref_sub_id`,`row_id`,`field_id`),
  KEY `idx_resource_id` (`resource_id`),
  KEY `idx_ref_sub_id` (`ref_sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_field_blob`
--

LOCK TABLES `contract_field_blob` WRITE;
/*!40000 ALTER TABLE `contract_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_invoice`
--

DROP TABLE IF EXISTS `contract_invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_invoice` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '发票名称',
  `contract_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同id',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `amount` decimal(20,10) DEFAULT NULL COMMENT '开票金额',
  `invoice_type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '发票类型',
  `tax_rate` decimal(20,10) DEFAULT NULL COMMENT '税率',
  `approval_status` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审核状态',
  `business_title_id` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '工商抬头ID',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_contract_id` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='发票';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_invoice`
--

LOCK TABLES `contract_invoice` WRITE;
/*!40000 ALTER TABLE `contract_invoice` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_invoice_field`
--

DROP TABLE IF EXISTS `contract_invoice_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_invoice_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='发票自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_invoice_field`
--

LOCK TABLES `contract_invoice_field` WRITE;
/*!40000 ALTER TABLE `contract_invoice_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_invoice_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_invoice_field_blob`
--

DROP TABLE IF EXISTS `contract_invoice_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_invoice_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='发票自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_invoice_field_blob`
--

LOCK TABLES `contract_invoice_field_blob` WRITE;
/*!40000 ALTER TABLE `contract_invoice_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_invoice_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_invoice_snapshot`
--

DROP TABLE IF EXISTS `contract_invoice_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_invoice_snapshot` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `invoice_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同id',
  `invoice_prop` longtext COLLATE utf8mb4_general_ci COMMENT '表单属性快照',
  `invoice_value` text COLLATE utf8mb4_general_ci COMMENT '表单值快照',
  PRIMARY KEY (`id`),
  KEY `idx_invoice_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='发票快照';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_invoice_snapshot`
--

LOCK TABLES `contract_invoice_snapshot` WRITE;
/*!40000 ALTER TABLE `contract_invoice_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_invoice_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_payment_plan`
--

DROP TABLE IF EXISTS `contract_payment_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_payment_plan` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '回款计划名称',
  `contract_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同ID',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `plan_status` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '计划状态',
  `plan_amount` decimal(20,10) DEFAULT NULL COMMENT '计划回款金额',
  `plan_end_time` bigint DEFAULT NULL COMMENT '计划回款时间',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_contract_id` (`contract_id`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_owner` (`owner`),
  KEY `idx_plan_end_time` (`plan_end_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同回款计划';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_payment_plan`
--

LOCK TABLES `contract_payment_plan` WRITE;
/*!40000 ALTER TABLE `contract_payment_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_payment_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_payment_plan_field`
--

DROP TABLE IF EXISTS `contract_payment_plan_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_payment_plan_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '回款计划id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='回款计划自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_payment_plan_field`
--

LOCK TABLES `contract_payment_plan_field` WRITE;
/*!40000 ALTER TABLE `contract_payment_plan_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_payment_plan_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_payment_plan_field_blob`
--

DROP TABLE IF EXISTS `contract_payment_plan_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_payment_plan_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '回款计划id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='回款计划自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_payment_plan_field_blob`
--

LOCK TABLES `contract_payment_plan_field_blob` WRITE;
/*!40000 ALTER TABLE `contract_payment_plan_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_payment_plan_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_payment_record`
--

DROP TABLE IF EXISTS `contract_payment_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_payment_record` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '回款记录名称',
  `no` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回款编号',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `contract_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同ID',
  `payment_plan_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回款计划ID',
  `record_amount` decimal(20,10) DEFAULT NULL COMMENT '回款金额',
  `record_end_time` bigint DEFAULT NULL COMMENT '回款时间',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_contract_id` (`contract_id`),
  KEY `idx_plan_id` (`payment_plan_id`),
  KEY `idx_owner` (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同回款记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_payment_record`
--

LOCK TABLES `contract_payment_record` WRITE;
/*!40000 ALTER TABLE `contract_payment_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_payment_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_payment_record_field`
--

DROP TABLE IF EXISTS `contract_payment_record_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_payment_record_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '回款记录id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同回款记录自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_payment_record_field`
--

LOCK TABLES `contract_payment_record_field` WRITE;
/*!40000 ALTER TABLE `contract_payment_record_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_payment_record_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_payment_record_field_blob`
--

DROP TABLE IF EXISTS `contract_payment_record_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_payment_record_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '回款记录id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同回款记录自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_payment_record_field_blob`
--

LOCK TABLES `contract_payment_record_field_blob` WRITE;
/*!40000 ALTER TABLE `contract_payment_record_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_payment_record_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_snapshot`
--

DROP TABLE IF EXISTS `contract_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_snapshot` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `contract_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同id',
  `contract_prop` longtext COLLATE utf8mb4_general_ci COMMENT '表单属性快照',
  `contract_value` text COLLATE utf8mb4_general_ci COMMENT '表单值快照',
  PRIMARY KEY (`id`),
  KEY `idx_contract_id` (`contract_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同快照';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_snapshot`
--

LOCK TABLES `contract_snapshot` WRITE;
/*!40000 ALTER TABLE `contract_snapshot` DISABLE KEYS */;
INSERT INTO `contract_snapshot` VALUES ('384898124205793280','384848921060450304','eJzdmFtPGzkUgP/KyvsaKkK4BN4gBClaQlAu3QeEkDPjKFY943RsF1iE1D6sQOxWsOpS+lBEL6pYrbaXBwRa6Kp/hkngX6w9k7kkMAQopQASUub4jO1zvuNzjmcBVDAiOgNDUwsA62AIJJK9PYlkf+9gvG8g0R8f6O4HMWBCA8kxe2u//vKfwy+v608+Sik2ObJMSH5C83JQoya3oMZHIMNaxqxQqVGjcuZ4DPD5mnp/NHM/M5rOywGDljGRIm4JFAOsSmfHYRkRT1AjUENVSnRkgSFTEBIDOmKahWscU9MTWQjqsBxMg3TM3Wd33DHtZ6zzqtzEvW75giBImTrtLplSO6Yk70rdd8qCYRMx5tjUXBkzNas+adEaC9ZmVFgaGlNrZHRPzES5qJTbxDp+hKUtKQKZnMF77OoyqWVAAgIFSqi0GPyI9Ep3JS4HOOYE+eJET6Iv0QcWY1GwBkKw1pbttd8jMU0orSahHp9QZmKyVPz2fNznSD4L4IGzVws9FNhCumOwKxImfigQWDwvQtcbJyBOBZvzjW2uf89fdfrCmFEFCsLvQyLQabKi62RNME4NuV5F4hcEuqrRUJMhqB/e1Jf37LWnje1PkWhTzvwSTRNvIjiAw8XhmUKulE+lbyDkczPVmgZKz1+OrHwLclhw0DpQLo669f0hkCoVirmsk9w0apTlbgsIWlrVn0daNtbMtZ7nKq0Cgs0HrRKtiok+fkJMMOOjmElA8+GB6AgabE8Ljc/P7dW96OTgJ+9eP3YK6XxmeHxmopQduXAKB/WNV8cvH9v/rdu/vov9cLT0t73yV+PPrfryGrhgVFUgYWeF1fkTgzDKzhk5GUBfmQYYsjAkE878zQ1MAbkhuVaX/J+Xf9ls86FfTV+ToYDnLpcd4t3tbOsr7w4P9jpUaWmsLjTOPM59AefSyMxkPjdaSn3/QnDthVpiQLost8IwncZFqo11aJDi8QDA4f62/exJJ6d7PneXvFOp+eo6pvb8GoTkjUuv8Z72CLCfrssj2CkOhg0qzNOjwenDLpdr72Y4nNJZGdg3zYBz3k83rY+pxpq3ZHmkYdlrTypXMd9xlpQyx0c9rknFKhUMmjoroBq0IFd9t9KNhp8I4NfXPx0vrXbCPuFt6YZjv/2QXeUQ5O5oyGef8N4A8vHSH8dvNjtBLgjjjOM9lstnS+PD3x7xVXVLV1dgw01NhyOnNicMtxo7PdQpWKajmfUFzI52to523h7u70diy82awZns90Fl0zfiKH7FXYk2DftuF+AqZClhWcjkJYYsz1RsYi6b5JzjHycSo0AmEyc+atifH9vbv9U3do83diKJFji0eBEHXzkGwr1WeqaYyd7mTguwkH3XAxdyrxlTP91LNBp1kbsDUVEQzTbZzrZx8Ky+udWBbdrUw2STd4ss8q27tVx7Q7fSxs7How+vO5TNIuWQtFbMwZtXLq/ywyT0jL0WyBesu0pd7QcMLYBHGM0W8C8KBJPNlfpcLW9GVHDnhkyU/ycVL8ClvuJbE7zpvOBjBq3xEW66ehWC5rosOuuLlbNkfXAczNGcaukOv2za719IDWQGqJS3W8btf3cbB9uNg/f1vQN75VVI3SEZ0rdXn9d3l9vnm3Zvha6lTkAv/g/k4tPc','{\"id\":\"384848921060450304\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780463111066,\"updateTime\":1780468839335,\"name\":\"Yundy-Zahid Tractor\",\"customerId\":\"384831079766302720\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000002\",\"approvalStatus\":\"APPROVED\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1782316800000,\"endTime\":1813852800000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":null,\"customerName\":\"Zahid Tractor & Heavy Machinery Co.Ltd\",\"ownerName\":\"Yundy\",\"createUserName\":\"Yundy\",\"updateUserName\":\"Yundy\",\"inCustomerPool\":null,\"poolId\":null,\"departmentId\":\"384244722241118208\",\"departmentName\":\"Kevin组\",\"alreadyPayAmount\":0,\"moduleFields\":[],\"stageName\":null,\"firstApproved\":null,\"optionMap\":{\"owner\":[{\"id\":\"384244868270006280\",\"name\":\"Yundy\"}],\"customerId\":[{\"id\":\"384831079766302720\",\"name\":\"Zahid Tractor & Heavy Machinery Co.Ltd\"}]},\"attachmentMap\":null,\"products\":null}'),('384898931659644928','384832694674006016','eJzdmFtPGzkUgP/KyvsaKkK4BN4gBClaQlAu3QeEkDPjKFY943RsF1iE1D6sQOxWsOpS+lBEL6pYrbaXBwRa6Kp/hkngX6w9k7kkMAQopQASUub4jO1zvuNzjmcBVDAiOgNDUwsA62AIJJK9PYlkf+9gvG8g0R8f6O4HMWBCA8kxe2u//vKfwy+v608+Sik2ObJMSH5C83JQoya3oMZHIMNaxqxQqVGjcuZ4DPD5mnp/NHM/M5rOywGDljGRIm4JFAOsSmfHYRkRT1AjUENVSnRkgSFTEBIDOmKahWscU9MTWQjqsBxMg3TM3Wd33DHtZ6zzqtzEvW75giBImTrtLplSO6Yk70rdd8qCYRMx5tjUXBkzNas+adEaC9ZmVFgaGlNrZHRPzES5qJTbxDp+hKUtKQKZnMF77OoyqWVAAgIFSqi0GPyI9Ep3JS4HOOYE+eJET6Iv0QcWY1GwBkKw1pbttd8jMU0orSahHp9QZmKyVPz2fNznSD4L4IGzVws9FNhCumOwKxImfigQWDwvQtcbJyBOBZvzjW2uf89fdfrCmFEFCsLvQyLQabKi62RNME4NuV5F4hcEuqrRUJMhqB/e1Jf37LWnje1PkWhTzvwSTRNvIjiAw8XhmUKulE+lbyDkczPVmgZKz1+OrHwLclhw0DpQLo669f0hkCoVirmsk9w0apTlbgsIWlrVn0daNtbMtZ7nKq0Cgs0HrRKtiok+fkJMMOOjmElA8+GB6AgabE8Ljc/P7dW96OTgJ+9eP3YK6XxmeHxmopQduXAKB/WNV8cvH9v/rdu/vov9cLT0t73yV+PPrfryGrhgVFUgYWeF1fkTgzDKzhk5GUBfmQYYsjAkE878zQ1MAbkhuVaX/J+Xf9ls86FfTV+ToYDnLpcd4t3tbOsr7w4P9jpUaWmsLjTOPM59AefSyMxkPjdaSn3/QnDthVpiQLost8IwncZFqo11aJDi8QDA4f62/exJJ6d7PneXvFOp+eo6pvb8GoTkjUuv8Z72CLCfrssj2CkOhg0qzNOjwenDLpdr72Y4nNJZGdg3zYBz3k83rY+pxpq3ZHmkYdlrTypXMd9xlpQyx0c9rknFKhUMmjoroBq0IFd9t9KNhp8I4NfXPx0vrXbCPuFt6YZjv/2QXeUQ5O5oyGef8N4A8vHSH8dvNjtBLgjjjOM9lstnS+PD3x7xVXVLV1dgw01NhyOnNicMtxo7PdQpWKajmfUFzI52to523h7u70diy82awZns90Fl0zfiKH7FXYk2DftuF+AqZClhWcjkJYYsz1RsYi6b5JzjHycSo0AmEyc+atifH9vbv9U3do83diKJFji0eBEHXzkGwr1WeqaYyd7mTguwkH3XAxdyrxlTP91LNBp1kbsDUVEQzTbZzrZx8Ky+udWBbdrUw2STd4ss8q27tVx7Q7fSxs7How+vO5TNIuWQtFbMwZtXLq/ywyT0jL0WyBesu0pd7QcMLYBHGM0W8C8KBJPNlfpcLW9GVHDnhkyU/ycVL8ClvuJbE7zpvOBjBq3xEW66ehWC5rosOuuLlbNkfXAczNGcaukOv2za719IDWQGqJS3W8btf3cbB9uNg/f1vQN75VVI3SEZ0rdXn9d3l9vnm3Zvha6lTkAv/g/k4tPc','{\"id\":\"384832694674006016\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461222707,\"updateTime\":1780468933572,\"name\":\"Yundy-Al-Futtaim Auto\",\"customerId\":\"384831827090612224\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000001\",\"approvalStatus\":\"APPROVED\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1746201600000,\"endTime\":1781712000000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":null,\"customerName\":\"Al-Futtaim Auto & Machinery Co.(FAMCO)\",\"ownerName\":\"Yundy\",\"createUserName\":\"Yundy\",\"updateUserName\":\"Yundy\",\"inCustomerPool\":null,\"poolId\":null,\"departmentId\":\"384244722241118208\",\"departmentName\":\"Kevin组\",\"alreadyPayAmount\":0,\"moduleFields\":[],\"stageName\":null,\"firstApproved\":null,\"optionMap\":{\"owner\":[{\"id\":\"384244868270006280\",\"name\":\"Yundy\"}],\"customerId\":[{\"id\":\"384831827090612224\",\"name\":\"Al-Futtaim Auto & Machinery Co.(FAMCO)\"}]},\"attachmentMap\":null,\"products\":null}');
/*!40000 ALTER TABLE `contract_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_stage_config`
--

DROP TABLE IF EXISTS `contract_stage_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_stage_config` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '合同状态',
  `type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态类型',
  `afoot_roll_back` bit(1) DEFAULT b'0' COMMENT '进行中回退设置',
  `end_roll_back` bit(1) DEFAULT b'0' COMMENT '完结回退设置',
  `pos` bigint NOT NULL COMMENT '顺序',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='合同状态流设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_stage_config`
--

LOCK TABLES `contract_stage_config` WRITE;
/*!40000 ALTER TABLE `contract_stage_config` DISABLE KEYS */;
INSERT INTO `contract_stage_config` VALUES ('ARCHIVED','合同完结','END',_binary '',_binary '\0',6,'100001',1776417799080,1776417799080,'admin','admin'),('CHANGE','合同变更','AFOOT',_binary '',_binary '\0',3,'100001',1776417799080,1776417799080,'admin','admin'),('COMPLETED_PERFORMANCE','履行完毕','AFOOT',_binary '',_binary '\0',5,'100001',1776417799080,1776417799080,'admin','admin'),('IN_PROGRESS','履行中','AFOOT',_binary '',_binary '\0',4,'100001',1776417799080,1776417799080,'admin','admin'),('PENDING_SIGNING','待签署','AFOOT',_binary '',_binary '\0',1,'100001',1776417799080,1776417799080,'admin','admin'),('SIGNED','已签署','AFOOT',_binary '',_binary '\0',2,'100001',1776417799080,1776417799080,'admin','admin'),('VOID','作废','END',_binary '',_binary '\0',7,'100001',1776417799080,1776417799080,'admin','admin');
/*!40000 ALTER TABLE `contract_stage_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cordys_crm_version`
--

DROP TABLE IF EXISTS `cordys_crm_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cordys_crm_version` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `cordys_crm_version_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cordys_crm_version`
--

LOCK TABLES `cordys_crm_version` WRITE;
/*!40000 ALTER TABLE `cordys_crm_version` DISABLE KEYS */;
INSERT INTO `cordys_crm_version` VALUES (1,'1.0.0.1','init','SQL','1.0.0/ddl/V1.0.0_1__init.sql',2140813912,'root','2026-06-02 09:20:55',3,1),(2,'1.0.0.2','system setting','SQL','1.0.0/ddl/V1.0.0_2__system_setting.sql',-134986003,'root','2026-06-02 09:20:56',1026,1),(3,'1.0.0.2.1','data','SQL','1.0.0/dml/V1.0.0_2_1__data.sql',-730198893,'root','2026-06-02 09:20:56',15,1),(4,'1.0.0.2.2','permission','SQL','1.0.0/dml/V1.0.0_2_2__permission.sql',1107565868,'root','2026-06-02 09:20:56',13,1),(5,'1.0.0.3','qrtz schema','SQL','1.0.0/ddl/V1.0.0_3__qrtz_schema.sql',-869970543,'root','2026-06-02 09:20:56',137,1),(6,'1.0.0.4','customer','SQL','1.0.0/ddl/V1.0.0_4__customer.sql',757928059,'root','2026-06-02 09:20:56',255,1),(7,'1.0.0.5','clue','SQL','1.0.0/ddl/V1.0.0_5__clue.sql',1969835222,'root','2026-06-02 09:20:56',181,1),(8,'1.0.0.6','opportunity','SQL','1.0.0/ddl/V1.0.0_6__opportunity.sql',-61156692,'root','2026-06-02 09:20:57',328,1),(9,'1.0.1.1','init','SQL','1.0.1/ddl/V1.0.1_1__init.sql',2140813912,'root','2026-06-02 09:20:57',3,1),(10,'1.0.1.2','ga ddl','SQL','1.0.1/ddl/V1.0.1_2__ga_ddl.sql',1226630495,'root','2026-06-02 09:20:57',89,1),(11,'1.0.1.2.1','data','SQL','1.0.1/dml/V1.0.1_2_1__data.sql',-630042700,'root','2026-06-02 09:20:57',1,1),(12,'1.0.1.2.2','permission','SQL','1.0.1/dml/V1.0.1_2_2__permission.sql',-38618081,'root','2026-06-02 09:20:57',1,1),(13,'1.0.2.1','init','SQL','1.0.2/ddl/V1.0.2_1__init.sql',2140813912,'root','2026-06-02 09:20:57',0,1),(14,'1.0.2.2','ga ddl','SQL','1.0.2/ddl/V1.0.2_2__ga_ddl.sql',938644336,'root','2026-06-02 09:20:57',0,1),(15,'1.0.2.2.1','data','SQL','1.0.2/dml/V1.0.2_2_1__data.sql',-630042700,'root','2026-06-02 09:20:57',0,1),(16,'1.0.2.2.2','permission','SQL','1.0.2/dml/V1.0.2_2_2__permission.sql',-630042700,'root','2026-06-02 09:20:57',0,1),(17,'1.0.3.1','init','SQL','1.0.3/ddl/V1.0.3_1__init.sql',2140813912,'root','2026-06-02 09:20:57',1,1),(18,'1.0.3.2','ga ddl','SQL','1.0.3/ddl/V1.0.3_2__ga_ddl.sql',-1075737143,'root','2026-06-02 09:20:57',18,1),(19,'1.0.3.2.1','data','SQL','1.0.3/dml/V1.0.3_2_1__data.sql',382577016,'root','2026-06-02 09:20:57',2,1),(20,'1.0.3.2.2','permission','SQL','1.0.3/dml/V1.0.3_2_2__permission.sql',-630042700,'root','2026-06-02 09:20:57',0,1),(21,'1.0.4.1','init','SQL','1.0.4/ddl/V1.0.4_1__init.sql',2140813912,'root','2026-06-02 09:20:57',1,1),(22,'1.0.4.2','ga ddl','SQL','1.0.4/ddl/V1.0.4_2__ga_ddl.sql',1277345392,'root','2026-06-02 09:20:57',65,1),(23,'1.1.0.1','init','SQL','1.1.0/ddl/V1.1.0_1__init.sql',2140813912,'root','2026-06-02 09:20:57',0,1),(24,'1.1.0.2','ga ddl','SQL','1.1.0/ddl/V1.1.0_2__ga_ddl.sql',-1583665627,'root','2026-06-02 09:20:57',138,1),(25,'1.1.0.2.1','data','SQL','1.1.0/dml/V1.1.0_2_1__data.sql',-820780230,'root','2026-06-02 09:20:57',1,1),(26,'1.1.0.2.2','permission','SQL','1.1.0/dml/V1.1.0_2_2__permission.sql',1646607373,'root','2026-06-02 09:20:57',1,1),(27,'1.1.1.1','init','SQL','1.1.1/ddl/V1.1.1_1__init.sql',2140813912,'root','2026-06-02 09:20:57',0,1),(28,'1.1.1.2','ga ddl','SQL','1.1.1/ddl/V1.1.1_2__ga_ddl.sql',618750105,'root','2026-06-02 09:20:57',204,1),(29,'1.1.1.2.1','data','SQL','1.1.1/dml/V1.1.1_2_1__data.sql',-1915035057,'root','2026-06-02 09:20:57',1,1),(30,'1.1.1.2.2','permission','SQL','1.1.1/dml/V1.1.1_2_2__permission.sql',-630042700,'root','2026-06-02 09:20:57',0,1),(31,'1.1.2.1','init','SQL','1.1.2/ddl/V1.1.2_1__init.sql',2140813912,'root','2026-06-02 09:20:57',1,1),(32,'1.1.2.1.1','permission','SQL','1.1.2/dml/V1.1.2_1_1__permission.sql',1347765258,'root','2026-06-02 09:20:57',0,1),(33,'1.1.3.1','init','SQL','1.1.3/ddl/V1.1.3_1__init.sql',2140813912,'root','2026-06-02 09:20:57',0,1),(34,'1.1.3.1.1','permission','SQL','1.1.3/dml/V1.1.3_1_1__permission.sql',-1276777996,'root','2026-06-02 09:20:57',1,1),(35,'1.1.3.2','ga ddl','SQL','1.1.3/ddl/V1.1.3_2__ga_ddl.sql',597287215,'root','2026-06-02 09:20:58',39,1),(36,'1.1.4.1','init','SQL','1.1.4/ddl/V1.1.4_1__init.sql',2140813912,'root','2026-06-02 09:20:58',1,1),(37,'1.1.4.1.1','permission','SQL','1.1.4/dml/V1.1.4_1_1__permission.sql',-630042700,'root','2026-06-02 09:20:58',1,1),(38,'1.1.4.2','ga ddl','SQL','1.1.4/ddl/V1.1.4_2__ga_ddl.sql',-2048559354,'root','2026-06-02 09:20:58',22,1),(39,'1.1.5.1','init','SQL','1.1.5/ddl/V1.1.5_1__init.sql',2140813912,'root','2026-06-02 09:20:58',0,1),(40,'1.1.5.1.1','permission','SQL','1.1.5/dml/V1.1.5_1_1__permission.sql',-630042700,'root','2026-06-02 09:20:58',0,1),(41,'1.1.5.2','ga ddl','SQL','1.1.5/ddl/V1.1.5_2__ga_ddl.sql',823580672,'root','2026-06-02 09:20:58',88,1),(42,'1.1.5.2.1','data','SQL','1.1.5/dml/V1.1.5_2_1__data.sql',9614074,'root','2026-06-02 09:20:58',1,1),(43,'1.1.8.1','init','SQL','1.1.8/ddl/V1.1.8_1__init.sql',2140813912,'root','2026-06-02 09:20:58',2,1),(44,'1.1.8.1.1','permission','SQL','1.1.8/dml/V1.1.8_1_1__permission.sql',1254166966,'root','2026-06-02 09:20:58',1,1),(45,'1.1.9.1','init','SQL','1.1.9/ddl/V1.1.9_1__init.sql',2140813912,'root','2026-06-02 09:20:58',2,1),(46,'1.1.9.1.1','permission','SQL','1.1.9/dml/V1.1.9_1_1__permission.sql',-599404011,'root','2026-06-02 09:20:58',2,1),(47,'1.1.9.2','ga ddl','SQL','1.1.9/ddl/V1.1.9_2__ga_ddl.sql',144035972,'root','2026-06-02 09:20:58',19,1),(48,'1.2.0.1','init','SQL','1.2.0/ddl/V1.2.0_1__init.sql',2140813912,'root','2026-06-02 09:20:58',2,1),(49,'1.2.0.2','ga ddl','SQL','1.2.0/ddl/V1.2.0_2__ga_ddl.sql',694072828,'root','2026-06-02 09:20:58',120,1),(50,'1.2.0.2.1','data','SQL','1.2.0/dml/V1.2.0_2_1__data.sql',-1030528241,'root','2026-06-02 09:20:58',2,1),(51,'1.2.0.2.2','permission','SQL','1.2.0/dml/V1.2.0_2_2__permission.sql',-1690247800,'root','2026-06-02 09:20:58',2,1),(52,'1.2.1.1','init','SQL','1.2.1/ddl/V1.2.1_1__init.sql',2140813912,'root','2026-06-02 09:20:58',2,1),(53,'1.2.1.2','ga ddl','SQL','1.2.1/ddl/V1.2.1_2__ga_ddl.sql',-1733308835,'root','2026-06-02 09:20:58',53,1),(54,'1.2.1.2.1','data','SQL','1.2.1/dml/V1.2.1_2_1__data.sql',1146113151,'root','2026-06-02 09:20:58',3,1),(55,'1.2.1.2.2','permission','SQL','1.2.1/dml/V1.2.1_2_2__permission.sql',-1793979143,'root','2026-06-02 09:20:58',1,1),(56,'1.2.1.2.3','modify tel','SQL','1.2.1/dml/V1.2.1_2_3__modify_tel.sql',50379962,'root','2026-06-02 09:20:58',2,1),(57,'1.2.2.1','init','SQL','1.2.2/ddl/V1.2.2_1__init.sql',2140813912,'root','2026-06-02 09:20:58',0,1),(58,'1.2.2.2','ga ddl','SQL','1.2.2/ddl/V1.2.2_2__ga_ddl.sql',-1915510694,'root','2026-06-02 09:20:58',21,1),(59,'1.2.2.2.1','data','SQL','1.2.2/dml/V1.2.2_2_1__data.sql',-630042700,'root','2026-06-02 09:20:58',0,1),(60,'1.2.2.2.2','permission','SQL','1.2.2/dml/V1.2.2_2_2__permission.sql',-630042700,'root','2026-06-02 09:20:58',0,1),(61,'1.2.2.2.3','modify tel','SQL','1.2.2/dml/V1.2.2_2_3__modify_tel.sql',554857625,'root','2026-06-02 09:20:58',0,1),(62,'1.2.3.1','init','SQL','1.2.3/ddl/V1.2.3_1__init.sql',2140813912,'root','2026-06-02 09:20:58',0,1),(63,'1.2.3.2','ga ddl','SQL','1.2.3/ddl/V1.2.3_2__ga_ddl.sql',2131852670,'root','2026-06-02 09:20:58',54,1),(64,'1.2.3.2.1','data','SQL','1.2.3/dml/V1.2.3_2_1__data.sql',748063098,'root','2026-06-02 09:20:58',2,1),(65,'1.2.3.2.2','permission','SQL','1.2.3/dml/V1.2.3_2_2__permission.sql',-630042700,'root','2026-06-02 09:20:58',0,1),(66,'1.2.3.2.3','modify tel','SQL','1.2.3/dml/V1.2.3_2_3__modify_tel.sql',122017178,'root','2026-06-02 09:20:58',0,1),(67,'1.3.0.1','init','SQL','1.3.0/ddl/V1.3.0_1__init.sql',2140813912,'root','2026-06-02 09:20:58',0,1),(68,'1.3.0.2','ga ddl','SQL','1.3.0/ddl/V1.3.0_2__ga_ddl.sql',-100615800,'root','2026-06-02 09:20:58',24,1),(69,'1.3.0.2.1','data','SQL','1.3.0/dml/V1.3.0_2_1__data.sql',1522989871,'root','2026-06-02 09:20:58',58,1),(70,'1.3.0.2.2','permission','SQL','1.3.0/dml/V1.3.0_2_2__permission.sql',-2036725308,'root','2026-06-02 09:20:58',2,1),(71,'1.3.0.2.3','modify tel','SQL','1.3.0/dml/V1.3.0_2_3__modify_tel.sql',479400907,'root','2026-06-02 09:20:58',4,1),(72,'1.3.2.1','init','SQL','1.3.2/ddl/V1.3.2_1__init.sql',2140813912,'root','2026-06-02 09:20:58',2,1),(73,'1.3.5.1','init','SQL','1.3.5/ddl/V1.3.5_1__init.sql',2140813912,'root','2026-06-02 09:20:58',1,1),(74,'1.3.5.2.1','data','SQL','1.3.5/dml/V1.3.5_2_1__data.sql',-630042700,'root','2026-06-02 09:20:58',0,1),(75,'1.3.5.2.2','permission','SQL','1.3.5/dml/V1.3.5_2_2__permission.sql',-963188,'root','2026-06-02 09:20:58',1,1),(76,'1.3.6.1','init','SQL','1.3.6/ddl/V1.3.6_1__init.sql',2140813912,'root','2026-06-02 09:20:58',0,1),(77,'1.3.6.2','ga ddl','SQL','1.3.6/ddl/V1.3.6_2__ga_ddl.sql',-535479993,'root','2026-06-02 09:20:58',19,1),(78,'1.3.6.2.1','data','SQL','1.3.6/dml/V1.3.6_2_1__data.sql',-630042700,'root','2026-06-02 09:20:58',0,1),(79,'1.4.0.1','init','SQL','1.4.0/ddl/V1.4.0_1__init.sql',2140813912,'root','2026-06-02 09:20:58',1,1),(80,'1.4.0.2','ga ddl','SQL','1.4.0/ddl/V1.4.0_2__ga_ddl.sql',2010846129,'root','2026-06-02 09:20:59',382,1),(81,'1.4.0.2.1','data','SQL','1.4.0/dml/V1.4.0_2_1__data.sql',641558196,'root','2026-06-02 09:20:59',1,1),(82,'1.4.0.2.2','permission','SQL','1.4.0/dml/V1.4.0_2_2__permission.sql',243263584,'root','2026-06-02 09:20:59',5,1),(83,'1.4.0.2.3','modify tel','SQL','1.4.0/dml/V1.4.0_2_3__modify_tel.sql',-765798086,'root','2026-06-02 09:20:59',1,1),(84,'1.4.0.2.4','modify log','SQL','1.4.0/dml/V1.4.0_2_4__modify_log.sql',-1608084143,'root','2026-06-02 09:20:59',1,1),(85,'1.4.1.1','init','SQL','1.4.1/ddl/V1.4.1_1__init.sql',2140813912,'root','2026-06-02 09:20:59',2,1),(86,'1.4.1.2','ga ddl','SQL','1.4.1/ddl/V1.4.1_2__ga_ddl.sql',-66321816,'root','2026-06-02 09:20:59',86,1),(87,'1.4.1.2.1','data','SQL','1.4.1/dml/V1.4.1_2_1__data.sql',-630042700,'root','2026-06-02 09:20:59',1,1),(88,'1.4.1.2.2','modify tel','SQL','1.4.1/dml/V1.4.1_2_2__modify_tel.sql',-355965402,'root','2026-06-02 09:20:59',1,1),(89,'1.4.2.1','init','SQL','1.4.2/ddl/V1.4.2_1__init.sql',2140813912,'root','2026-06-02 09:20:59',0,1),(90,'1.4.2.2','ga ddl','SQL','1.4.2/ddl/V1.4.2_2__ga_ddl.sql',400708788,'root','2026-06-02 09:20:59',181,1),(91,'1.4.2.2.1','data','SQL','1.4.2/dml/V1.4.2_2_1__data.sql',1265076884,'root','2026-06-02 09:20:59',3,1),(92,'1.5.0.1','init','SQL','1.5.0/ddl/V1.5.0_1__init.sql',2140813912,'root','2026-06-02 09:20:59',0,1),(93,'1.5.0.2','ga ddl','SQL','1.5.0/ddl/V1.5.0_2__ga_ddl.sql',-722718415,'root','2026-06-02 09:20:59',203,1),(94,'1.5.0.2.1','data','SQL','1.5.0/dml/V1.5.0_2_1__data.sql',234039216,'root','2026-06-02 09:20:59',7,1),(95,'1.5.0.2.2','modify tel','SQL','1.5.0/dml/V1.5.0_2_2__modify_tel.sql',1739070801,'root','2026-06-02 09:21:00',112,1),(96,'1.5.0.2.3','permission','SQL','1.5.0/dml/V1.5.0_2_3__permission.sql',-1622605058,'root','2026-06-02 09:21:00',7,1),(97,'1.5.0.3','modify sub key','SQL','1.5.0/ddl/V1.5.0_3__modify_sub_key.sql',1933395588,'root','2026-06-02 09:21:00',43,1),(98,'1.5.1.1','init','SQL','1.5.1/ddl/V1.5.1_1__init.sql',2140813912,'root','2026-06-02 09:21:00',1,1),(99,'1.5.1.2','ga ddl','SQL','1.5.1/ddl/V1.5.1_2__ga_ddl.sql',938644336,'root','2026-06-02 09:21:00',1,1),(100,'1.5.1.2.1','data','SQL','1.5.1/dml/V1.5.1_2_1__data.sql',315678626,'root','2026-06-02 09:21:00',1,1),(101,'1.5.1.3','modify','SQL','1.5.1/ddl/V1.5.1_3__modify.sql',1121878854,'root','2026-06-02 09:21:00',77,1),(102,'1.5.1.4','record del','SQL','1.5.1/ddl/V1.5.1_4__record_del.sql',1026612194,'root','2026-06-02 09:21:00',57,1),(103,'1.5.2.1','init','SQL','1.5.2/ddl/V1.5.2_1__init.sql',2140813912,'root','2026-06-02 09:21:00',2,1),(104,'1.5.2.2','ga ddl','SQL','1.5.2/ddl/V1.5.2_2__ga_ddl.sql',-1755547699,'root','2026-06-02 09:21:00',94,1),(105,'1.5.2.2.1','data','SQL','1.5.2/dml/V1.5.2_2_1__data.sql',38001925,'root','2026-06-02 09:21:00',2,1),(106,'1.6.0.1','init','SQL','1.6.0/ddl/V1.6.0_1__init.sql',2140813912,'root','2026-06-02 09:21:00',1,1),(107,'1.6.0.2','ga ddl','SQL','1.6.0/ddl/V1.6.0_2__ga_ddl.sql',1449210954,'root','2026-06-02 09:21:00',128,1),(108,'1.6.0.2.1','data','SQL','1.6.0/dml/V1.6.0_2_1__data.sql',753453164,'root','2026-06-02 09:21:00',2,1),(109,'1.6.0.2.2','permission','SQL','1.6.0/dml/V1.6.0_2_2__permission.sql',-1734597599,'root','2026-06-02 09:21:00',3,1),(110,'1.6.1.1','init','SQL','1.6.1/ddl/V1.6.1_1__init.sql',2140813912,'root','2026-06-02 09:21:00',1,1),(111,'1.6.1.2','ga ddl','SQL','1.6.1/ddl/V1.6.1_2__ga_ddl.sql',-1503795354,'root','2026-06-02 09:21:00',60,1),(112,'1.6.1.2.1','data','SQL','1.6.1/dml/V1.6.1_2_1__data.sql',690457517,'root','2026-06-02 09:21:00',2,1),(113,'1.6.2.1','init','SQL','1.6.2/ddl/V1.6.2_1__init.sql',2140813912,'root','2026-06-02 09:21:00',1,1),(114,'1.6.2.2','ga ddl','SQL','1.6.2/ddl/V1.6.2_2__ga_ddl.sql',-291991987,'root','2026-06-02 09:21:00',17,1),(115,'1.6.2.2.1','data','SQL','1.6.2/dml/V1.6.2_2_1__data.sql',-1363268928,'root','2026-06-02 09:21:00',1,1),(116,'1.7.0.1','init','SQL','1.7.0/ddl/V1.7.0_1__init.sql',2140813912,'root','2026-06-02 09:21:00',0,1),(117,'1.7.0.2','ga ddl','SQL','1.7.0/ddl/V1.7.0_2__ga_ddl.sql',-320693342,'root','2026-06-02 09:21:01',395,1),(118,'1.7.0.2.1','data','SQL','1.7.0/dml/V1.7.0_2_1__data.sql',-1097518628,'root','2026-06-02 09:21:01',1,1),(119,'1.7.0.2.2','permission','SQL','1.7.0/dml/V1.7.0_2_2__permission.sql',-1708208183,'root','2026-06-02 09:21:01',0,1),(120,'1.7.0.2.3','modify tel','SQL','1.7.0/dml/V1.7.0_2_3__modify_tel.sql',-1012876473,'root','2026-06-02 09:21:01',0,1),(121,'1.7.0.2.4','approval status','SQL','1.7.0/dml/V1.7.0_2_4__approval_status.sql',1228763485,'root','2026-06-02 09:21:01',1,1),(122,'1.7.0.3','pool rule enhance','SQL','1.7.0/ddl/V1.7.0_3__pool_rule_enhance.sql',-1903662123,'root','2026-06-02 09:21:01',115,1),(123,'1.7.0.4','pool monthly limit','SQL','1.7.0/ddl/V1.7.0_4__pool_monthly_limit.sql',-124344314,'root','2026-06-02 09:21:01',111,1),(124,'1.7.0.5','clue pool monthly limit','SQL','1.7.0/ddl/V1.7.0_5__clue_pool_monthly_limit.sql',-760699194,'root','2026-06-02 09:21:01',91,1),(125,'1.7.0.6','pool view allocation','SQL','1.7.0/ddl/V1.7.0_6__pool_view_allocation.sql',1323745047,'root','2026-06-02 09:21:01',15,1),(126,'1.7.0.7','welltrans push log','SQL','1.7.0/ddl/V1.7.0_7__welltrans_push_log.sql',-709600111,'root','2026-06-04 05:05:39',31,1);
/*!40000 ALTER TABLE `cordys_crm_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户名称',
  `owner` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '负责人',
  `collection_time` bigint DEFAULT NULL COMMENT '领取时间',
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '公海ID',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `in_shared_pool` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否在公海池',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `follower` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '最新跟进人',
  `follow_time` bigint DEFAULT NULL COMMENT '最新跟进时间',
  `reason_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '公海原因ID',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_pool_id` (`pool_id`),
  KEY `idx_follower` (`follower`),
  KEY `idx_follow_time` (`follow_time`),
  KEY `idx_reason_id` (`reason_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('384831079766302720','Zahid Tractor & Heavy Machinery Co.Ltd','384244868270006280',1780461034997,NULL,1780461034997,1780461034997,'384244868270006280','384244868270006280',_binary '\0','100001',NULL,NULL,NULL),('384831827090612224','Al-Futtaim Auto & Machinery Co.(FAMCO)',NULL,NULL,'384245160327782400',1780461121958,1780513200066,'384244868270006280','admin',_binary '','100001',NULL,NULL,'system'),('385629866373996544','Tuwaiq & Han','384244868270006278',1780554025768,NULL,1780554025768,1780554025768,'384244868270006278','384244868270006278',_binary '\0','100001',NULL,NULL,NULL),('385630338820399104','PORTMNT','384244868270006278',1780554080620,NULL,1780554080620,1780554080620,'384244868270006278','384244868270006278',_binary '\0','100001',NULL,NULL,NULL);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_capacity`
--

DROP TABLE IF EXISTS `customer_capacity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_capacity` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织架构ID',
  `scope_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '范围ID',
  `capacity` int DEFAULT NULL COMMENT '库容;NULL:不限制',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `filter` text COLLATE utf8mb4_general_ci COMMENT '过滤条件',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户容量设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_capacity`
--

LOCK TABLES `customer_capacity` WRITE;
/*!40000 ALTER TABLE `customer_capacity` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_capacity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_collaboration`
--

DROP TABLE IF EXISTS `customer_collaboration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_collaboration` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '协作人id',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户id',
  `collaboration_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '协作类型(只读/协作)',
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户协作人';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_collaboration`
--

LOCK TABLES `customer_collaboration` WRITE;
/*!40000 ALTER TABLE `customer_collaboration` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_collaboration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_contact`
--

DROP TABLE IF EXISTS `customer_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '客户id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '联系人姓名',
  `phone` varchar(30) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '联系人电话',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '责任人',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否停用',
  `disable_reason` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '停用原因',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_phone` (`phone`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户联系人';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_contact`
--

LOCK TABLES `customer_contact` WRITE;
/*!40000 ALTER TABLE `customer_contact` DISABLE KEYS */;
INSERT INTO `customer_contact` VALUES ('384831337464340480','384831079766302720','Customer','1111','384244868270006280',1780461064788,1780461064788,'384244868270006280','384244868270006280',_binary '',NULL,'100001'),('384832093378584576','384831827090612224','Customer','+9665155','-',1780461152871,1780461152871,'384244868270006280','384244868270006280',_binary '',NULL,'100001'),('385630055352557568','385629866373996544','Fahad Alaqil (CEO)','+966564673363','384244868270006278',1780554047855,1780554047855,'384244868270006278','384244868270006278',_binary '',NULL,'100001'),('385630459079483392','385630338820399104','Procurement Team','+966547178046','384244868270006278',1780554094942,1780554094942,'384244868270006278','384244868270006278',_binary '',NULL,'100001'),('385630828446670848','385630338820399104','Procurement Team 1','+966547178045','384244868270006278',1780554137808,1780554137808,'384244868270006278','384244868270006278',_binary '',NULL,'100001');
/*!40000 ALTER TABLE `customer_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_contact_field`
--

DROP TABLE IF EXISTS `customer_contact_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id_field_id_field_value` (`resource_id`,`field_id`,`field_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户联系人自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_contact_field`
--

LOCK TABLES `customer_contact_field` WRITE;
/*!40000 ALTER TABLE `customer_contact_field` DISABLE KEYS */;
INSERT INTO `customer_contact_field` VALUES ('384831337464340481','384831337464340480','384238649157361757','info@zahidtractor.com'),('384832093378584577','384832093378584576','384238649157361757','sa.machinery@alfuttaim.com'),('385630055352557569','385630055352557568','384238649157361757','info@tuwaiqwahan.com'),('385630459079483393','385630459079483392','384238649157361757','info@portmnt.com'),('385630828446670849','385630828446670848','384238649157361757','sales@portmnt.com');
/*!40000 ALTER TABLE `customer_contact_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_contact_field_blob`
--

DROP TABLE IF EXISTS `customer_contact_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_contact_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户联系人自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_contact_field_blob`
--

LOCK TABLES `customer_contact_field_blob` WRITE;
/*!40000 ALTER TABLE `customer_contact_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_contact_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_field`
--

DROP TABLE IF EXISTS `customer_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id_field_id_field_value` (`resource_id`,`field_id`,`field_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_field`
--

LOCK TABLES `customer_field` WRITE;
/*!40000 ALTER TABLE `customer_field` DISABLE KEYS */;
INSERT INTO `customer_field` VALUES ('384831088356237312','384831079766302720','384238649157361809','3'),('384831088356237313','384831079766302720','384238649157361810','1'),('384831088356237314','384831079766302720','384238649157361811','2'),('384831088356237315','384831079766302720','384238649157361812','1'),('384831088356237316','384831079766302720','384238649157361813','2'),('384831827090612225','384831827090612224','384238649157361809','3'),('384831827090612226','384831827090612224','384238649157361810','1'),('384831827090612227','384831827090612224','384238649157361811','2'),('384831827090612228','384831827090612224','384238649157361812','1'),('384831827090612229','384831827090612224','384238649157361813','2'),('384831827090612230','384831827090612224','384238649157361816','KSA-'),('385629866373996545','385629866373996544','384238649157361809','3'),('385629866373996546','385629866373996544','384238649157361810','1'),('385629866373996547','385629866373996544','384238649157361811','2'),('385629866373996548','385629866373996544','384238649157361812','1'),('385629866373996549','385629866373996544','384238649157361813','2'),('385629866373996550','385629866373996544','384238649157361816','KSA-'),('385630338820399105','385630338820399104','384238649157361809','3'),('385630338820399106','385630338820399104','384238649157361810','1'),('385630338820399107','385630338820399104','384238649157361811','2'),('385630338820399108','385630338820399104','384238649157361812','1'),('385630338820399109','385630338820399104','384238649157361813','2'),('385630338820399110','385630338820399104','384238649157361816','KSA-');
/*!40000 ALTER TABLE `customer_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_field_blob`
--

DROP TABLE IF EXISTS `customer_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_field_blob`
--

LOCK TABLES `customer_field_blob` WRITE;
/*!40000 ALTER TABLE `customer_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_owner`
--

DROP TABLE IF EXISTS `customer_owner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_owner` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户id',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '责任人',
  `collection_time` bigint NOT NULL COMMENT '领取时间',
  `end_time` bigint NOT NULL COMMENT '结束时间',
  `operator` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作人',
  `reason_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '公海原因ID',
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户历史责任人';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_owner`
--

LOCK TABLES `customer_owner` WRITE;
/*!40000 ALTER TABLE `customer_owner` DISABLE KEYS */;
INSERT INTO `customer_owner` VALUES ('385279182294228992','384831827090612224','384244868270006280',1780461121958,1780513200059,'admin',NULL);
/*!40000 ALTER TABLE `customer_owner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_pool`
--

DROP TABLE IF EXISTS `customer_pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_pool` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `scope_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '范围ID',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织ID',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公海池名称',
  `owner_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '管理员ID',
  `enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '启用/禁用',
  `auto` bit(1) NOT NULL DEFAULT b'0' COMMENT '自动回收',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='公海池';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_pool`
--

LOCK TABLES `customer_pool` WRITE;
/*!40000 ALTER TABLE `customer_pool` DISABLE KEYS */;
INSERT INTO `customer_pool` VALUES ('384245160327782400','[\"101927171227910394\"]','100001','柏盛通国外公海','[\"384244601982033920\"]',_binary '',_binary '',1780392824160,1780400322902,'admin','admin');
/*!40000 ALTER TABLE `customer_pool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_pool_daily_view_record`
--

DROP TABLE IF EXISTS `customer_pool_daily_view_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_pool_daily_view_record` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公海池ID',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户ID',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户ID',
  `view_time` bigint NOT NULL COMMENT '查看时间',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  PRIMARY KEY (`id`),
  KEY `idx_pool_user_view_time` (`pool_id`,`user_id`,`view_time`),
  KEY `idx_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='公海每日查看记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_pool_daily_view_record`
--

LOCK TABLES `customer_pool_daily_view_record` WRITE;
/*!40000 ALTER TABLE `customer_pool_daily_view_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_pool_daily_view_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_pool_hidden_field`
--

DROP TABLE IF EXISTS `customer_pool_hidden_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_pool_hidden_field` (
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公海池ID',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '字段ID',
  PRIMARY KEY (`pool_id`,`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='公海池隐藏字段';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_pool_hidden_field`
--

LOCK TABLES `customer_pool_hidden_field` WRITE;
/*!40000 ALTER TABLE `customer_pool_hidden_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_pool_hidden_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_pool_pick_rule`
--

DROP TABLE IF EXISTS `customer_pool_pick_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_pool_pick_rule` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公海池ID',
  `limit_on_number` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否限制领取数量',
  `pick_number` int DEFAULT NULL COMMENT '领取数量',
  `limit_pre_owner` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否限制前归属人领取',
  `pick_interval_days` int DEFAULT NULL COMMENT '领取间隔天数',
  `limit_new` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否限制新数据',
  `new_pick_interval` int DEFAULT NULL COMMENT '新数据领取保护',
  `limit_daily_view` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否限制每日可看',
  `daily_view_count` int DEFAULT '0' COMMENT '每日可看数量上限',
  `limit_monthly_view` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否限制每月可看',
  `monthly_view_count` int DEFAULT '0' COMMENT '每月可看数量上限',
  `limit_monthly_pick` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否限制每月领取',
  `monthly_pick_count` int DEFAULT '0' COMMENT '每月领取数量上限',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_pool_id` (`pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='公海池领取规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_pool_pick_rule`
--

LOCK TABLES `customer_pool_pick_rule` WRITE;
/*!40000 ALTER TABLE `customer_pool_pick_rule` DISABLE KEYS */;
INSERT INTO `customer_pool_pick_rule` VALUES ('384245160327782401','384245160327782400',_binary '',1,_binary '',30,_binary '',7,_binary '\0',0,_binary '',10,_binary '',2,'admin',1780392824162,'admin',1780400322903);
/*!40000 ALTER TABLE `customer_pool_pick_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_pool_recycle_rule`
--

DROP TABLE IF EXISTS `customer_pool_recycle_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_pool_recycle_rule` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公海池ID',
  `operator` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作符',
  `condition` text COLLATE utf8mb4_general_ci COMMENT '回收条件',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_pool_id` (`pool_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='公海池回收规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_pool_recycle_rule`
--

LOCK TABLES `customer_pool_recycle_rule` WRITE;
/*!40000 ALTER TABLE `customer_pool_recycle_rule` DISABLE KEYS */;
INSERT INTO `customer_pool_recycle_rule` VALUES ('384245160327782402','384245160327782400','AND','[{\"column\":\"storageTime\",\"operator\":\"DYNAMICS\",\"value\":\"WEEK\",\"scope\":[\"Created\",\"Picked\"]},{\"column\":\"contractStartTime\",\"operator\":\"DYNAMICS\",\"value\":\"360,180\",\"scope\":[]}]',1780392824163,1780400322904,'admin','admin');
/*!40000 ALTER TABLE `customer_pool_recycle_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_pool_view_allocation`
--

DROP TABLE IF EXISTS `customer_pool_view_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_pool_view_allocation` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `pool_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公海池ID',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户ID',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户ID',
  `period_type` varchar(16) COLLATE utf8mb4_general_ci NOT NULL COMMENT '周期类型: DAILY / MONTHLY',
  `period_key` varchar(8) COLLATE utf8mb4_general_ci NOT NULL COMMENT '周期key: yyyyMMdd / yyyyMM',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  PRIMARY KEY (`id`),
  KEY `idx_pool_user_period` (`pool_id`,`user_id`,`period_type`,`period_key`),
  KEY `idx_customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_pool_view_allocation`
--

LOCK TABLES `customer_pool_view_allocation` WRITE;
/*!40000 ALTER TABLE `customer_pool_view_allocation` DISABLE KEYS */;
INSERT INTO `customer_pool_view_allocation` VALUES ('385628552114003968','384245160327782400','384244868270006280','384831827090612224','MONTHLY','202606',1780553872232,1780553872232,'384244868270006280','384244868270006280','100001');
/*!40000 ALTER TABLE `customer_pool_view_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_relation`
--

DROP TABLE IF EXISTS `customer_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_relation` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `source_customer_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户ID(集团)',
  `target_customer_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '客户ID(子公司)',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户关系';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_relation`
--

LOCK TABLES `customer_relation` WRITE;
/*!40000 ALTER TABLE `customer_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard`
--

DROP TABLE IF EXISTS `dashboard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `resource_url` varchar(500) COLLATE utf8mb4_general_ci NOT NULL COMMENT '仪表板url',
  `dashboard_module_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '模块id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `pos` bigint NOT NULL DEFAULT '0' COMMENT '同一节点下顺序',
  `scope_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '范围',
  `description` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '描述',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`),
  KEY `idx_dashboard_module_id` (`dashboard_module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='仪表板';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard`
--

LOCK TABLES `dashboard` WRITE;
/*!40000 ALTER TABLE `dashboard` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_collection`
--

DROP TABLE IF EXISTS `dashboard_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_collection` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户id',
  `dashboard_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '仪表板id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='仪表板收藏';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_collection`
--

LOCK TABLES `dashboard_collection` WRITE;
/*!40000 ALTER TABLE `dashboard_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_module`
--

DROP TABLE IF EXISTS `dashboard_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_module` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `parent_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NONE' COMMENT '父节点id',
  `pos` bigint NOT NULL DEFAULT '0' COMMENT '同一节点下顺序',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_name` (`name`),
  KEY `idx_pos` (`pos`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='仪表板模块';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_module`
--

LOCK TABLES `dashboard_module` WRITE;
/*!40000 ALTER TABLE `dashboard_module` DISABLE KEYS */;
INSERT INTO `dashboard_module` VALUES ('101927171227910425','100001','默认文件夹','NONE',0,1780392057000,1780392057000,'admin','admin');
/*!40000 ALTER TABLE `dashboard_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export_task`
--

DROP TABLE IF EXISTS `export_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export_task` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `file_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '文件名',
  `resource_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '资源类型',
  `file_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '文件id',
  `status` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_status` (`status`),
  KEY `idx_resource_type` (`resource_type`),
  KEY `idx_create_time` (`create_time`),
  KEY `idx_create_user` (`create_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='导出任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export_task`
--

LOCK TABLES `export_task` WRITE;
/*!40000 ALTER TABLE `export_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `export_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follow_up_plan`
--

DROP TABLE IF EXISTS `follow_up_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follow_up_plan` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '客户id',
  `opportunity_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商机id',
  `type` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `clue_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '线索id',
  `content` varchar(3000) COLLATE utf8mb4_general_ci NOT NULL COMMENT '跟进内容',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `contact_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '联系人',
  `estimated_time` bigint NOT NULL COMMENT '预计开始时间',
  `method` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '跟进方式',
  `status` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '状态',
  `converted` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否转为跟进记录',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_opportunity_id` (`opportunity_id`),
  KEY `idx_clue_id` (`clue_id`),
  KEY `idx_owner` (`owner`),
  KEY `idx_contact_id` (`contact_id`),
  KEY `idx_estimated_create` (`estimated_time` DESC,`create_time` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='跟进计划';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow_up_plan`
--

LOCK TABLES `follow_up_plan` WRITE;
/*!40000 ALTER TABLE `follow_up_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow_up_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follow_up_plan_field`
--

DROP TABLE IF EXISTS `follow_up_plan_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follow_up_plan_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '跟进计划id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id_field_id_field_value` (`resource_id`,`field_id`,`field_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='跟进计划自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow_up_plan_field`
--

LOCK TABLES `follow_up_plan_field` WRITE;
/*!40000 ALTER TABLE `follow_up_plan_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow_up_plan_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follow_up_plan_field_blob`
--

DROP TABLE IF EXISTS `follow_up_plan_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follow_up_plan_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '跟进计划id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='跟进计划自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow_up_plan_field_blob`
--

LOCK TABLES `follow_up_plan_field_blob` WRITE;
/*!40000 ALTER TABLE `follow_up_plan_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow_up_plan_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follow_up_record`
--

DROP TABLE IF EXISTS `follow_up_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follow_up_record` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '客户id',
  `opportunity_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商机id',
  `type` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `clue_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '线索id',
  `content` varchar(3000) COLLATE utf8mb4_general_ci NOT NULL COMMENT '跟进内容',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `follow_time` bigint NOT NULL COMMENT '跟进时间',
  `follow_method` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '跟进方式',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `contact_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '联系人id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_opportunity_id` (`opportunity_id`),
  KEY `idx_clue_id` (`clue_id`),
  KEY `idx_owner` (`owner`),
  KEY `idx_contact_id` (`contact_id`),
  KEY `idx_follow_create` (`follow_time` DESC,`create_time` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='跟进记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow_up_record`
--

LOCK TABLES `follow_up_record` WRITE;
/*!40000 ALTER TABLE `follow_up_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow_up_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follow_up_record_field`
--

DROP TABLE IF EXISTS `follow_up_record_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follow_up_record_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '跟进记录id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id_field_id_field_value` (`resource_id`,`field_id`,`field_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='跟进记录自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow_up_record_field`
--

LOCK TABLES `follow_up_record_field` WRITE;
/*!40000 ALTER TABLE `follow_up_record_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow_up_record_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `follow_up_record_field_blob`
--

DROP TABLE IF EXISTS `follow_up_record_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `follow_up_record_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '跟进记录id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='跟进记录自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `follow_up_record_field_blob`
--

LOCK TABLES `follow_up_record_field_blob` WRITE;
/*!40000 ALTER TABLE `follow_up_record_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `follow_up_record_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity`
--

DROP TABLE IF EXISTS `opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '客户ID',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '商机名称',
  `amount` decimal(20,10) DEFAULT NULL COMMENT '金额',
  `possible` decimal(20,10) DEFAULT NULL COMMENT '可能性',
  `products` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '意向产品',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `last_stage` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '上次修改前的商机阶段',
  `stage` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '商机阶段',
  `contact_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '联系人ID',
  `owner` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '负责人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `follower` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '最新跟进人',
  `follow_time` bigint DEFAULT NULL COMMENT '最新跟进时间',
  `expected_end_time` bigint DEFAULT NULL COMMENT '结束时间',
  `actual_end_time` bigint DEFAULT NULL COMMENT '实际结束时间',
  `failure_reason` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '失败原因',
  `pos` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_follower` (`follower`),
  KEY `idx_follow_time` (`follow_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity`
--

LOCK TABLES `opportunity` WRITE;
/*!40000 ALTER TABLE `opportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity_field`
--

DROP TABLE IF EXISTS `opportunity_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '商机id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id_field_id_field_value` (`resource_id`,`field_id`,`field_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity_field`
--

LOCK TABLES `opportunity_field` WRITE;
/*!40000 ALTER TABLE `opportunity_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity_field_blob`
--

DROP TABLE IF EXISTS `opportunity_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '商机id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity_field_blob`
--

LOCK TABLES `opportunity_field_blob` WRITE;
/*!40000 ALTER TABLE `opportunity_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity_quotation`
--

DROP TABLE IF EXISTS `opportunity_quotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity_quotation` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `opportunity_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '商机id',
  `amount` decimal(14,2) NOT NULL COMMENT '累计金额',
  `approval_status` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核状态',
  `invalid` tinyint(1) DEFAULT '0' COMMENT '是否作废: 0-正常, 1-作废',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织ID',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `until_time` bigint NOT NULL COMMENT '有效期至',
  PRIMARY KEY (`id`),
  KEY `idx_opportunity_id` (`opportunity_id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_approval_status` (`approval_status`),
  KEY `idx_until_time` (`until_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机报价单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity_quotation`
--

LOCK TABLES `opportunity_quotation` WRITE;
/*!40000 ALTER TABLE `opportunity_quotation` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity_quotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity_quotation_field`
--

DROP TABLE IF EXISTS `opportunity_quotation_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity_quotation_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '报价单id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  `ref_sub_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '引用子表格ID;关联的子表格字段ID',
  `row_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子表格行实例ID;行实例数据ID',
  `biz_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '唯一业务行ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_opp_quotation_field_cell` (`resource_id`,`ref_sub_id`,`row_id`,`field_id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机报价单自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity_quotation_field`
--

LOCK TABLES `opportunity_quotation_field` WRITE;
/*!40000 ALTER TABLE `opportunity_quotation_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity_quotation_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity_quotation_field_blob`
--

DROP TABLE IF EXISTS `opportunity_quotation_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity_quotation_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '报价单id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  `ref_sub_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '父引用ID;关联的子表格字段ID',
  `row_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '行实例ID;行实例数据ID',
  `biz_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '唯一业务行ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_opp_quotation_field_blob_cell` (`resource_id`,`ref_sub_id`,`row_id`,`field_id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机报价单自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity_quotation_field_blob`
--

LOCK TABLES `opportunity_quotation_field_blob` WRITE;
/*!40000 ALTER TABLE `opportunity_quotation_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity_quotation_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity_quotation_snapshot`
--

DROP TABLE IF EXISTS `opportunity_quotation_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity_quotation_snapshot` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `quotation_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '报价单id',
  `quotation_prop` longtext COLLATE utf8mb4_general_ci COMMENT '表单属性快照',
  `quotation_value` text COLLATE utf8mb4_general_ci COMMENT '表单值快照',
  PRIMARY KEY (`id`),
  KEY `idx_quotation_id` (`quotation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机报价单快照';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity_quotation_snapshot`
--

LOCK TABLES `opportunity_quotation_snapshot` WRITE;
/*!40000 ALTER TABLE `opportunity_quotation_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity_quotation_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity_rule`
--

DROP TABLE IF EXISTS `opportunity_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity_rule` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '规则名称',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织ID',
  `owner_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '管理员ID',
  `scope_id` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '范围ID',
  `enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '启用/禁用',
  `auto` bit(1) NOT NULL DEFAULT b'0' COMMENT '自动回收',
  `operator` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作符',
  `condition` text COLLATE utf8mb4_general_ci COMMENT '回收条件',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机关闭规则';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity_rule`
--

LOCK TABLES `opportunity_rule` WRITE;
/*!40000 ALTER TABLE `opportunity_rule` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity_stage_config`
--

DROP TABLE IF EXISTS `opportunity_stage_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity_stage_config` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(16) COLLATE utf8mb4_general_ci NOT NULL COMMENT '值',
  `type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `rate` varchar(10) COLLATE utf8mb4_general_ci NOT NULL COMMENT '赢率',
  `afoot_roll_back` bit(1) DEFAULT b'0' COMMENT '进行中回退设置',
  `end_roll_back` bit(1) DEFAULT b'0' COMMENT '完结回退设置',
  `pos` bigint NOT NULL COMMENT '顺序',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商机阶段配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity_stage_config`
--

LOCK TABLES `opportunity_stage_config` WRITE;
/*!40000 ALTER TABLE `opportunity_stage_config` DISABLE KEYS */;
INSERT INTO `opportunity_stage_config` VALUES ('BUSINESS_PROCUREMENT','商务采购','AFOOT','90',_binary '',_binary '\0',5,'100001',1760175899000,1760175899000,'admin','admin'),('CLEAR_REQUIREMENTS','需求明确','AFOOT','30',_binary '',_binary '\0',2,'100001',1760175899000,1760175899000,'admin','admin'),('CREATE','新建','AFOOT','10',_binary '',_binary '\0',1,'100001',1760175899000,1760175899000,'admin','admin'),('FAIL','失败','END','0',_binary '',_binary '\0',7,'100001',1760175899000,1760175899000,'admin','admin'),('PROJECT_PROPOSAL_REPORT','立项汇报','AFOOT','70',_binary '',_binary '\0',4,'100001',1760175899000,1760175899000,'admin','admin'),('SCHEME_VALIDATION','方案验证','AFOOT','50',_binary '',_binary '\0',3,'100001',1760175899000,1760175899000,'admin','admin'),('SUCCESS','成功','END','100',_binary '',_binary '\0',6,'100001',1760175899000,1760175899000,'admin','admin');
/*!40000 ALTER TABLE `opportunity_stage_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `price` decimal(14,4) DEFAULT NULL COMMENT '价格',
  `status` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态',
  `pos` bigint NOT NULL DEFAULT '0' COMMENT '排序',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织机构id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='产品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('384837032590974976','Ocean Shipping',1.0000,'1',4096,'100001',1780461727843,1780461759319,'384244868270006272','384244868270006272'),('384837187209797632','Air Shipping',1.0000,'1',8192,'100001',1780461745972,1780461745972,'384244868270006272','384244868270006272');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_field`
--

DROP TABLE IF EXISTS `product_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '产品id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id_field_id_field_value` (`resource_id`,`field_id`,`field_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='产品自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_field`
--

LOCK TABLES `product_field` WRITE;
/*!40000 ALTER TABLE `product_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_field_blob`
--

DROP TABLE IF EXISTS `product_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '产品id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='客户自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_field_blob`
--

LOCK TABLES `product_field_blob` WRITE;
/*!40000 ALTER TABLE `product_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_price`
--

DROP TABLE IF EXISTS `product_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_price` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '价格表名称',
  `status` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态',
  `pos` bigint NOT NULL COMMENT '自定义排序',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织ID',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_org_id` (`organization_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='价格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_price`
--

LOCK TABLES `product_price` WRITE;
/*!40000 ALTER TABLE `product_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_price_field`
--

DROP TABLE IF EXISTS `product_price_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_price_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '价格表ID',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性ID',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  `ref_sub_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '引用子表格ID;关联的子表格字段ID',
  `row_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子表格行实例ID;行实例数据ID',
  `biz_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '唯一业务行ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_price_field_cell` (`resource_id`,`ref_sub_id`,`row_id`,`field_id`),
  KEY `idx_resource_id` (`resource_id`),
  KEY `idx_ref_sub_id` (`ref_sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='价格自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_price_field`
--

LOCK TABLES `product_price_field` WRITE;
/*!40000 ALTER TABLE `product_price_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_price_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_price_field_blob`
--

DROP TABLE IF EXISTS `product_price_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_price_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '价格id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  `ref_sub_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '引用子表格ID;关联的子表格字段ID',
  `row_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子表格行实例ID;行实例数据ID',
  `biz_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '唯一业务行ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_price_field_blob_cell` (`resource_id`,`ref_sub_id`,`row_id`,`field_id`),
  KEY `idx_resource_id` (`resource_id`),
  KEY `idx_ref_sub_id` (`ref_sub_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='价格表自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_price_field_blob`
--

LOCK TABLES `product_price_field_blob` WRITE;
/*!40000 ALTER TABLE `product_price_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_price_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order`
--

DROP TABLE IF EXISTS `sales_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `number` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '编号',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单名称',
  `customer_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '客户id',
  `contract_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '合同id',
  `owner` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '订单负责人',
  `amount` decimal(20,10) DEFAULT NULL COMMENT '金额',
  `stage` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单状态',
  `approval_status` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '审批状态',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `pos` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_contract_id` (`contract_id`),
  KEY `idx_owner` (`owner`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order`
--

LOCK TABLES `sales_order` WRITE;
/*!40000 ALTER TABLE `sales_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_field`
--

DROP TABLE IF EXISTS `sales_order_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  `ref_sub_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '引用子表格ID;关联的子表格字段ID',
  `row_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子表格行实例ID;行实例数据ID',
  `biz_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '唯一业务行ID',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单自定义属性';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_field`
--

LOCK TABLES `sales_order_field` WRITE;
/*!40000 ALTER TABLE `sales_order_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_order_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_field_blob`
--

DROP TABLE IF EXISTS `sales_order_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性id',
  `field_value` text COLLATE utf8mb4_general_ci NOT NULL COMMENT '自定义属性值',
  `ref_sub_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '引用子表格ID;关联的子表格字段ID',
  `row_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '子表格行实例ID;行实例数据ID',
  `biz_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '唯一业务行ID',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单自定义属性大文本';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_field_blob`
--

LOCK TABLES `sales_order_field_blob` WRITE;
/*!40000 ALTER TABLE `sales_order_field_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_order_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_snapshot`
--

DROP TABLE IF EXISTS `sales_order_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_snapshot` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `order_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单id',
  `order_prop` longtext COLLATE utf8mb4_general_ci COMMENT '订单属性快照',
  `order_value` text COLLATE utf8mb4_general_ci COMMENT '订单值快照',
  PRIMARY KEY (`id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单快照';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_snapshot`
--

LOCK TABLES `sales_order_snapshot` WRITE;
/*!40000 ALTER TABLE `sales_order_snapshot` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales_order_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_order_stage_config`
--

DROP TABLE IF EXISTS `sales_order_stage_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_stage_config` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单状态',
  `type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态类型',
  `afoot_roll_back` bit(1) DEFAULT b'0' COMMENT '进行中回退设置',
  `end_roll_back` bit(1) DEFAULT b'0' COMMENT '完结回退设置',
  `pos` bigint NOT NULL COMMENT '顺序',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单状态流设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_stage_config`
--

LOCK TABLES `sales_order_stage_config` WRITE;
/*!40000 ALTER TABLE `sales_order_stage_config` DISABLE KEYS */;
INSERT INTO `sales_order_stage_config` VALUES ('COMPLETED','已完成','END',_binary '',_binary '\0',6,'100001',1772521969413,1772521969413,'admin','admin'),('CREATE','新建','AFOOT',_binary '',_binary '\0',1,'100001',1772521969413,1772521969413,'admin','admin'),('PARTIALLY_SHIPPED','部分发货','AFOOT',_binary '',_binary '\0',3,'100001',1772521969413,1772521969413,'admin','admin'),('PENDING_ACCEPTANCE','待验收','AFOOT',_binary '',_binary '\0',5,'100001',1772521969413,1772521969413,'admin','admin'),('PENDING_SHIPMENT','待发货','AFOOT',_binary '',_binary '\0',2,'100001',1772521969413,1772521969413,'admin','admin'),('SHIPPED','已发货','AFOOT',_binary '',_binary '\0',4,'100001',1772521969413,1772521969413,'admin','admin'),('VOIDED','已作废','END',_binary '',_binary '\0',7,'100001',1772521969413,1772521969413,'admin','admin');
/*!40000 ALTER TABLE `sales_order_stage_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedule`
--

DROP TABLE IF EXISTS `schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule` (
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'qrtz UUID',
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '执行类型 cron',
  `value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'cron 表达式',
  `job` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Schedule Job Class Name',
  `resource_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NONE' COMMENT '资源类型 API_IMPORT,API_SCENARIO,UI_SCENARIO,LOAD_TEST,TEST_PLAN,CLEAN_REPORT,BUG_SYNC',
  `enable` bit(1) DEFAULT NULL COMMENT '是否开启',
  `resource_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '资源ID，api_scenario ui_scenario load_test',
  `create_user` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `organization_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '组织ID',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '名称',
  `config` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '配置',
  `num` bigint NOT NULL COMMENT '业务ID',
  PRIMARY KEY (`id`),
  KEY `idx_resource_id` (`resource_id`),
  KEY `idx_create_user` (`create_user`),
  KEY `idx_create_time` (`create_time` DESC),
  KEY `idx_update_time` (`update_time` DESC),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_enable` (`enable`),
  KEY `idx_name` (`name`),
  KEY `idx_type` (`type`),
  KEY `idx_resource_type` (`resource_type`),
  KEY `idx_num` (`num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='定时任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedule`
--

LOCK TABLES `schedule` WRITE;
/*!40000 ALTER TABLE `schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_announcement`
--

DROP TABLE IF EXISTS `sys_announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_announcement` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `subject` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '公告标题',
  `content` blob NOT NULL COMMENT '公告内容',
  `start_time` bigint NOT NULL COMMENT '开始时间',
  `end_time` bigint NOT NULL COMMENT '结束时间',
  `url` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '链接',
  `rename_url` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '重命名链接',
  `receiver` blob NOT NULL COMMENT '接收人id(销售ids/角色ids/部门ids)',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `notice` bit(1) NOT NULL DEFAULT b'0' COMMENT '转为通知',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `receive_type` blob NOT NULL COMMENT '接收类型组合',
  PRIMARY KEY (`id`),
  KEY `idx_organizationId` (`organization_id`),
  KEY `idx_create_time` (`create_time` DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='公告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_announcement`
--

LOCK TABLES `sys_announcement` WRITE;
/*!40000 ALTER TABLE `sys_announcement` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_attachment`
--

DROP TABLE IF EXISTS `sys_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_attachment` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '类型',
  `size` bigint DEFAULT NULL COMMENT '大小',
  `storage` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '存储方式',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '资源ID',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织ID',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_storage` (`storage`),
  KEY `idx_org_id` (`organization_id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统附件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_attachment`
--

LOCK TABLES `sys_attachment` WRITE;
/*!40000 ALTER TABLE `sys_attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_department`
--

DROP TABLE IF EXISTS `sys_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_department` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `parent_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '父级',
  `pos` bigint NOT NULL COMMENT '排序',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `resource` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '来源',
  `resource_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '来源id',
  PRIMARY KEY (`id`),
  KEY `idx_resource` (`resource`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='部门表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_department`
--

LOCK TABLES `sys_department` WRITE;
/*!40000 ALTER TABLE `sys_department` DISABLE KEYS */;
INSERT INTO `sys_department` VALUES ('101927171227910394','Basenton','100001','NONE',100001,1736240043609,1780392754066,'admin','admin','INTERNAL',NULL),('384244601982033920','管理层','100001','101927171227910394',104097,1780392759871,1780392770049,'admin','admin','INTERNAL',NULL),('384244722241118208','Kevin组','100001','101927171227910394',108193,1780392773595,1780392773595,'admin','admin','INTERNAL',NULL),('384244782370660352','Betty组','100001','101927171227910394',112289,1780392780507,1780392780507,'admin','admin','INTERNAL',NULL);
/*!40000 ALTER TABLE `sys_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_department_commander`
--

DROP TABLE IF EXISTS `sys_department_commander`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_department_commander` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户id',
  `department_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '部门id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_department_id` (`department_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='部门责任人表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_department_commander`
--

LOCK TABLES `sys_department_commander` WRITE;
/*!40000 ALTER TABLE `sys_department_commander` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_department_commander` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict`
--

DROP TABLE IF EXISTS `sys_dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典值',
  `module` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典模块',
  `type` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'TEXT' COMMENT '字典值类型',
  `pos` bigint NOT NULL COMMENT '自定义排序',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织ID',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_org_type` (`organization_id`,`type`),
  KEY `idx_org_name` (`organization_id`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统字典表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict`
--

LOCK TABLES `sys_dict` WRITE;
/*!40000 ALTER TABLE `sys_dict` DISABLE KEYS */;
INSERT INTO `sys_dict` VALUES ('101927171227910432','客户选择竞品','OPPORTUNITY_FAIL_RS','TEXT',1,'100001',1780392057000,1780392057000,'admin','admin'),('101927171227910433','立项失败','OPPORTUNITY_FAIL_RS','TEXT',2,'100001',1780392057000,1780392057000,'admin','admin'),('101927171227910434','决策链复杂','OPPORTUNITY_FAIL_RS','TEXT',3,'100001',1780392057000,1780392057000,'admin','admin'),('101927171227910435','预算限制','OPPORTUNITY_FAIL_RS','TEXT',4,'100001',1780392057000,1780392057000,'admin','admin'),('101927171227910436','需求变化','OPPORTUNITY_FAIL_RS','TEXT',5,'100001',1780392057000,1780392057000,'admin','admin');
/*!40000 ALTER TABLE `sys_dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_dict_config`
--

DROP TABLE IF EXISTS `sys_dict_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_dict_config` (
  `module` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '字典类型',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织ID',
  `enabled` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否启用',
  PRIMARY KEY (`module`,`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统字典配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_dict_config`
--

LOCK TABLES `sys_dict_config` WRITE;
/*!40000 ALTER TABLE `sys_dict_config` DISABLE KEYS */;
INSERT INTO `sys_dict_config` VALUES ('CONTRACT_APPROVAL','100001',_binary ''),('INVOICE_APPROVAL','100001',_binary ''),('QUOTATION_APPROVAL','100001',_binary '');
/*!40000 ALTER TABLE `sys_dict_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_license`
--

DROP TABLE IF EXISTS `sys_license`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_license` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `license_code` longtext COLLATE utf8mb4_general_ci NOT NULL COMMENT 'license_code',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='license';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_license`
--

LOCK TABLES `sys_license` WRITE;
/*!40000 ALTER TABLE `sys_license` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_license` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_login_log`
--

DROP TABLE IF EXISTS `sys_login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_login_log` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `create_time` bigint NOT NULL COMMENT '操作时间',
  `operator` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作人',
  `login_address` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '登录地',
  `platform` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '平台',
  PRIMARY KEY (`id`),
  KEY `idx_operator` (`operator`),
  KEY `idx_create_time` (`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='登入日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_login_log`
--

LOCK TABLES `sys_login_log` WRITE;
/*!40000 ALTER TABLE `sys_login_log` DISABLE KEYS */;
INSERT INTO `sys_login_log` VALUES ('384246878314700800',1780393024728,'admin','172.18.0.1','WEB'),('384255743127199744',1780394056765,'admin','172.18.0.1','WEB'),('384262932902453248',1780394893062,'admin','172.18.0.5','WEB'),('384266145537990656',1780395267889,'admin','172.18.0.1','WEB'),('384266575034720256',1780395317829,'admin','172.18.0.5','WEB'),('384309292779446272',1780400290653,'admin','172.18.0.5','WEB'),('384763854938185728',1780453208041,'admin','172.18.0.1','WEB'),('384825255790649344',1780460356227,'384244868270006280','172.18.0.1','WEB'),('384825315920191488',1780460363696,'admin','172.18.0.1','WEB'),('384826089014304768',1780460453674,'384244868270006280','172.18.0.1','WEB'),('384832978141847552',1780461255142,'384244868270006274','172.18.0.1','WEB'),('384833167120408576',1780461277665,'admin','172.18.0.1','WEB'),('384833553667465216',1780461322140,'384244868270006274','172.18.0.1','WEB'),('384834077653475328',1780461383140,'384244868270006272','172.18.0.1','WEB'),('384834593049550848',1780461443738,'384244868270006280','172.18.0.1','WEB'),('384834842157654016',1780461472479,'384244868270006274','172.18.0.1','WEB'),('384835469222879232',1780461545353,'384244868270006280','172.18.0.1','WEB'),('384836826432544768',1780461703281,'384244868270006272','172.18.0.1','WEB'),('384837419138031616',1780461772239,'admin','172.18.0.1','WEB'),('384848208095879168',1780463028524,'384244868270006274','172.18.0.1','WEB'),('384848319765028864',1780463041849,'384244868270006280','172.18.0.1','WEB'),('384848981189992448',1780463118559,'384244868270006274','172.18.0.1','WEB'),('384849084269207552',1780463130731,'384244868270006272','172.18.0.1','WEB'),('384849256067899392',1780463150877,'384244868270006274','172.18.0.1','WEB'),('384849410686722048',1780463168424,'384244868270006280','172.18.0.1','WEB'),('384849556715610112',1780463185152,'admin','172.18.0.1','WEB'),('384850072111685632',1780463245746,'384244868270006272','172.18.0.1','WEB'),('384850304039919616',1780463272449,'384244868270006280','172.18.0.1','WEB'),('384897325341876224',1780468746930,'admin','172.18.0.1','WEB'),('384897497140568064',1780468766675,'384244868270006274','172.18.0.1','WEB'),('384897574449979392',1780468775881,'384244868270006272','172.18.0.1','WEB'),('384897754838605824',1780468796378,'384244868270006274','172.18.0.1','WEB'),('384897952407101440',1780468819977,'384244868270006280','172.18.0.1','WEB'),('384898184335335424',1780468846985,'384244868270006274','172.18.0.1','WEB'),('384898287414550528',1780468858481,'384244868270006272','172.18.0.1','WEB'),('384898442033373184',1780468876270,'admin','172.18.0.1','WEB'),('384898639601868800',1780468899895,'384244868270006272','172.18.0.1','WEB'),('384898802810626048',1780468918888,'384244868270006280','172.18.0.1','WEB'),('384898983199252480',1780468939921,'384244868270006272','172.18.0.1','WEB'),('384899154997944320',1780468959488,'admin','172.18.0.1','WEB'),('384899799243038720',1780469034806,'384244868270006272','172.18.0.1','WEB'),('384899910912188416',1780469047840,'admin','172.18.0.1','WEB'),('384900245919637504',1780469086321,'384244868270006272','172.18.0.1','WEB'),('384900306049179648',1780469093917,'admin','172.18.0.1','WEB'),('384903604584062976',1780469477845,'admin','192.168.1.23','WEB'),('384904523707064320',1780469584893,'384244868270006272','172.18.0.1','WEB'),('384904996153466880',1780469639331,'384244868270006274','172.18.0.1','WEB'),('384906130024833024',1780469771252,'384244868270006274','172.18.0.1','WEB'),('384906361953067008',1780469798793,'admin','172.18.0.1','WEB'),('384906422082609152',1780469805333,'384244868270006272','172.18.0.1','WEB'),('384906568111497216',1780469822489,'384244868270006280','172.18.0.1','WEB'),('384907177996853248',1780469893927,'384244868270006274','172.18.0.1','WEB'),('384907341205610496',1780469912811,'admin','172.18.0.1','WEB'),('384907538774106112',1780469935576,'384244868270006280','172.18.0.1','WEB'),('384912778634207232',1780470545984,'admin','172.18.0.1','WEB'),('385577476362870784',1780547926663,'admin','172.18.0.1','WEB'),('385581788510060544',1780548428711,'admin','172.18.0.1','WEB'),('385588402759696384',1780549198029,'admin','172.18.0.1','WEB'),('385588402759696385',1780549198051,'admin','172.18.0.1','WEB'),('385591477956288512',1780549556535,'admin','172.18.0.1','WEB'),('385591477956288513',1780549556598,'admin','172.18.0.1','WEB'),('385605264801316864',1780551161527,'admin','172.18.0.1','WEB'),('385605410830204928',1780551178038,'admin','172.18.0.1','WEB'),('385605780197392384',1780551221834,'admin','172.18.0.1','WEB'),('385606467392159744',1780551301296,'admin','172.18.0.1','WEB'),('385610049394892800',1780551718072,'admin','172.18.0.1','WEB'),('385616818263351296',1780552506162,'admin','172.18.0.1','WEB'),('385628028127993856',1780553811568,'384244868270006280','172.18.0.1','WEB'),('385629419697397760',1780553973467,'384244868270006278','172.18.0.1','WEB'),('385631060374904832',1780554164285,'admin','172.18.0.1','WEB'),('385634041082216448',1780554511012,'admin','172.18.0.1','WEB'),('385637726164164608',1780554940870,'admin','172.18.0.1','WEB'),('385642622426882048',1780555510960,'384244868270006272','172.18.0.1','WEB'),('385642734096031744',1780555523102,'admin','172.18.0.1','WEB');
/*!40000 ALTER TABLE `sys_login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_message_task`
--

DROP TABLE IF EXISTS `sys_message_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_message_task` (
  `id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `event` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '通知事件类型',
  `task_type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务类型',
  `email_enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '邮件启用',
  `sys_enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '系统启用',
  `we_com_enable` bit(1) DEFAULT b'0' COMMENT '企业微信启用',
  `ding_talk_enable` bit(1) DEFAULT b'0' COMMENT '钉钉启用',
  `lark_enable` bit(1) DEFAULT b'0' COMMENT '飞书启用',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `template` blob COMMENT '消息模版',
  `create_user` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `create_time` bigint NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_user` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '修改人',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_create_time` (`create_time` DESC),
  KEY `idx_task_type` (`task_type`),
  KEY `idx_event` (`event`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_email_enable` (`email_enable`),
  KEY `idx_sys_enable` (`sys_enable`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='消息通知任务';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_message_task`
--

LOCK TABLES `sys_message_task` WRITE;
/*!40000 ALTER TABLE `sys_message_task` DISABLE KEYS */;
INSERT INTO `sys_message_task` VALUES ('101927171227910395','CUSTOMER_ADD','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910396','CUSTOMER_TRANSFERRED_CUSTOMER','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910397','CUSTOMER_AUTOMATIC_MOVE_HIGH_SEAS','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910398','CUSTOMER_MOVED_HIGH_SEAS','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910399','CUSTOMER_DELETED','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910400','HIGH_SEAS_CUSTOMER_DISTRIBUTED','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910401','CUSTOMER_FOLLOW_UP_PLAN_DUE','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910402','CLUE_AUTOMATIC_MOVE_POOL','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910403','CLUE_MOVED_POOL','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910404','CLUE_CONVERT_CUSTOMER','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910405','TRANSFER_CLUE','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910406','CLUE_DELETED','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910407','CLUE_DISTRIBUTED','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910408','CLUE_IMPORT','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910409','CLUE_FOLLOW_UP_PLAN_DUE','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910410','BUSINESS_DELETED','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910411','BUSINESS_TRANSFER','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910412','BUSINESS_IMPORT','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910413','BUSINESS_FOLLOW_UP_PLAN_DUE','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392056002,'admin',1780392056002),('101927171227910447','CUSTOMER_CONCAT_ADD','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392058002,'admin',1780392058002),('101927171227910448','CUSTOMER_COLLABORATION_ADD','CUSTOMER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392058002,'admin',1780392058002),('101927171227910449','CLUE_CONVERT_BUSINESS','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392058002,'admin',1780392058002),('101927171227910485','BUSINESS_QUOTATION_APPROVAL','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910486','BUSINESS_QUOTATION_DELETED','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910547','BUSINESS_QUOTATION_EXPIRING','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910549','BUSINESS_QUOTATION_EXPIRED','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910551','CONTRACT_ARCHIVED','CONTRACT',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910553','CONTRACT_VOID','CONTRACT',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910555','CONTRACT_EXPIRING','CONTRACT',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910557','CONTRACT_EXPIRED','CONTRACT',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910559','CONTRACT_PAYMENT_EXPIRING','CONTRACT',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910561','CONTRACT_PAYMENT_EXPIRED','CONTRACT',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392059002,'admin',1780392059002),('101927171227910618','SYNC_ORGANIZATION_STRUCTURE','SYSTEM',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392060002,'admin',1780392060002),('101927171227910638','CLUE_ADD','CLUE',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392060002,'admin',1780392060002),('101927171227910639','BUSINESS_ADD','OPPORTUNITY',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392060002,'admin',1780392060002),('101927171227910640','CONTRACT_APPROVAL','CONTRACT',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392061002,'admin',1780392061002),('101927171227910641','ORDER_APPROVAL','ORDER',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392061002,'admin',1780392061002),('101927171227910642','INVOICE_APPROVAL','CONTRACT',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392061002,'admin',1780392061002),('101927171227910643','APPROVAL_TODO','APPROVAL',_binary '\0',_binary '',_binary '\0',_binary '\0',_binary '\0','100001',NULL,'admin',1780392061002,'admin',1780392061002);
/*!40000 ALTER TABLE `sys_message_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_message_task_config`
--

DROP TABLE IF EXISTS `sys_message_task_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_message_task_config` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `event` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '通知事件类型',
  `task_type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '任务类型',
  `value` text COLLATE utf8mb4_general_ci COMMENT '通知配置值',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_task_type` (`task_type`),
  KEY `idx_event` (`event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='消息通知配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_message_task_config`
--

LOCK TABLES `sys_message_task_config` WRITE;
/*!40000 ALTER TABLE `sys_message_task_config` DISABLE KEYS */;
INSERT INTO `sys_message_task_config` VALUES ('101927171227910548','100001','BUSINESS_QUOTATION_EXPIRING','OPPORTUNITY','{\"timeList\":[{\"timeValue\":3,\"timeUnit\":\"DAY\"}],\"userIds\":[\"OWNER\"],\"roleIds\":[],\"ownerEnable\":false,\"ownerLevel\":0,\"roleEnable\":false}'),('101927171227910550','100001','BUSINESS_QUOTATION_EXPIRED','OPPORTUNITY','{\"timeList\":[],\"userIds\":[\"OWNER\"],\"roleIds\":[],\"ownerEnable\":false,\"ownerLevel\":0,\"roleEnable\":false}'),('101927171227910552','100001','CONTRACT_ARCHIVED','CONTRACT','{\"timeList\":[],\"userIds\":[\"OWNER\"],\"roleIds\":[],\"ownerEnable\":false,\"ownerLevel\":0,\"roleEnable\":false}'),('101927171227910554','100001','CONTRACT_VOID','CONTRACT','{\"timeList\":[],\"userIds\":[\"OWNER\"],\"roleIds\":[],\"ownerEnable\":false,\"ownerLevel\":0,\"roleEnable\":false}'),('101927171227910556','100001','CONTRACT_EXPIRING','CONTRACT','{\"timeList\":[{\"timeValue\":3,\"timeUnit\":\"DAY\"}],\"userIds\":[\"OWNER\"],\"roleIds\":[],\"ownerEnable\":false,\"ownerLevel\":0,\"roleEnable\":false}'),('101927171227910558','100001','CONTRACT_EXPIRED','CONTRACT','{\"timeList\":[],\"userIds\":[\"OWNER\"],\"roleIds\":[],\"ownerEnable\":false,\"ownerLevel\":0,\"roleEnable\":false}'),('101927171227910560','100001','CONTRACT_PAYMENT_EXPIRING','CONTRACT','{\"timeList\":[{\"timeValue\":3,\"timeUnit\":\"DAY\"}],\"userIds\":[\"OWNER\"],\"roleIds\":[],\"ownerEnable\":false,\"ownerLevel\":0,\"roleEnable\":false}'),('101927171227910562','100001','CONTRACT_PAYMENT_EXPIRED','CONTRACT','{\"timeList\":[],\"userIds\":[\"OWNER\"],\"roleIds\":[],\"ownerEnable\":false,\"ownerLevel\":0,\"roleEnable\":false}');
/*!40000 ALTER TABLE `sys_message_task_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_module`
--

DROP TABLE IF EXISTS `sys_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_module` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `module_key` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '模块KEY',
  `enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '启用/禁用',
  `pos` bigint NOT NULL COMMENT '自定义排序',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '修改人',
  `update_time` bigint NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='模块配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_module`
--

LOCK TABLES `sys_module` WRITE;
/*!40000 ALTER TABLE `sys_module` DISABLE KEYS */;
INSERT INTO `sys_module` VALUES ('101927171227910424','100001','dashboard',_binary '',7,'admin',1780392057000,'admin',1780392057000),('101927171227910457','100001','agent',_binary '',8,'admin',1780392058000,'admin',1780392058000),('101927171227910483','100001','contract',_binary '',9,'admin',1780392059000,'admin',1780392059000),('101927171227910484','100001','tender',_binary '',10,'admin',1780392059000,'admin',1780392059000),('101927171227910622','100001','order',_binary '',10,'admin',1780392060000,'admin',1780392060000),('384238649157361664','100001','home',_binary '',1,'admin',1780392066283,'admin',1780392066283),('384238649157361665','100001','clue',_binary '',2,'admin',1780392066283,'admin',1780392066283),('384238649157361666','100001','customer',_binary '',3,'admin',1780392066283,'admin',1780392066283),('384238649157361667','100001','business',_binary '',4,'admin',1780392066283,'admin',1780392066283),('384238649157361668','100001','product',_binary '',5,'admin',1780392066283,'admin',1780392066283),('384238649157361669','100001','setting',_binary '',6,'admin',1780392066283,'admin',1780392066283);
/*!40000 ALTER TABLE `sys_module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_module_field`
--

DROP TABLE IF EXISTS `sys_module_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_module_field` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `form_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '所属表单ID',
  `internal_key` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '字段内置Key',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `mobile` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否移动端',
  `pos` bigint NOT NULL COMMENT '排序',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_form_id_internal_key` (`form_id`,`internal_key`),
  KEY `idx_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='模块字段配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_module_field`
--

LOCK TABLES `sys_module_field` WRITE;
/*!40000 ALTER TABLE `sys_module_field` DISABLE KEYS */;
INSERT INTO `sys_module_field` VALUES ('384238649157361684','384238649157361682','contractPaymentRecordBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066321,'admin',1780392066321),('384238649157361685','384238649157361682','contractPaymentRecordName','回款记录名称','INPUT',_binary '',2,'admin',1780392066323,'admin',1780392066323),('384238649157361686','384238649157361682','contractPaymentRecordNo','回款编码','SERIAL_NUMBER',_binary '',3,'admin',1780392066323,'admin',1780392066323),('384238649157361687','384238649157361682','contractPaymentRecordContract','合同名称','DATA_SOURCE',_binary '',4,'admin',1780392066323,'admin',1780392066323),('384238649157361688','384238649157361682','contractPaymentRecordPlan','回款计划','DATA_SOURCE',_binary '',5,'admin',1780392066323,'admin',1780392066323),('384238649157361689','384238649157361682','contractPaymentRecordOwner','负责人','MEMBER',_binary '',6,'admin',1780392066323,'admin',1780392066323),('384238649157361690','384238649157361682','contractPaymentRecordInfo','回款信息','DIVIDER',_binary '',7,'admin',1780392066323,'admin',1780392066323),('384238649157361691','384238649157361682','contractPaymentRecordEndTime','回款时间','DATE_TIME',_binary '',8,'admin',1780392066323,'admin',1780392066323),('384238649157361692','384238649157361682','contractPaymentRecordAmount','回款金额','INPUT_NUMBER',_binary '',9,'admin',1780392066323,'admin',1780392066323),('384238649157361693','384238649157361682','contractPaymentRecordBank','收款银行','SELECT',_binary '',10,'admin',1780392066323,'admin',1780392066323),('384238649157361694','384238649157361682','contractPaymentRecordBankNo','收款银行账号','SELECT',_binary '',11,'admin',1780392066323,'admin',1780392066323),('384238649157361695','384238649157361676','productBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066323,'admin',1780392066323),('384238649157361696','384238649157361676','productName','产品名称','INPUT',_binary '',2,'admin',1780392066323,'admin',1780392066323),('384238649157361697','384238649157361676','productPrice','产品价格','INPUT_NUMBER',_binary '',3,'admin',1780392066324,'admin',1780392066324),('384238649157361698','384238649157361676','productStatus','状态','RADIO',_binary '',4,'admin',1780392066324,'admin',1780392066324),('384238649157361699','384238649157361676','productDescription','描述','TEXTAREA',_binary '',5,'admin',1780392066324,'admin',1780392066324),('384238649157361700','384238649157361676','productPicInfo','图片信息','DIVIDER',_binary '',6,'admin',1780392066324,'admin',1780392066324),('384238649157361701','384238649157361676','productPic','产品图片','PICTURE',_binary '',7,'admin',1780392066324,'admin',1780392066324),('384238649157361702','384238649157361681','contractPaymentPlanContract','合同','DATA_SOURCE',_binary '',2,'admin',1780392066324,'admin',1780392066324),('384238649157361703','384238649157361681','contractPaymentPlanOwner','负责人','MEMBER',_binary '',3,'admin',1780392066324,'admin',1780392066324),('384238649157361704','384238649157361681','contractPaymentPlanPlanAmount','计划回款金额','INPUT_NUMBER',_binary '',4,'admin',1780392066324,'admin',1780392066324),('384238649157361705','384238649157361681','contractPaymentPlanPlanEndTime','计划回款时间','DATE_TIME',_binary '',5,'admin',1780392066324,'admin',1780392066324),('384238649157361706','384238649157361679','contractBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066324,'admin',1780392066324),('384238649157361707','384238649157361679','contractName','合同','INPUT',_binary '',2,'admin',1780392066324,'admin',1780392066324),('384238649157361708','384238649157361679','contractCustomer','客户名称','DATA_SOURCE',_binary '',3,'admin',1780392066324,'admin',1780392066324),('384238649157361709','384238649157361679','contractNo','合同编号','SERIAL_NUMBER',_binary '',4,'admin',1780392066324,'admin',1780392066324),('384238649157361710','384238649157361679','contractProducts','合同报价信息','SUB_PRODUCT',_binary '',5,'admin',1780392066324,'admin',1780392066324),('384238649157361715','384238649157361679','contractOwner','负责人','MEMBER',_binary '',6,'admin',1780392066348,'admin',1780392066348),('384238649157361716','384238649157361675','opportunityBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066348,'admin',1780392066348),('384238649157361717','384238649157361675','opportunityName','商机名称','INPUT',_binary '',2,'admin',1780392066348,'admin',1780392066348),('384238649157361718','384238649157361675','opportunityCustomer','客户名称','DATA_SOURCE',_binary '',3,'admin',1780392066348,'admin',1780392066348),('384238649157361719','384238649157361675','opportunityNo','业务编码','SERIAL_NUMBER',_binary '',4,'admin',1780392066348,'admin',1780392066348),('384238649157361720','384238649157361675','opportunitySource','商机来源','SELECT',_binary '',5,'admin',1780392066348,'admin',1780392066348),('384238649157361721','384238649157361675','opportunityPrice','金额','INPUT_NUMBER',_binary '',6,'admin',1780392066348,'admin',1780392066348),('384238649157361722','384238649157361675','opportunityProduct','意向产品','DATA_SOURCE_MULTIPLE',_binary '',7,'admin',1780392066348,'admin',1780392066348),('384238649157361723','384238649157361675','opportunityEndTime','结束时间','DATE_TIME',_binary '',8,'admin',1780392066348,'admin',1780392066348),('384238649157361724','384238649157361675','opportunityWinRate','可能性','INPUT_NUMBER',_binary '',9,'admin',1780392066348,'admin',1780392066348),('384238649157361725','384238649157361675','opportunityContact','联系人','DATA_SOURCE',_binary '',10,'admin',1780392066348,'admin',1780392066348),('384238649157361726','384238649157361675','opportunityCustomerTag','客户标签','INPUT_MULTIPLE',_binary '',11,'admin',1780392066348,'admin',1780392066348),('384238649157361727','384238649157361675','opportunityRemark','备注信息','TEXTAREA',_binary '',12,'admin',1780392066348,'admin',1780392066348),('384238649157361728','384238649157361675','opportunityAddressInfo','地址信息','DIVIDER',_binary '',13,'admin',1780392066348,'admin',1780392066348),('384238649157361729','384238649157361675','opportunityArea','地区','LOCATION',_binary '',14,'admin',1780392066348,'admin',1780392066348),('384238649157361730','384238649157361675','opportunityOwnerInfo','负责人信息','DIVIDER',_binary '',15,'admin',1780392066348,'admin',1780392066348),('384238649157361731','384238649157361675','opportunityOwner','负责人','MEMBER',_binary '',16,'admin',1780392066348,'admin',1780392066348),('384238649157361732','384238649157361677','priceBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066348,'admin',1780392066348),('384238649157361733','384238649157361677','priceName','价格表名称','INPUT',_binary '',2,'admin',1780392066348,'admin',1780392066348),('384238649157361734','384238649157361677','priceStatus','状态','RADIO',_binary '',3,'admin',1780392066349,'admin',1780392066349),('384238649157361735','384238649157361677','priceProducts','产品信息','SUB_PRODUCT',_binary '',4,'admin',1780392066349,'admin',1780392066349),('384238649157361741','384238649157361677','priceRemark','备注','TEXTAREA',_binary '',5,'admin',1780392066351,'admin',1780392066351),('384238649157361742','384238649157361670','clueBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066351,'admin',1780392066351),('384238649157361743','384238649157361670','clueName','公司名称','INPUT',_binary '',2,'admin',1780392066351,'admin',1780392066351),('384238649157361744','384238649157361670','clueProgress','线索进度','SELECT',_binary '',3,'admin',1780392066351,'admin',1780392066351),('384238649157361745','384238649157361670','clueSource','线索来源','SELECT',_binary '',4,'admin',1780392066351,'admin',1780392066351),('384238649157361746','384238649157361670','clueOnlineSource','线上来源详情','SELECT',_binary '',5,'admin',1780392066352,'admin',1780392066352),('384238649157361747','384238649157361670','clueDemand','客户需求','TEXTAREA',_binary '',6,'admin',1780392066352,'admin',1780392066352),('384238649157361748','384238649157361670','clueContactName','联系人名称','INPUT',_binary '',7,'admin',1780392066352,'admin',1780392066352),('384238649157361749','384238649157361670','clueContactPhone','联系人电话','PHONE',_binary '',8,'admin',1780392066352,'admin',1780392066352),('384238649157361750','384238649157361670','clueProduct','意向产品','DATA_SOURCE_MULTIPLE',_binary '',9,'admin',1780392066352,'admin',1780392066352),('384238649157361751','384238649157361670','clueAddressInfo','地址信息','DIVIDER',_binary '',10,'admin',1780392066352,'admin',1780392066352),('384238649157361752','384238649157361670','clueArea','地区','LOCATION',_binary '',11,'admin',1780392066352,'admin',1780392066352),('384238649157361753','384238649157361670','clueOwnerInfo','负责人信息','DIVIDER',_binary '',12,'admin',1780392066352,'admin',1780392066352),('384238649157361754','384238649157361670','clueOwner','负责人','MEMBER',_binary '',13,'admin',1780392066352,'admin',1780392066352),('384238649157361755','384238649157361672','contactCustomer','客户名称','DATA_SOURCE',_binary '',0,'admin',1780557135363,'admin',1780557135363),('384238649157361756','384238649157361672','contactName','姓名','INPUT',_binary '',1,'admin',1780557135363,'admin',1780557135363),('384238649157361757','384238649157361672','contactEmail','邮箱','INPUT',_binary '',2,'admin',1780557135363,'admin',1780557135363),('384238649157361758','384238649157361672','contactPhone','手机号','PHONE',_binary '',3,'admin',1780557135363,'admin',1780557135363),('384238649157361759','384238649157361672','contactOwner','负责人','MEMBER',_binary '',4,'admin',1780557135363,'admin',1780557135363),('384238649157361760','384238649157361673','recordType','跟进类型','SELECT',_binary '',1,'admin',1780392066352,'admin',1780392066352),('384238649157361761','384238649157361673','recordCustomer','客户名称','DATA_SOURCE',_binary '',2,'admin',1780392066352,'admin',1780392066352),('384238649157361762','384238649157361673','recordOpportunity','商机','DATA_SOURCE',_binary '',4,'admin',1780392066352,'admin',1780392066352),('384238649157361763','384238649157361673','recordContact','联系人','DATA_SOURCE',_binary '',5,'admin',1780392066352,'admin',1780392066352),('384238649157361764','384238649157361673','recordClue','公司名称','DATA_SOURCE',_binary '',3,'admin',1780392066352,'admin',1780392066352),('384238649157361765','384238649157361673','recordMethod','跟进方式','SELECT',_binary '',6,'admin',1780392066352,'admin',1780392066352),('384238649157361766','384238649157361673','recordTime','跟进时间','DATE_TIME',_binary '',7,'admin',1780392066352,'admin',1780392066352),('384238649157361767','384238649157361673','recordOwner','负责人','MEMBER',_binary '',8,'admin',1780392066352,'admin',1780392066352),('384238649157361768','384238649157361673','recordProduct','意向产品','DATA_SOURCE_MULTIPLE',_binary '',9,'admin',1780392066352,'admin',1780392066352),('384238649157361769','384238649157361673','recordDescription','跟进内容','TEXTAREA',_binary '',10,'admin',1780392066352,'admin',1780392066352),('384238649157361770','384238649157361680','invoiceBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066352,'admin',1780392066352),('384238649157361771','384238649157361680','invoiceName','发票名称','INPUT',_binary '',2,'admin',1780392066352,'admin',1780392066352),('384238649157361772','384238649157361680','invoiceContractBasicInfo','合同信息','DIVIDER',_binary '',3,'admin',1780392066352,'admin',1780392066352),('384238649157361773','384238649157361680','invoiceContract','合同名称','DATA_SOURCE',_binary '',4,'admin',1780392066352,'admin',1780392066352),('384238649157361774','384238649157361680','invoiceBasicInfo','发票信息','DIVIDER',_binary '',5,'admin',1780392066355,'admin',1780392066355),('384238649157361775','384238649157361680','invoiceType','开票类型','SELECT',_binary '',6,'admin',1780392066355,'admin',1780392066355),('384238649157361776','384238649157361680','invoiceProjectName','开票项目名称','SELECT',_binary '',7,'admin',1780392066355,'admin',1780392066355),('384238649157361777','384238649157361680','invoiceSpecification','规格型号','SELECT',_binary '',8,'admin',1780392066355,'admin',1780392066355),('384238649157361778','384238649157361680','invoiceUnit','单位','SELECT',_binary '',9,'admin',1780392066355,'admin',1780392066355),('384238649157361779','384238649157361680','invoiceQuantity','数量','INPUT_NUMBER',_binary '',10,'admin',1780392066355,'admin',1780392066355),('384238649157361780','384238649157361680','invoiceTaxRate','税率','INPUT_NUMBER',_binary '',11,'admin',1780392066355,'admin',1780392066355),('384238649157361781','384238649157361680','invoiceBusinessTitle','工商抬头','DATA_SOURCE',_binary '',12,'admin',1780392066355,'admin',1780392066355),('384238649157361782','384238649157361680','invoiceAmount','发票金额','INPUT_NUMBER',_binary '',13,'admin',1780392066356,'admin',1780392066356),('384238649157361783','384238649157361680','invoiceOwner','负责人','MEMBER',_binary '',14,'admin',1780392066356,'admin',1780392066356),('384238649157361784','384238649157361674','planType','跟进类型','SELECT',_binary '',1,'admin',1780392066356,'admin',1780392066356),('384238649157361785','384238649157361674','planCustomer','客户名称','DATA_SOURCE',_binary '',2,'admin',1780392066357,'admin',1780392066357),('384238649157361786','384238649157361674','planOpportunity','商机','DATA_SOURCE',_binary '',4,'admin',1780392066357,'admin',1780392066357),('384238649157361787','384238649157361674','planContact','联系人','DATA_SOURCE',_binary '',5,'admin',1780392066357,'admin',1780392066357),('384238649157361788','384238649157361674','planClue','公司名称','DATA_SOURCE',_binary '',3,'admin',1780392066357,'admin',1780392066357),('384238649157361789','384238649157361674','planStartTime','预计开始时间','DATE_TIME',_binary '',6,'admin',1780392066357,'admin',1780392066357),('384238649157361790','384238649157361674','planMethod','跟进方式','SELECT',_binary '',7,'admin',1780392066357,'admin',1780392066357),('384238649157361791','384238649157361674','planOwner','负责人','MEMBER',_binary '',8,'admin',1780392066357,'admin',1780392066357),('384238649157361792','384238649157361674','planProduct','意向产品','DATA_SOURCE_MULTIPLE',_binary '',9,'admin',1780392066357,'admin',1780392066357),('384238649157361793','384238649157361674','planContent','预计沟通内容','TEXTAREA',_binary '',10,'admin',1780392066357,'admin',1780392066357),('384238649157361794','384238649157361678','quotationBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066357,'admin',1780392066357),('384238649157361795','384238649157361678','quotationName','报价','INPUT',_binary '',2,'admin',1780392066357,'admin',1780392066357),('384238649157361796','384238649157361678','quotationOpportunity','商机','DATA_SOURCE',_binary '',3,'admin',1780392066357,'admin',1780392066357),('384238649157361797','384238649157361678','quotationContact','联系人','DATA_SOURCE',_binary '',4,'admin',1780392066357,'admin',1780392066357),('384238649157361798','384238649157361678','quotationTime','报价日期','DATE_TIME',_binary '',5,'admin',1780392066357,'admin',1780392066357),('384238649157361799','384238649157361678','quotationUntilTime','有效期至','DATE_TIME',_binary '',6,'admin',1780392066357,'admin',1780392066357),('384238649157361800','384238649157361678','quotationProducts','报价产品','SUB_PRICE',_binary '',7,'admin',1780392066357,'admin',1780392066357),('384238649157361807','384238649157361671','customerBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066358,'admin',1780392066358),('384238649157361808','384238649157361671','customerName','客户名称','INPUT',_binary '',2,'admin',1780392066358,'admin',1780392066358),('384238649157361809','384238649157361671','customerIndustry','客户行业','SELECT',_binary '',3,'admin',1780392066358,'admin',1780392066358),('384238649157361810','384238649157361671','customerLevel','客户等级','SELECT',_binary '',4,'admin',1780392066358,'admin',1780392066358),('384238649157361811','384238649157361671','customerType','客户类型','SELECT',_binary '',5,'admin',1780392066358,'admin',1780392066358),('384238649157361812','384238649157361671','customerSource','客户来源','SELECT',_binary '',6,'admin',1780392066358,'admin',1780392066358),('384238649157361813','384238649157361671','customerOnlineSource','线上来源详情','SELECT',_binary '',7,'admin',1780392066358,'admin',1780392066358),('384238649157361814','384238649157361671','customerTag','客户标签','INPUT_MULTIPLE',_binary '',8,'admin',1780392066358,'admin',1780392066358),('384238649157361815','384238649157361671','customerAddressInfo','地址信息','DIVIDER',_binary '',9,'admin',1780392066358,'admin',1780392066358),('384238649157361816','384238649157361671','customerArea','地区','LOCATION',_binary '',10,'admin',1780392066358,'admin',1780392066358),('384238649157361817','384238649157361671','customerOwnerInfo','负责人信息','DIVIDER',_binary '',11,'admin',1780392066358,'admin',1780392066358),('384238649157361818','384238649157361671','customerOwner','负责人','MEMBER',_binary '',12,'admin',1780392066358,'admin',1780392066358),('384238649157361819','384238649157361683','orderBasicInfo','基本信息','DIVIDER',_binary '',1,'admin',1780392066358,'admin',1780392066358),('384238649157361820','384238649157361683','orderNo','订单编号','SERIAL_NUMBER',_binary '',2,'admin',1780392066358,'admin',1780392066358),('384238649157361821','384238649157361683','orderCustomer','关联客户','DATA_SOURCE',_binary '',3,'admin',1780392066358,'admin',1780392066358),('384238649157361822','384238649157361683','orderContract','关联合同','DATA_SOURCE',_binary '',4,'admin',1780392066358,'admin',1780392066358),('384238649157361823','384238649157361683','orderName','订单名称','INPUT',_binary '',5,'admin',1780392066358,'admin',1780392066358),('384238649157361824','384238649157361683','orderOwner','负责人','MEMBER',_binary '',6,'admin',1780392066358,'admin',1780392066358),('384238649157361825','384238649157361683','orderProductInfo','销售产品信息','DIVIDER',_binary '',7,'admin',1780392066358,'admin',1780392066358),('384238649157361826','384238649157361683','orderProducts','产品明细','SUB_PRODUCT',_binary '',8,'admin',1780392066358,'admin',1780392066358),('384238649157361831','384238649157361683','orderAmount','订单金额','FORMULA',_binary '',9,'admin',1780392066358,'admin',1780392066358),('384238649157361832','384238649157361683','orderReceivedInfo','订单收货信息','DIVIDER',_binary '',10,'admin',1780392066358,'admin',1780392066358),('384238649157361833','384238649157361683','orderDeliveryAddress','收货地址','LOCATION',_binary '',11,'admin',1780392066358,'admin',1780392066358),('384238649157361834','384238649157361683','orderConsignee','收货人','INPUT',_binary '',12,'admin',1780392066358,'admin',1780392066358),('384238649157361835','384238649157361683','orderPhone','收货人联系方式','PHONE',_binary '',13,'admin',1780392066358,'admin',1780392066358),('384238649157361836','384238649157361681','contractPaymentPlanName','回款计划名称','INPUT',_binary '',1,'admin',1780392066546,'admin',1780392066546),('384238649157361837','384238649157361679','contractStartTime','合同开始时间','DATE_TIME',_binary '',7,'admin',1780392066548,'admin',1780392066548),('384238649157361838','384238649157361679','contractEndTime','合同结束时间','DATE_TIME',_binary '',8,'admin',1780392066548,'admin',1780392066548),('384238649157361839','384238649157361678','quotationTotalAmount','累计金额','FORMULA',_binary '',8,'admin',1780392066556,'admin',1780392066556),('384238649157361840','384238649157361679','contractTotalAmount','累计金额','FORMULA',_binary '',9,'admin',1780392066558,'admin',1780392066558);
/*!40000 ALTER TABLE `sys_module_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_module_field_blob`
--

DROP TABLE IF EXISTS `sys_module_field_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_module_field_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `prop` longtext COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='模块字段属性配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_module_field_blob`
--

LOCK TABLES `sys_module_field_blob` WRITE;
/*!40000 ALTER TABLE `sys_module_field_blob` DISABLE KEYS */;
INSERT INTO `sys_module_field_blob` VALUES ('384238649157361684','{\"name\":\"基本信息\",\"internalKey\":\"contractPaymentRecordBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361684\",\"mobile\":true}'),('384238649157361685','{\"name\":\"回款记录名称\",\"internalKey\":\"contractPaymentRecordName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361685\"}'),('384238649157361686','{\"name\":\"回款编码\",\"internalKey\":\"contractPaymentRecordNo\",\"type\":\"SERIAL_NUMBER\",\"placeholder\":\"无需录入, 自动生成\",\"showLabel\":true,\"serialNumberRules\":[\"PAY\",\"-\",\"yyyyMM\",\"-\",\"6\"],\"rules\":[{\"key\":\"required\"}],\"readable\":true,\"editable\":false,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361686\"}'),('384238649157361687','{\"name\":\"合同名称\",\"internalKey\":\"contractPaymentRecordContract\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CONTRACT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361687\"}'),('384238649157361688','{\"name\":\"回款计划\",\"internalKey\":\"contractPaymentRecordPlan\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"PAYMENT_PLAN\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361688\"}'),('384238649157361689','{\"name\":\"负责人\",\"internalKey\":\"contractPaymentRecordOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361689\"}'),('384238649157361690','{\"name\":\"回款信息\",\"internalKey\":\"contractPaymentRecordInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361690\",\"mobile\":true}'),('384238649157361691','{\"id\":\"384238649157361691\",\"name\":\"回款时间\",\"internalKey\":\"contractPaymentRecordEndTime\",\"pos\":null,\"type\":\"DATE_TIME\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dateType\":\"date\",\"dateDefaultType\":\"custom\",\"defaultValue\":null}'),('384238649157361692','{\"name\":\"回款金额\",\"internalKey\":\"contractPaymentRecordAmount\",\"type\":\"INPUT_NUMBER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"numberFormat\":\"number\",\"decimalPlaces\":true,\"precision\":2,\"showThousandsSeparator\":true,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361692\"}'),('384238649157361693','{\"id\":\"384238649157361693\",\"name\":\"收款银行\",\"internalKey\":\"contractPaymentRecordBank\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"中国银行\"},{\"value\":\"2\",\"label\":\"中国农业银行\"},{\"value\":\"3\",\"label\":\"中国工商银行\"},{\"value\":\"4\",\"label\":\"中国建设银行\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361694','{\"id\":\"384238649157361694\",\"name\":\"收款银行账号\",\"internalKey\":\"contractPaymentRecordBankNo\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"银行账号1\"},{\"value\":\"2\",\"label\":\"银行账号2\"},{\"value\":\"3\",\"label\":\"银行账号3\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361695','{\"name\":\"基本信息\",\"internalKey\":\"productBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361695\",\"mobile\":true}'),('384238649157361696','{\"name\":\"产品名称\",\"internalKey\":\"productName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"},{\"key\":\"unique\"}],\"id\":\"384238649157361696\",\"mobile\":true}'),('384238649157361697','{\"name\":\"产品价格\",\"internalKey\":\"productPrice\",\"type\":\"INPUT_NUMBER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"numberFormat\":\"number\",\"showThousandsSeparator\":true,\"id\":\"384238649157361697\",\"mobile\":true}'),('384238649157361698','{\"id\":\"384238649157361698\",\"name\":\"状态\",\"internalKey\":\"productStatus\",\"pos\":null,\"type\":\"RADIO\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"options\":[{\"value\":\"1\",\"label\":\"上架\"},{\"value\":\"2\",\"label\":\"下架\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"defaultValue\":\"1\",\"direction\":\"horizontal\",\"linkProp\":null}'),('384238649157361699','{\"name\":\"描述\",\"internalKey\":\"productDescription\",\"type\":\"TEXTAREA\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361699\",\"mobile\":true}'),('384238649157361700','{\"name\":\"图片信息\",\"internalKey\":\"productPicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361700\",\"mobile\":true}'),('384238649157361701','{\"name\":\"产品图片\",\"internalKey\":\"productPic\",\"type\":\"PICTURE\",\"pictureShowType\":\"card\",\"uploadSizeLimitEnable\":true,\"uploadSizeLimit\":20,\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361701\",\"mobile\":true}'),('384238649157361702','{\"name\":\"合同\",\"internalKey\":\"contractPaymentPlanContract\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CONTRACT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361702\"}'),('384238649157361703','{\"name\":\"负责人\",\"internalKey\":\"contractPaymentPlanOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361703\"}'),('384238649157361704','{\"name\":\"计划回款金额\",\"internalKey\":\"contractPaymentPlanPlanAmount\",\"type\":\"INPUT_NUMBER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"numberFormat\":\"number\",\"showThousandsSeparator\":true,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361704\"}'),('384238649157361705','{\"id\":\"384238649157361705\",\"name\":\"计划回款时间\",\"internalKey\":\"contractPaymentPlanPlanEndTime\",\"pos\":null,\"type\":\"DATE_TIME\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dateType\":\"date\",\"dateDefaultType\":\"custom\",\"defaultValue\":null}'),('384238649157361706','{\"name\":\"基本信息\",\"internalKey\":\"contractBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361706\",\"mobile\":true}'),('384238649157361707','{\"name\":\"合同\",\"internalKey\":\"contractName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"rules\":[{\"key\":\"required\"},{\"key\":\"unique\"}],\"id\":\"384238649157361707\"}'),('384238649157361708','{\"name\":\"客户名称\",\"internalKey\":\"contractCustomer\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CUSTOMER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361708\"}'),('384238649157361709','{\"name\":\"合同编号\",\"internalKey\":\"contractNo\",\"type\":\"SERIAL_NUMBER\",\"placeholder\":\"无需录入, 自动生成\",\"showLabel\":true,\"serialNumberRules\":[\"Con\",\"-\",\"yyyyMM\",\"-\",\"6\"],\"readable\":true,\"editable\":false,\"fieldWidth\":1,\"mobile\":true,\"disableProps\":[\"serialNumberRules\"],\"id\":\"384238649157361709\"}'),('384238649157361710','{\"id\":\"384238649157361710\",\"name\":\"合同报价信息\",\"internalKey\":\"contractProducts\",\"pos\":null,\"type\":\"SUB_PRODUCT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"fixedColumn\":1,\"subFields\":[{\"id\":\"384238649157361711\",\"name\":\"产品\",\"internalKey\":\"contractProduct\",\"pos\":null,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"PRODUCT\",\"combineSearch\":null,\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null},{\"id\":\"384238649157361712\",\"name\":\"产品单价\",\"internalKey\":\"contractProductAmount\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"number\",\"decimalPlaces\":true,\"precision\":2,\"showThousandsSeparator\":true},{\"id\":\"384238649157361713\",\"name\":\"数量\",\"internalKey\":\"contractProductNumber\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"number\",\"decimalPlaces\":null,\"precision\":0,\"showThousandsSeparator\":null},{\"id\":\"384238649157361714\",\"name\":\"金额\",\"internalKey\":\"contractProductSumAmount\",\"pos\":null,\"type\":\"FORMULA\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":false,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"formula\":null,\"showThousandsSeparator\":true}],\"sumColumns\":[\"384238649157361714\"]}'),('384238649157361715','{\"name\":\"负责人\",\"internalKey\":\"contractOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"mobile\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361715\"}'),('384238649157361716','{\"name\":\"基本信息\",\"internalKey\":\"opportunityBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361716\",\"mobile\":true}'),('384238649157361717','{\"name\":\"商机名称\",\"internalKey\":\"opportunityName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361717\"}'),('384238649157361718','{\"name\":\"客户名称\",\"internalKey\":\"opportunityCustomer\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CUSTOMER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361718\"}'),('384238649157361719','{\"name\":\"业务编码\",\"internalKey\":\"opportunityNo\",\"type\":\"SERIAL_NUMBER\",\"placeholder\":\"无需录入, 自动生成\",\"showLabel\":true,\"serialNumberRules\":[\"Opp\",\"-\",\"yyyyMM\",\"-\",\"6\"],\"readable\":true,\"editable\":false,\"fieldWidth\":1,\"disableProps\":[\"serialNumberRules\"],\"id\":\"384238649157361719\",\"mobile\":true}'),('384238649157361720','{\"id\":\"384238649157361720\",\"name\":\"商机来源\",\"internalKey\":\"opportunitySource\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"电话营销\"},{\"value\":\"2\",\"label\":\"客户介绍\"},{\"value\":\"3\",\"label\":\"线下活动\"},{\"value\":\"4\",\"label\":\"社区用户\"},{\"value\":\"5\",\"label\":\"Github\"},{\"value\":\"6\",\"label\":\"维保，续约，增购\"},{\"value\":\"7\",\"label\":\"其他\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361721','{\"name\":\"金额\",\"internalKey\":\"opportunityPrice\",\"type\":\"INPUT_NUMBER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"numberFormat\":\"number\",\"showThousandsSeparator\":true,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361721\"}'),('384238649157361722','{\"name\":\"意向产品\",\"internalKey\":\"opportunityProduct\",\"type\":\"DATA_SOURCE_MULTIPLE\",\"dataSourceType\":\"PRODUCT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361722\"}'),('384238649157361723','{\"id\":\"384238649157361723\",\"name\":\"结束时间\",\"internalKey\":\"opportunityEndTime\",\"pos\":null,\"type\":\"DATE_TIME\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dateType\":\"date\",\"dateDefaultType\":\"custom\",\"defaultValue\":null}'),('384238649157361724','{\"name\":\"可能性\",\"internalKey\":\"opportunityWinRate\",\"type\":\"INPUT_NUMBER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"numberFormat\":\"percent\",\"showThousandsSeparator\":true,\"id\":\"384238649157361724\",\"mobile\":true}'),('384238649157361725','{\"name\":\"联系人\",\"internalKey\":\"opportunityContact\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CONTACT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361725\"}'),('384238649157361726','{\"name\":\"客户标签\",\"internalKey\":\"opportunityCustomerTag\",\"type\":\"INPUT_MULTIPLE\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361726\",\"mobile\":true}'),('384238649157361727','{\"name\":\"备注信息\",\"internalKey\":\"opportunityRemark\",\"type\":\"TEXTAREA\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361727\",\"mobile\":true}'),('384238649157361728','{\"name\":\"地址信息\",\"internalKey\":\"opportunityAddressInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361728\",\"mobile\":true}'),('384238649157361729','{\"name\":\"地区\",\"internalKey\":\"opportunityArea\",\"type\":\"LOCATION\",\"locationType\":\"detail\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361729\",\"mobile\":true}'),('384238649157361730','{\"name\":\"负责人信息\",\"internalKey\":\"opportunityOwnerInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361730\",\"mobile\":true}'),('384238649157361731','{\"name\":\"负责人\",\"internalKey\":\"opportunityOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361731\",\"mobile\":true}'),('384238649157361732','{\"name\":\"基本信息\",\"internalKey\":\"priceBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361732\",\"mobile\":true}'),('384238649157361733','{\"name\":\"价格表名称\",\"internalKey\":\"priceName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"},{\"key\":\"unique\"}],\"mobile\":true,\"id\":\"384238649157361733\"}'),('384238649157361734','{\"id\":\"384238649157361734\",\"name\":\"状态\",\"internalKey\":\"priceStatus\",\"pos\":null,\"type\":\"RADIO\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"options\":[{\"value\":\"1\",\"label\":\"启用\"},{\"value\":\"2\",\"label\":\"禁用\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"defaultValue\":\"1\",\"direction\":\"horizontal\",\"linkProp\":null}'),('384238649157361735','{\"id\":\"384238649157361735\",\"name\":\"产品信息\",\"internalKey\":\"priceProducts\",\"pos\":null,\"type\":\"SUB_PRODUCT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"fixedColumn\":1,\"subFields\":[{\"id\":\"384238649157361736\",\"name\":\"产品\",\"internalKey\":\"priceProduct\",\"pos\":null,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"PRODUCT\",\"combineSearch\":null,\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null},{\"id\":\"384238649157361737\",\"name\":\"产品SKU\",\"internalKey\":\"priceProductSku\",\"pos\":null,\"type\":\"INPUT\",\"mobile\":null,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"defaultValueType\":null,\"formula\":null},{\"id\":\"384238649157361738\",\"name\":\"产品定价\",\"internalKey\":\"priceProductAmount\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"number\",\"decimalPlaces\":true,\"precision\":2,\"showThousandsSeparator\":true},{\"id\":\"384238649157361739\",\"name\":\"税点\",\"internalKey\":\"priceProductTax\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":null,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"percent\",\"decimalPlaces\":true,\"precision\":2,\"showThousandsSeparator\":null},{\"id\":\"384238649157361740\",\"name\":\"重要说明\",\"internalKey\":\"priceProductSku\",\"pos\":null,\"type\":\"INPUT\",\"mobile\":null,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"defaultValueType\":null,\"formula\":null}],\"sumColumns\":null}'),('384238649157361741','{\"name\":\"备注\",\"internalKey\":\"priceRemark\",\"type\":\"TEXTAREA\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361741\"}'),('384238649157361742','{\"name\":\"基本信息\",\"internalKey\":\"clueBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361742\",\"mobile\":true}'),('384238649157361743','{\"name\":\"公司名称\",\"internalKey\":\"clueName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361743\"}'),('384238649157361744','{\"id\":\"384238649157361744\",\"name\":\"线索进度\",\"internalKey\":\"clueProgress\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"初步意向\"},{\"value\":\"2\",\"label\":\"强烈意愿\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361745','{\"id\":\"384238649157361745\",\"name\":\"线索来源\",\"internalKey\":\"clueSource\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":[{\"value\":\"1\",\"fieldIds\":[\"384238649157361746\"]}],\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"线上\"},{\"value\":\"2\",\"label\":\"电话影响\"},{\"value\":\"3\",\"label\":\"客户介绍\"},{\"value\":\"4\",\"label\":\"线下活动\"},{\"value\":\"5\",\"label\":\"社区用户\"},{\"value\":\"6\",\"label\":\"GitHub\"},{\"value\":\"7\",\"label\":\"维保，续约，增购\"},{\"value\":\"8\",\"label\":\"其他\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361746','{\"id\":\"384238649157361746\",\"name\":\"线上来源详情\",\"internalKey\":\"clueOnlineSource\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"400电话\"},{\"value\":\"2\",\"label\":\"官网咨询\"},{\"value\":\"3\",\"label\":\"社区用户\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361747','{\"name\":\"客户需求\",\"internalKey\":\"clueDemand\",\"type\":\"TEXTAREA\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361747\",\"mobile\":true}'),('384238649157361748','{\"name\":\"联系人名称\",\"internalKey\":\"clueContactName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361748\"}'),('384238649157361749','{\"name\":\"联系人电话\",\"internalKey\":\"clueContactPhone\",\"type\":\"PHONE\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"format\":\"255\",\"rules\":[{\"key\":\"unique\"}],\"id\":\"384238649157361749\"}'),('384238649157361750','{\"name\":\"意向产品\",\"internalKey\":\"clueProduct\",\"type\":\"DATA_SOURCE_MULTIPLE\",\"dataSourceType\":\"PRODUCT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361750\"}'),('384238649157361751','{\"name\":\"地址信息\",\"internalKey\":\"clueAddressInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361751\",\"mobile\":true}'),('384238649157361752','{\"name\":\"地区\",\"internalKey\":\"clueArea\",\"type\":\"LOCATION\",\"locationType\":\"detail\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361752\",\"mobile\":true}'),('384238649157361753','{\"name\":\"负责人信息\",\"internalKey\":\"clueOwnerInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361753\",\"mobile\":true}'),('384238649157361754','{\"name\":\"负责人\",\"internalKey\":\"clueOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361754\",\"mobile\":true}'),('384238649157361755','{\"id\":\"384238649157361755\",\"name\":\"客户名称\",\"internalKey\":\"contactCustomer\",\"pos\":0,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"customerId\",\"disabledProps\":[],\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"CUSTOMER\",\"combineSearch\":null,\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null}'),('384238649157361756','{\"id\":\"384238649157361756\",\"name\":\"姓名\",\"internalKey\":\"contactName\",\"pos\":1,\"type\":\"INPUT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"name\",\"disabledProps\":[\"readable\",\"mobile\",\"rules.required\"],\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"defaultValueType\":\"custom\",\"formula\":null}'),('384238649157361757','{\"id\":\"384238649157361757\",\"name\":\"邮箱\",\"internalKey\":\"contactEmail\",\"pos\":2,\"type\":\"INPUT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"unique\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"defaultValueType\":\"custom\",\"formula\":null}'),('384238649157361758','{\"id\":\"384238649157361758\",\"name\":\"手机号\",\"internalKey\":\"contactPhone\",\"pos\":3,\"type\":\"PHONE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"unique\"}],\"showControlRules\":null,\"businessKey\":\"phone\",\"disabledProps\":[],\"resourceFieldId\":null,\"subTableFieldId\":null,\"format\":\"255\"}'),('384238649157361759','{\"id\":\"384238649157361759\",\"name\":\"负责人\",\"internalKey\":\"contactOwner\",\"pos\":4,\"type\":\"MEMBER\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"owner\",\"disabledProps\":[\"readable\",\"mobile\",\"rules.required\"],\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"hasCurrentUser\":true,\"initialOptions\":[]}'),('384238649157361760','{\"id\":\"384238649157361760\",\"name\":\"跟进类型\",\"internalKey\":\"recordType\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":[{\"value\":\"CUSTOMER\",\"fieldIds\":[\"384238649157361761\",\"384238649157361762\",\"384238649157361763\"]},{\"value\":\"CLUE\",\"fieldIds\":[\"384238649157361764\"]}],\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"CUSTOMER\",\"label\":\"客户\"},{\"value\":\"CLUE\",\"label\":\"线索\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361761','{\"name\":\"客户名称\",\"internalKey\":\"recordCustomer\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CUSTOMER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361761\"}'),('384238649157361762','{\"name\":\"商机\",\"internalKey\":\"recordOpportunity\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"OPPORTUNITY\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361762\"}'),('384238649157361763','{\"name\":\"联系人\",\"internalKey\":\"recordContact\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CONTACT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361763\"}'),('384238649157361764','{\"name\":\"公司名称\",\"internalKey\":\"recordClue\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CLUE\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361764\"}'),('384238649157361765','{\"id\":\"384238649157361765\",\"name\":\"跟进方式\",\"internalKey\":\"recordMethod\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"到访\"},{\"value\":\"2\",\"label\":\"电话\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361766','{\"id\":\"384238649157361766\",\"name\":\"跟进时间\",\"internalKey\":\"recordTime\",\"pos\":null,\"type\":\"DATE_TIME\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dateType\":\"date\",\"dateDefaultType\":\"custom\",\"defaultValue\":null}'),('384238649157361767','{\"name\":\"负责人\",\"internalKey\":\"recordOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361767\"}'),('384238649157361768','{\"name\":\"意向产品\",\"internalKey\":\"recordProduct\",\"type\":\"DATA_SOURCE_MULTIPLE\",\"dataSourceType\":\"PRODUCT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361768\",\"mobile\":true}'),('384238649157361769','{\"name\":\"跟进内容\",\"internalKey\":\"recordDescription\",\"type\":\"TEXTAREA\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361769\"}'),('384238649157361770','{\"name\":\"基本信息\",\"internalKey\":\"invoiceBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361770\",\"mobile\":true}'),('384238649157361771','{\"name\":\"发票名称\",\"internalKey\":\"invoiceName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361771\"}'),('384238649157361772','{\"name\":\"合同信息\",\"internalKey\":\"invoiceContractBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361772\",\"mobile\":true}'),('384238649157361773','{\"id\":\"384238649157361773\",\"name\":\"合同名称\",\"internalKey\":\"invoiceContract\",\"pos\":null,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"CONTRACT\",\"combineSearch\":null,\"showFields\":[\"384238649157361708\",\"384238649157361709\",\"384238649157361840\"],\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null}'),('384238649157361774','{\"name\":\"发票信息\",\"internalKey\":\"invoiceBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361774\",\"mobile\":true}'),('384238649157361775','{\"id\":\"384238649157361775\",\"name\":\"开票类型\",\"internalKey\":\"invoiceType\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"专票\"},{\"value\":\"2\",\"label\":\"普票\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361776','{\"id\":\"384238649157361776\",\"name\":\"开票项目名称\",\"internalKey\":\"invoiceProjectName\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"产品1\"},{\"value\":\"2\",\"label\":\"产品2\"},{\"value\":\"3\",\"label\":\"产品3\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361777','{\"id\":\"384238649157361777\",\"name\":\"规格型号\",\"internalKey\":\"invoiceSpecification\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"sku1\"},{\"value\":\"2\",\"label\":\"sku2\"},{\"value\":\"3\",\"label\":\"sku3\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361778','{\"id\":\"384238649157361778\",\"name\":\"单位\",\"internalKey\":\"invoiceUnit\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"个\"},{\"value\":\"2\",\"label\":\"套\"},{\"value\":\"3\",\"label\":\"年\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361779','{\"name\":\"数量\",\"internalKey\":\"invoiceQuantity\",\"type\":\"INPUT_NUMBER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"numberFormat\":\"number\",\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361779\"}'),('384238649157361780','{\"name\":\"税率\",\"internalKey\":\"invoiceTaxRate\",\"type\":\"INPUT_NUMBER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"mobile\":true,\"fieldWidth\":1,\"numberFormat\":\"percent\",\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361780\"}'),('384238649157361781','{\"name\":\"工商抬头\",\"internalKey\":\"invoiceBusinessTitle\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"BUSINESS_TITLE\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"mobile\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"showFields\":[\"identificationNumber\"],\"id\":\"384238649157361781\"}'),('384238649157361782','{\"name\":\"发票金额\",\"internalKey\":\"invoiceAmount\",\"type\":\"INPUT_NUMBER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"numberFormat\":\"number\",\"showThousandsSeparator\":true,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361782\"}'),('384238649157361783','{\"name\":\"负责人\",\"internalKey\":\"invoiceOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"mobile\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361783\"}'),('384238649157361784','{\"id\":\"384238649157361784\",\"name\":\"跟进类型\",\"internalKey\":\"planType\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":[{\"value\":\"CUSTOMER\",\"fieldIds\":[\"384238649157361785\",\"384238649157361786\",\"384238649157361787\"]},{\"value\":\"CLUE\",\"fieldIds\":[\"384238649157361788\"]}],\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"CUSTOMER\",\"label\":\"客户\"},{\"value\":\"CLUE\",\"label\":\"线索\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361785','{\"name\":\"客户名称\",\"internalKey\":\"planCustomer\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CUSTOMER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361785\"}'),('384238649157361786','{\"name\":\"商机\",\"internalKey\":\"planOpportunity\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"OPPORTUNITY\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361786\"}'),('384238649157361787','{\"name\":\"联系人\",\"internalKey\":\"planContact\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CONTACT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361787\"}'),('384238649157361788','{\"name\":\"公司名称\",\"internalKey\":\"planClue\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CLUE\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361788\"}'),('384238649157361789','{\"id\":\"384238649157361789\",\"name\":\"预计开始时间\",\"internalKey\":\"planStartTime\",\"pos\":null,\"type\":\"DATE_TIME\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dateType\":\"date\",\"dateDefaultType\":\"custom\",\"defaultValue\":null}'),('384238649157361790','{\"id\":\"384238649157361790\",\"name\":\"跟进方式\",\"internalKey\":\"planMethod\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"到访\"},{\"value\":\"2\",\"label\":\"电话\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361791','{\"name\":\"负责人\",\"internalKey\":\"planOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361791\",\"mobile\":true}'),('384238649157361792','{\"name\":\"意向产品\",\"internalKey\":\"planProduct\",\"type\":\"DATA_SOURCE_MULTIPLE\",\"dataSourceType\":\"PRODUCT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361792\",\"mobile\":true}'),('384238649157361793','{\"name\":\"预计沟通内容\",\"internalKey\":\"planContent\",\"type\":\"TEXTAREA\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361793\"}'),('384238649157361794','{\"name\":\"基本信息\",\"internalKey\":\"quotationBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361794\",\"mobile\":true}'),('384238649157361795','{\"name\":\"报价\",\"internalKey\":\"quotationName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"},{\"key\":\"unique\"}],\"mobile\":true,\"id\":\"384238649157361795\"}'),('384238649157361796','{\"name\":\"商机\",\"internalKey\":\"quotationOpportunity\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"OPPORTUNITY\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361796\"}'),('384238649157361797','{\"name\":\"联系人\",\"internalKey\":\"quotationContact\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CONTACT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361797\"}'),('384238649157361798','{\"id\":\"384238649157361798\",\"name\":\"报价日期\",\"internalKey\":\"quotationTime\",\"pos\":null,\"type\":\"DATE_TIME\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dateType\":\"date\",\"dateDefaultType\":\"custom\",\"defaultValue\":null}'),('384238649157361799','{\"id\":\"384238649157361799\",\"name\":\"有效期至\",\"internalKey\":\"quotationUntilTime\",\"pos\":null,\"type\":\"DATE_TIME\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dateType\":\"date\",\"dateDefaultType\":\"custom\",\"defaultValue\":null}'),('384238649157361800','{\"id\":\"384238649157361800\",\"name\":\"报价产品\",\"internalKey\":\"quotationProducts\",\"pos\":null,\"type\":\"SUB_PRICE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"fixedColumn\":1,\"subFields\":[{\"id\":\"384238649157361801\",\"name\":\"产品\",\"internalKey\":\"quotationProduct\",\"pos\":null,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":[\"rules.required\",\"dataSourceType\"],\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"PRODUCT\",\"combineSearch\":null,\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null},{\"id\":\"384238649157361802\",\"name\":\"价格表\",\"internalKey\":\"quotationPrice\",\"pos\":null,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":[\"dataSourceType\"],\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"PRICE\",\"combineSearch\":null,\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null},{\"id\":\"384238649157361803\",\"name\":\"产品定价\",\"internalKey\":\"quotationProductAmount\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":null,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"number\",\"decimalPlaces\":true,\"precision\":2,\"showThousandsSeparator\":true},{\"id\":\"384238649157361804\",\"name\":\"折扣\",\"internalKey\":\"quotationDiscount\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":null,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"number\",\"decimalPlaces\":true,\"precision\":2,\"showThousandsSeparator\":null},{\"id\":\"384238649157361805\",\"name\":\"税点\",\"internalKey\":\"quotationTax\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":null,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"percent\",\"decimalPlaces\":true,\"precision\":2,\"showThousandsSeparator\":null},{\"id\":\"384238649157361806\",\"name\":\"金额\",\"internalKey\":\"quotationAmount\",\"pos\":null,\"type\":\"FORMULA\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":false,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"formula\":null,\"showThousandsSeparator\":true}],\"sumColumns\":[\"384238649157361806\"]}'),('384238649157361807','{\"name\":\"基本信息\",\"internalKey\":\"customerBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361807\",\"mobile\":true}'),('384238649157361808','{\"name\":\"客户名称\",\"internalKey\":\"customerName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"},{\"key\":\"unique\"}],\"mobile\":true,\"id\":\"384238649157361808\"}'),('384238649157361809','{\"id\":\"384238649157361809\",\"name\":\"客户行业\",\"internalKey\":\"customerIndustry\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"互联网\"},{\"value\":\"2\",\"label\":\"金融\"},{\"value\":\"3\",\"label\":\"制造业\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361810','{\"id\":\"384238649157361810\",\"name\":\"客户等级\",\"internalKey\":\"customerLevel\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":\"1\",\"options\":[{\"value\":\"1\",\"label\":\"重要客户\"},{\"value\":\"2\",\"label\":\"一般客户\"},{\"value\":\"3\",\"label\":\"战略客户\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361811','{\"id\":\"384238649157361811\",\"name\":\"客户类型\",\"internalKey\":\"customerType\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"无\"},{\"value\":\"2\",\"label\":\"最终客户\"},{\"value\":\"3\",\"label\":\"代理商\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361812','{\"id\":\"384238649157361812\",\"name\":\"客户来源\",\"internalKey\":\"customerSource\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":[{\"value\":\"1\",\"fieldIds\":[\"384238649157361813\"]}],\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"线上\"},{\"value\":\"2\",\"label\":\"线下\"},{\"value\":\"3\",\"label\":\"维保\"},{\"value\":\"4\",\"label\":\"续约\"},{\"value\":\"5\",\"label\":\"扩容\"},{\"value\":\"6\",\"label\":\"增购\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361813','{\"id\":\"384238649157361813\",\"name\":\"线上来源详情\",\"internalKey\":\"customerOnlineSource\",\"pos\":null,\"type\":\"SELECT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"options\":[{\"value\":\"1\",\"label\":\"400电话\"},{\"value\":\"2\",\"label\":\"官网咨询\"},{\"value\":\"3\",\"label\":\"社区用户\"}],\"customOptions\":null,\"optionSource\":\"custom\",\"refId\":null,\"refFormKey\":null,\"linkProp\":null}'),('384238649157361814','{\"name\":\"客户标签\",\"internalKey\":\"customerTag\",\"type\":\"INPUT_MULTIPLE\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361814\",\"mobile\":true}'),('384238649157361815','{\"name\":\"地址信息\",\"internalKey\":\"customerAddressInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361815\",\"mobile\":true}'),('384238649157361816','{\"name\":\"地区\",\"internalKey\":\"customerArea\",\"type\":\"LOCATION\",\"locationType\":\"detail\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361816\",\"mobile\":true}'),('384238649157361817','{\"name\":\"负责人信息\",\"internalKey\":\"customerOwnerInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361817\",\"mobile\":true}'),('384238649157361818','{\"name\":\"负责人\",\"internalKey\":\"customerOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361818\",\"mobile\":true}'),('384238649157361819','{\"name\":\"基本信息\",\"internalKey\":\"orderBasicInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361819\",\"mobile\":true}'),('384238649157361820','{\"name\":\"订单编号\",\"internalKey\":\"orderNo\",\"type\":\"SERIAL_NUMBER\",\"placeholder\":\"无需录入, 自动生成\",\"showLabel\":true,\"serialNumberRules\":[\"XSDD\",\"-\",\"yyyyMM\",\"-\",\"6\"],\"readable\":true,\"editable\":false,\"fieldWidth\":1,\"mobile\":true,\"disableProps\":[\"serialNumberRules\"],\"id\":\"384238649157361820\"}'),('384238649157361821','{\"name\":\"关联客户\",\"internalKey\":\"orderCustomer\",\"type\":\"DATA_SOURCE\",\"dataSourceType\":\"CUSTOMER\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"id\":\"384238649157361821\"}'),('384238649157361822','{\"id\":\"384238649157361822\",\"name\":\"关联合同\",\"internalKey\":\"orderContract\",\"pos\":null,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"CONTRACT\",\"combineSearch\":{\"searchMode\":\"OR\",\"conditions\":[{\"leftFieldId\":\"customerId\",\"leftFieldType\":\"DATA_SOURCE\",\"operator\":\"IN\",\"rightFieldId\":\"384238649157361821\",\"rightFieldCustom\":false,\"rightFieldCustomValue\":\"\",\"rightFieldType\":\"INPUT\"}]},\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null}'),('384238649157361823','{\"name\":\"订单名称\",\"internalKey\":\"orderName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"rules\":[{\"key\":\"required\"},{\"key\":\"unique\"}],\"id\":\"384238649157361823\"}'),('384238649157361824','{\"name\":\"负责人\",\"internalKey\":\"orderOwner\",\"type\":\"MEMBER\",\"hasCurrentUser\":true,\"showLabel\":true,\"readable\":true,\"editable\":true,\"mobile\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"id\":\"384238649157361824\"}'),('384238649157361825','{\"name\":\"销售产品信息\",\"internalKey\":\"orderProductInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361825\",\"mobile\":true}'),('384238649157361826','{\"id\":\"384238649157361826\",\"name\":\"产品明细\",\"internalKey\":\"orderProducts\",\"pos\":null,\"type\":\"SUB_PRODUCT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"fixedColumn\":1,\"subFields\":[{\"id\":\"384238649157361827\",\"name\":\"产品名称\",\"internalKey\":\"orderProduct\",\"pos\":null,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"PRODUCT\",\"combineSearch\":null,\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null},{\"id\":\"384238649157361828\",\"name\":\"产品单价\",\"internalKey\":\"orderProductPrice\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"number\",\"decimalPlaces\":true,\"precision\":2,\"showThousandsSeparator\":true},{\"id\":\"384238649157361829\",\"name\":\"数量\",\"internalKey\":\"orderProductNumber\",\"pos\":null,\"type\":\"INPUT_NUMBER\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"min\":null,\"max\":null,\"numberFormat\":\"number\",\"decimalPlaces\":null,\"precision\":0,\"showThousandsSeparator\":null},{\"id\":\"384238649157361830\",\"name\":\"金额\",\"internalKey\":\"orderProductAmount\",\"pos\":null,\"type\":\"FORMULA\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":false,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"formula\":\"{\\n     \\\"source\\\": \\\"${384238649157361828} * ${384238649157361829}\\\",\\n     \\\"display\\\": \\\"产品单价 * 数量\\\",\\n     \\\"fields\\\": [\\n         {\\n             \\\"fieldId\\\": \\\"384238649157361828\\\",\\n             \\\"fieldType\\\": \\\"INPUT_NUMBER\\\",\\n             \\\"numberType\\\": \\\"number\\\"\\n         },\\n         {\\n             \\\"fieldId\\\": \\\"384238649157361829\\\",\\n             \\\"fieldType\\\": \\\"INPUT_NUMBER\\\",\\n             \\\"numberType\\\": \\\"number\\\"\\n         }\\n     ],\\n     \\\"ir\\\": {\\n         \\\"type\\\": \\\"binary\\\",\\n         \\\"operator\\\": \\\"*\\\",\\n         \\\"left\\\": {\\n             \\\"type\\\": \\\"field\\\",\\n             \\\"fieldId\\\": \\\"384238649157361828\\\",\\n             \\\"name\\\": \\\"产品单价\\\",\\n             \\\"fieldType\\\": \\\"INPUT_NUMBER\\\",\\n             \\\"numberType\\\": \\\"number\\\",\\n             \\\"startTokenIndex\\\": 0,\\n             \\\"endTokenIndex\\\": 0\\n         },\\n         \\\"right\\\": {\\n             \\\"type\\\": \\\"field\\\",\\n             \\\"fieldId\\\": \\\"384238649157361829\\\",\\n             \\\"name\\\": \\\"数量\\\",\\n             \\\"fieldType\\\": \\\"INPUT_NUMBER\\\",\\n             \\\"numberType\\\": \\\"number\\\",\\n             \\\"startTokenIndex\\\": 2,\\n             \\\"endTokenIndex\\\": 2\\n         }\\n     }\\n }\",\"showThousandsSeparator\":true}],\"sumColumns\":[]}'),('384238649157361831','{\"id\":\"384238649157361831\",\"name\":\"订单金额\",\"internalKey\":\"orderAmount\",\"pos\":null,\"type\":\"FORMULA\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":false,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"formula\":\"{\\n    \\\"source\\\": \\\"SUM(${384238649157361826.384238649157361830})\\\",\\n    \\\"display\\\": \\\"SUM(产品明细.金额)\\\",\\n    \\\"fields\\\": [\\n        {\\n            \\\"fieldId\\\": \\\"384238649157361826.384238649157361830\\\",\\n            \\\"fieldType\\\": \\\"FORMULA\\\",\\n            \\\"numberType\\\": \\\"number\\\"\\n        }\\n    ],\\n    \\\"ir\\\": {\\n        \\\"type\\\": \\\"function\\\",\\n        \\\"name\\\": \\\"SUM\\\",\\n        \\\"args\\\": [\\n            {\\n                \\\"type\\\": \\\"field\\\",\\n                \\\"fieldId\\\": \\\"384238649157361826.384238649157361830\\\",\\n                \\\"name\\\": \\\"产品明细.金额\\\",\\n                \\\"fieldType\\\": \\\"FORMULA\\\",\\n                \\\"numberType\\\": \\\"number\\\",\\n                \\\"startTokenIndex\\\": 2,\\n                \\\"endTokenIndex\\\": 2\\n            }\\n        ]\\n    }\\n}\",\"showThousandsSeparator\":true}'),('384238649157361832','{\"name\":\"订单收货信息\",\"internalKey\":\"orderReceivedInfo\",\"type\":\"DIVIDER\",\"showLabel\":true,\"readable\":true,\"fieldWidth\":1,\"dividerClass\":\"divider--normal\",\"dividerColor\":\"#edf0f1\",\"titleColor\":\"#323535\",\"id\":\"384238649157361832\",\"mobile\":true}'),('384238649157361833','{\"name\":\"收货地址\",\"internalKey\":\"orderDeliveryAddress\",\"type\":\"LOCATION\",\"locationType\":\"PCD\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"id\":\"384238649157361833\",\"mobile\":true}'),('384238649157361834','{\"name\":\"收货人\",\"internalKey\":\"orderConsignee\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"id\":\"384238649157361834\"}'),('384238649157361835','{\"name\":\"收货人联系方式\",\"internalKey\":\"orderPhone\",\"type\":\"PHONE\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"mobile\":true,\"format\":\"11\",\"id\":\"384238649157361835\"}'),('384238649157361836','{\"name\":\"回款计划名称\",\"internalKey\":\"contractPaymentPlanName\",\"type\":\"INPUT\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"ext_ver\":\"1.5.0\",\"id\":\"384238649157361836\"}'),('384238649157361837','{\"name\":\"合同开始时间\",\"internalKey\":\"contractStartTime\",\"type\":\"DATE_TIME\",\"dateType\":\"date\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"ext_ver\":\"1.5.0\",\"id\":\"384238649157361837\"}'),('384238649157361838','{\"name\":\"合同结束时间\",\"internalKey\":\"contractEndTime\",\"type\":\"DATE_TIME\",\"dateType\":\"date\",\"showLabel\":true,\"readable\":true,\"editable\":true,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"}],\"mobile\":true,\"ext_ver\":\"1.5.0\",\"id\":\"384238649157361838\"}'),('384238649157361839','{\"id\":\"384238649157361839\",\"name\":\"累计金额\",\"internalKey\":\"quotationTotalAmount\",\"pos\":null,\"type\":\"FORMULA\",\"mobile\":true,\"showLabel\":true,\"placeholder\":null,\"description\":null,\"readable\":true,\"editable\":false,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"},{\"key\":\"unique\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"formula\":null,\"showThousandsSeparator\":true}'),('384238649157361840','{\"name\":\"累计金额\",\"internalKey\":\"contractTotalAmount\",\"type\":\"FORMULA\",\"showLabel\":true,\"readable\":true,\"editable\":false,\"fieldWidth\":1,\"rules\":[{\"key\":\"required\"},{\"key\":\"unique\"}],\"mobile\":true,\"showThousandsSeparator\":true,\"ext_ver\":\"1.5.1\",\"id\":\"384238649157361840\"}');
/*!40000 ALTER TABLE `sys_module_field_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_module_form`
--

DROP TABLE IF EXISTS `sys_module_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_module_form` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `form_key` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='模块表单配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_module_form`
--

LOCK TABLES `sys_module_form` WRITE;
/*!40000 ALTER TABLE `sys_module_form` DISABLE KEYS */;
INSERT INTO `sys_module_form` VALUES ('384238649157361670','clue','100001',1780392066292,1780392066292,'admin','admin'),('384238649157361671','customer','100001',1780392066302,1780392066302,'admin','admin'),('384238649157361672','contact','100001',1780392066302,1780557135359,'admin','admin'),('384238649157361673','record','100001',1780392066303,1780392066303,'admin','admin'),('384238649157361674','plan','100001',1780392066303,1780392066303,'admin','admin'),('384238649157361675','opportunity','100001',1780392066303,1780392066303,'admin','admin'),('384238649157361676','product','100001',1780392066303,1780392066303,'admin','admin'),('384238649157361677','price','100001',1780392066303,1780392066303,'admin','admin'),('384238649157361678','quotation','100001',1780392066303,1780392066303,'admin','admin'),('384238649157361679','contract','100001',1780392066303,1780392066303,'admin','admin'),('384238649157361680','invoice','100001',1780392066304,1780392066304,'admin','admin'),('384238649157361681','contractPaymentPlan','100001',1780392066304,1780392066304,'admin','admin'),('384238649157361682','contractPaymentRecord','100001',1780392066304,1780392066304,'admin','admin'),('384238649157361683','order','100001',1780392066304,1780392066304,'admin','admin');
/*!40000 ALTER TABLE `sys_module_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_module_form_blob`
--

DROP TABLE IF EXISTS `sys_module_form_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_module_form_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `prop` text COLLATE utf8mb4_general_ci COMMENT '属性',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='模块表单属性配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_module_form_blob`
--

LOCK TABLES `sys_module_form_blob` WRITE;
/*!40000 ALTER TABLE `sys_module_form_blob` DISABLE KEYS */;
INSERT INTO `sys_module_form_blob` VALUES ('384238649157361670','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":null}'),('384238649157361671','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":{\"clue\":[{\"key\":\"CLUE_TO_CUSTOMER\",\"linkFields\":[]}]}}'),('384238649157361672','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":{\"clue\":[{\"key\":\"CLUE_TO_CONTACT\",\"linkFields\":[{\"current\":\"384238649157361756\",\"link\":\"384238649157361748\",\"enable\":true},{\"current\":\"384238649157361758\",\"link\":\"384238649157361749\",\"enable\":true}]}]}}'),('384238649157361673','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":{\"opportunity\":[{\"key\":\"OPPORTUNITY_TO_RECORD\",\"linkFields\":[]}],\"plan\":[{\"key\":\"PLAN_TO_RECORD\",\"linkFields\":[]}],\"clue\":[{\"key\":\"CLUE_TO_RECORD\",\"linkFields\":[]}],\"customer\":[{\"key\":\"CUSTOMER_TO_RECORD\",\"linkFields\":[]}]}}'),('384238649157361674','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":null}'),('384238649157361675','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":{\"clue\":[{\"key\":\"CLUE_TO_OPPORTUNITY\",\"linkFields\":[]}],\"customer\":[{\"key\":\"CUSTOMER_TO_OPPORTUNITY\",\"linkFields\":[]}]}}'),('384238649157361676','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":null}'),('384238649157361677','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":null}'),('384238649157361678','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":null}'),('384238649157361679','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":null}'),('384238649157361680','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":{\"contract\":[{\"key\":\"CONTRACT_TO_INVOICE\",\"linkFields\":[]}]}}'),('384238649157361681','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":null}'),('384238649157361682','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":null}'),('384238649157361683','{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":{\"contract\":[{\"key\":\"CONTRACT_TO_ORDER\",\"linkFields\":[]}]}}');
/*!40000 ALTER TABLE `sys_module_form_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_navigation`
--

DROP TABLE IF EXISTS `sys_navigation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_navigation` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `navigation_key` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '导航栏key',
  `enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '启用/禁用',
  `pos` bigint NOT NULL COMMENT '自定义排序',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统导航设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_navigation`
--

LOCK TABLES `sys_navigation` WRITE;
/*!40000 ALTER TABLE `sys_navigation` DISABLE KEYS */;
INSERT INTO `sys_navigation` VALUES ('101927171227910464','100001','search',_binary '',1,'admin',1780392058000,'admin',1780392058000),('101927171227910465','100001','agent',_binary '',3,'admin',1780392058000,'admin',1780392058000),('101927171227910466','100001','notify',_binary '',4,'admin',1780392058000,'admin',1780392058000),('101927171227910467','100001','about',_binary '',5,'admin',1780392058000,'admin',1780392058000),('101927171227910468','100001','language',_binary '',6,'admin',1780392058000,'admin',1780392058000),('101927171227910469','100001','help',_binary '',7,'admin',1780392058000,'admin',1780392058000),('101927171227910472','100001','event',_binary '',2,'admin',1780392058000,'admin',1780392058000);
/*!40000 ALTER TABLE `sys_navigation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_notification`
--

DROP TABLE IF EXISTS `sys_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_notification` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '通知类型',
  `receiver` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '接收人',
  `subject` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '标题',
  `status` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '状态',
  `operator` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作人',
  `operation` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '资源ID',
  `resource_type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '资源类型',
  `resource_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '资源名称',
  `content` blob NOT NULL COMMENT '通知内容',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`),
  KEY `idx_create_time` (`create_time` DESC),
  KEY `idx_type` (`type`),
  KEY `idx_subject` (`subject`),
  KEY `idx_resource_type` (`resource_type`),
  KEY `idx_operator` (`operator`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_resource_id` (`resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='消息通知';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_notification`
--

LOCK TABLES `sys_notification` WRITE;
/*!40000 ALTER TABLE `sys_notification` DISABLE KEYS */;
INSERT INTO `sys_notification` VALUES ('384898124205793285','SYSTEM_NOTICE','384244868270006272','Not Support Key: message.approval_todo通知','UNREAD','384244868270006280','APPROVAL_TODO','100001','101927171227910643','APPROVAL','Yundy-Zahid Tractor',_binary 'PK\0\0u\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�,\�K�|\�?\�ɮ%Ov�=�\�\�tB��B$HT7*1#3E!�(1�$�\����\�?kZ\�t\�\�g�;PK\�6O;\0\0\09\0\0\0',1780468839433,1780468839433,'384244868270006280','384244868270006280'),('384898124205793286','SYSTEM_NOTICE','384244868270006274','Not Support Key: message.approval_todo通知','UNREAD','384244868270006280','APPROVAL_TODO','100001','101927171227910643','APPROVAL','Yundy-Zahid Tractor',_binary 'PK\0\0u\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�,\�K�|\�?\�ɮ%Ov�=�\�\�tB��B$HT7*1#3E!�(1�$�\����\�?kZ\�t\�\�g�;PK\�6O;\0\0\09\0\0\0',1780468839445,1780468839445,'384244868270006280','384244868270006280'),('384898931659644932','SYSTEM_NOTICE','384244868270006272','Not Support Key: message.approval_todo通知','UNREAD','384244868270006280','APPROVAL_TODO','100001','101927171227910643','APPROVAL','Yundy-Al-Futtaim Auto',_binary 'PK\0\0Fu\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�,\�K�|\�?\�ɮ%Ov�=�\�\�tB��B$HT\�1G׭��$13W���$����\�?kZ\�t\�\�g�;PK���y=\0\0\0;\0\0\0',1780468933617,1780468933617,'384244868270006280','384244868270006280'),('384904927433990146','SYSTEM_NOTICE','384244868270006274','Not Support Key: message.approval_todo通知','UNREAD','384244868270006280','APPROVAL_TODO','100001','101927171227910643','APPROVAL','Yundy-Al-Futtaim Auto',_binary 'PK\0\0�v\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�,\�K�|\�?\�ɮ%Ov�=�\�\�tB��B$HT\�1G׭��$13W���$����\�?kZ\�t\�\�g�;PK���y=\0\0\0;\0\0\0',1780469631454,1780469631454,'384244868270006280','384244868270006280'),('384905125002485762','SYSTEM_NOTICE','384244868270006280','合同审批通知','UNREAD','384244868270006274','CONTRACT_APPROVAL','100001','101927171227910640','CONTRACT','Yundy-Al-Futtaim Auto',_binary 'PK\0\0\�v\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip\�N-\�\�{�n\�ΝOv�E�\�T\�:\�躕��$f\�*8��\�?�\�\�tB\��==e\�wO~6oΓ��n\�\��a֋�\�\0PK\�qqE\0\0\0D\0\0\0',1780469654098,1780469654098,'384244868270006274','384244868270006274'),('384907298255937538','SYSTEM_NOTICE','384244868270006280','合同审批通知','UNREAD','384244868270006274','CONTRACT_APPROVAL','100001','101927171227910640','CONTRACT','Yundy-Zahid Tractor',_binary 'PK\0\0Mw\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip\�N-\�\�{�n\�ΝOv�E�\�T\�F%fd�(�%&�\�=�\�\�tB\��==E\�wO~6oΓ��n\�\��a֋�\�\0PK^�C\0\0\0B\0\0\0',1780469907064,1780469907064,'384244868270006274','384244868270006274'),('385279182294228993','SYSTEM_NOTICE','384244868270006280','客户自动移入公海（到时间）通知','UNREAD','admin','CUSTOMER_AUTOMATIC_MOVE_HIGH_SEAS','100001','101927171227910397','CUSTOMER','Al-Futtaim Auto & Machinery Co.(FAMCO)',_binary 'PK\0\0\0\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zipz\0��请注意！根据系统规则，您负责的Al-Futtaim Auto & Machinery Co.(FAMCO)客户已被移入公海，请知悉！PK���\0\0\0z\0\0\0',1780513200068,1780513200068,'admin','admin');
/*!40000 ALTER TABLE `sys_notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_operation_log`
--

DROP TABLE IF EXISTS `sys_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_operation_log` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NONE' COMMENT '组织id',
  `type` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作类型/add/update/delete',
  `module` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作模块',
  `resource_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '资源id',
  `resource_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '资源名称',
  `detail` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作详情',
  `create_time` bigint NOT NULL COMMENT '操作时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作人',
  `path` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作路径',
  `method` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '操作方法',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_resource_id` (`resource_id`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='操作日志';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_operation_log`
--

LOCK TABLES `sys_operation_log` WRITE;
/*!40000 ALTER TABLE `sys_operation_log` DISABLE KEYS */;
INSERT INTO `sys_operation_log` VALUES ('384244559032360960','100001','UPDATE','SYSTEM_ORGANIZATION','101927171227910394','Basenton',NULL,1780392754069,'admin','/department/rename','POST'),('384244601982033921','100001','ADD','SYSTEM_ORGANIZATION','384244601982033920','Kevin组',NULL,1780392759873,'admin','/department/add','POST'),('384244696471314432','100001','UPDATE','SYSTEM_ORGANIZATION','384244601982033920','管理层',NULL,1780392770050,'admin','/department/rename','POST'),('384244722241118209','100001','ADD','SYSTEM_ORGANIZATION','384244722241118208','Kevin组',NULL,1780392773595,'admin','/department/add','POST'),('384244782370660353','100001','ADD','SYSTEM_ORGANIZATION','384244782370660352','Betty组',NULL,1780392780508,'admin','/department/add','POST'),('384244868270006286','100001','ADD','SYSTEM_ORGANIZATION','384244868270006272','Simon',NULL,1780392790940,'admin',NULL,'GET'),('384244868270006287','100001','ADD','SYSTEM_ORGANIZATION','384244868270006274','Kevin',NULL,1780392790940,'admin',NULL,'GET'),('384244868270006288','100001','ADD','SYSTEM_ORGANIZATION','384244868270006276','Betty',NULL,1780392790940,'admin',NULL,'GET'),('384244868270006289','100001','ADD','SYSTEM_ORGANIZATION','384244868270006278','Tina',NULL,1780392790940,'admin',NULL,'GET'),('384244868270006290','100001','ADD','SYSTEM_ORGANIZATION','384244868270006280','Yundy',NULL,1780392790940,'admin',NULL,'GET'),('384244868270006291','100001','ADD','SYSTEM_ORGANIZATION','384244868270006282','Cyan',NULL,1780392790940,'admin',NULL,'GET'),('384244868270006292','100001','ADD','SYSTEM_ORGANIZATION','384244868270006284','Anya',NULL,1780392790940,'admin',NULL,'GET'),('384245160327782403','100001','ADD','SYSTEM_MODULE','384245160327782400','公海设置',NULL,1780392824163,'admin','/account-pool/add','POST'),('384266935811973120','100001','UPDATE','SYSTEM_MODULE','384245160327782400','公海设置',NULL,1780395359099,'admin','/account-pool/update','POST'),('384267107610664960','100001','UPDATE','SYSTEM_MODULE','384245160327782400','公海设置',NULL,1780395379448,'admin','/account-pool/update','POST'),('384309567657353216','100001','UPDATE','SYSTEM_MODULE','384245160327782400','公海设置',NULL,1780400322905,'admin','/account-pool/update','POST'),('384825668107509762','100001','ADD_USER','SYSTEM_ROLE','org_admin','管理员','角色 管理员 添加用户 Simon',1780460404103,'admin',NULL,'GET'),('384825668107509763','100001','ADD_USER','SYSTEM_ROLE','org_admin','管理员','角色 管理员 添加用户 Kevin',1780460404103,'admin',NULL,'GET'),('384825771186724866','100001','ADD_USER','SYSTEM_ROLE','sales_manager','销售经理','角色 销售经理 添加用户 Kevin',1780460416307,'admin',NULL,'GET'),('384825771186724867','100001','ADD_USER','SYSTEM_ROLE','sales_manager','销售经理','角色 销售经理 添加用户 Betty',1780460416307,'admin',NULL,'GET'),('384825848496136196','100001','ADD_USER','SYSTEM_ROLE','sales_staff','销售专员','角色 销售专员 添加用户 Yundy',1780460425286,'admin',NULL,'GET'),('384825848496136197','100001','ADD_USER','SYSTEM_ROLE','sales_staff','销售专员','角色 销售专员 添加用户 Cyan',1780460425286,'admin',NULL,'GET'),('384825848496136198','100001','ADD_USER','SYSTEM_ROLE','sales_staff','销售专员','角色 销售专员 添加用户 Anya',1780460425286,'admin',NULL,'GET'),('384825848496136199','100001','ADD_USER','SYSTEM_ROLE','sales_staff','销售专员','角色 销售专员 添加用户 Tina',1780460425286,'admin',NULL,'GET'),('384831088356237317','100001','ADD','CUSTOMER_INDEX','384831079766302720','Zahid Tractor & Heavy Machinery Co.Ltd',NULL,1780461035026,'384244868270006280','/account/add','POST'),('384831337464340482','100001','ADD','CUSTOMER_CONTACT','384831337464340480','Customer',NULL,1780461064797,'384244868270006280','/account/contact/add','POST'),('384831827090612231','100001','ADD','CUSTOMER_INDEX','384831827090612224','Al-Futtaim Auto & Machinery Co.(FAMCO)',NULL,1780461121964,'384244868270006280','/account/add','POST'),('384832093378584578','100001','ADD','CUSTOMER_CONTACT','384832093378584576','Customer',NULL,1780461152878,'384244868270006280','/account/contact/add','POST'),('384832694674006018','100001','ADD','CONTRACT_INDEX','384832694674006016','Yundy-Al-Futtaim Auto',NULL,1780461222746,'384244868270006280','/contract/add','POST'),('384833381868773377','100001','UPDATE','SYSTEM_ORGANIZATION','384244868270006281','Yundy',NULL,1780461302950,'admin','/user/update','POST'),('384833484947988481','100001','UPDATE','SYSTEM_ORGANIZATION','384244868270006279','Tina',NULL,1780461314422,'admin','/user/update','POST'),('384834730488504321','100001','UPDATE','CONTRACT_INDEX','384832694674006016','Yundy-Al-Futtaim Auto',NULL,1780461459615,'384244868270006280','/contract/update','POST'),('384837032590974977','100001','ADD','PRODUCT_MANAGEMENT_PRO','384837032590974976','Ocean fee',NULL,1780461727850,'384244868270006272','/product/add','POST'),('384837187209797633','100001','ADD','PRODUCT_MANAGEMENT_PRO','384837187209797632','Air Shipping',NULL,1780461745976,'384244868270006272','/product/add','POST'),('384837307468881920','100001','UPDATE','PRODUCT_MANAGEMENT_PRO','384837032590974976','Ocean Shipping',NULL,1780461759327,'384244868270006272','/product/update','POST'),('384847838728691719','100001','ADD','SYSTEM_PROCESS_APPROVAL','384847838728691712','合同审批流程',NULL,1780462985795,'admin','/approval-flow/add','POST'),('384847984757579776','100001','UPDATE','SYSTEM_ORGANIZATION','384244868270006274','Kevin',NULL,1780463002615,'admin','/user/update/name','POST'),('384848036297187330','100001','UPDATE','SYSTEM_ORGANIZATION','384244868270006275','Kevin',NULL,1780463008987,'admin','/user/update','POST'),('384848070656925696','100001','UPDATE','SYSTEM_ORGANIZATION','384244868270006276','Betty',NULL,1780463012766,'admin','/user/update/name','POST'),('384848122196533249','100001','UPDATE','SYSTEM_ORGANIZATION','384244868270006277','Betty',NULL,1780463018045,'admin','/user/update','POST'),('384848397074440193','100001','UPDATE','CONTRACT_INDEX','384832694674006016','Yundy-Al-Futtaim Auto',NULL,1780463050113,'384244868270006280','/contract/update','POST'),('384848474383851521','100001','UPDATE','CONTRACT_INDEX','384832694674006016','Yundy-Al-Futtaim Auto',NULL,1780463059802,'384244868270006280','/contract/update','POST'),('384848921060450306','100001','ADD','CONTRACT_INDEX','384848921060450304','Yundy-Zahid Tractor',NULL,1780463111074,'384244868270006280','/contract/add','POST'),('384849814413647878','100001','UPDATE','SYSTEM_PROCESS_APPROVAL','384847838728691712','合同审批流程',NULL,1780463215250,'admin','/approval-flow/update','POST'),('384850011982143494','100001','UPDATE','SYSTEM_PROCESS_APPROVAL','384847838728691712','合同审批流程',NULL,1780463238549,'admin','/approval-flow/update','POST'),('384850183780835328','100001','UPDATE','CONTRACT_INDEX','384848921060450304','Yundy-Zahid Tractor',NULL,1780463258624,'384244868270006272','/contract/update/stage','POST'),('384850218140573696','100001','UPDATE','CONTRACT_INDEX','384848921060450304','Yundy-Zahid Tractor',NULL,1780463262924,'384244868270006272','/contract/update/stage','POST'),('384897428421091328','100001','UPDATE','SYSTEM_PROCESS_APPROVAL','384847838728691712','合同审批流程',NULL,1780468758167,'admin','/approval-flow/enable/384847838728691712','GET'),('384898124205793281','100001','UPDATE','CONTRACT_INDEX','384848921060450304','Yundy-Zahid Tractor',NULL,1780468839350,'384244868270006280','/contract/update','POST'),('384898596652195846','100001','UPDATE','SYSTEM_PROCESS_APPROVAL','384847838728691712','合同审批流程',NULL,1780468894355,'admin','/approval-flow/update','POST'),('384898931659644929','100001','UPDATE','CONTRACT_INDEX','384832694674006016','Yundy-Al-Futtaim Auto',NULL,1780468933583,'384244868270006280','/contract/update','POST'),('384899713343692806','100001','UPDATE','SYSTEM_PROCESS_APPROVAL','384847838728691712','合同审批流程',NULL,1780469024968,'admin','/approval-flow/update','POST'),('384900185790095366','100001','UPDATE','SYSTEM_PROCESS_APPROVAL','384847838728691712','合同审批流程',NULL,1780469079926,'admin','/approval-flow/update','POST'),('384904927433990147','100001','APPROVAL','CONTRACT_INDEX','384832694674006016','Yundy-Al-Futtaim Auto','同意',1780469631454,'384244868270006272',NULL,'GET'),('384905125002485761','100001','APPROVAL','CONTRACT_INDEX','384832694674006016','Yundy-Al-Futtaim Auto','同意',1780469654092,'384244868270006274',NULL,'GET'),('384905545909280768','100001','REMOVE_USER','SYSTEM_ROLE','org_admin','管理员','角色 管理员 移除用户 Kevin',1780469703308,'admin',NULL,'GET'),('384906001175814150','100001','UPDATE','SYSTEM_PROCESS_APPROVAL','384847838728691712','合同审批流程',NULL,1780469756707,'admin','/approval-flow/update','POST'),('384906490802085889','100001','APPROVAL','CONTRACT_INDEX','384848921060450304','Yundy-Zahid Tractor','同意',1780469813793,'384244868270006272',NULL,'GET'),('384907031967965185','100001','ADD_USER','SYSTEM_ROLE','org_admin','管理员','角色 管理员 添加用户 Kevin',1780469876919,'admin',NULL,'GET'),('384907298255937537','100001','APPROVAL','CONTRACT_INDEX','384848921060450304','Yundy-Zahid Tractor','同意',1780469907061,'384244868270006274',NULL,'GET'),('384907452874760192','100001','REMOVE_USER','SYSTEM_ROLE','org_admin','管理员','角色 管理员 移除用户 Kevin',1780469925569,'admin',NULL,'GET'),('385629866373996551','100001','ADD','CUSTOMER_INDEX','385629866373996544','Tuwaiq & Han',NULL,1780554025797,'384244868270006278','/account/add','POST'),('385630055352557570','100001','ADD','CUSTOMER_CONTACT','385630055352557568','Fahad Alaqil (CEO)',NULL,1780554047865,'384244868270006278','/account/contact/add','POST'),('385630338820399111','100001','ADD','CUSTOMER_INDEX','385630338820399104','PORTMNT',NULL,1780554080626,'384244868270006278','/account/add','POST'),('385630459079483394','100001','ADD','CUSTOMER_CONTACT','385630459079483392','Procurement Team',NULL,1780554094948,'384244868270006278','/account/contact/add','POST'),('385630828446670850','100001','ADD','CUSTOMER_CONTACT','385630828446670848','Procurement Team 1',NULL,1780554137817,'384244868270006278','/account/contact/add','POST'),('385652689830223872','100001','UPDATE','SYSTEM_MODULE','contact','联系人表单设置',NULL,1780556682347,'admin','/module/form/save','POST'),('385656581070594048','100001','UPDATE','SYSTEM_MODULE','contact','联系人表单设置',NULL,1780557135367,'admin','/module/form/save','POST');
/*!40000 ALTER TABLE `sys_operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_operation_log_blob`
--

DROP TABLE IF EXISTS `sys_operation_log_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_operation_log_blob` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '主键',
  `original_value` longblob COMMENT '变更前内容',
  `modified_value` longblob COMMENT '变更后内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='操作日志内容详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_operation_log_blob`
--

LOCK TABLES `sys_operation_log_blob` WRITE;
/*!40000 ALTER TABLE `sys_operation_log_blob` DISABLE KEYS */;
INSERT INTO `sys_operation_log_blob` VALUES ('384244559032360960',_binary 'PK\0\0�\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�V\�LQ�R240�42747422�440�4Q\�QJ.JM,I\r-N-�HL\�\�\�\n��`\nBT�d\�*Y�����X\�\�c�\�K	*=m]\�\�\�	�ϗo\0��_����Y�X���\�	qe\n�R\�J�b~�~� ��b��`y��\�\��Ңd���~!�A~�>JQ���Ҝ�Z\0PK��7�\0\0\0\�\0\0\0',_binary '{\"id\":\"101927171227910394\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1736240043609,\"updateTime\":1780392754066,\"name\":\"Basenton\",\"organizationId\":\"100001\",\"parentId\":\"NONE\",\"pos\":100001,\"resource\":\"INTERNAL\",\"resourceId\":null}'),('384244601982033921',NULL,_binary '{\"id\":\"384244601982033920\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392759871,\"updateTime\":1780392759871,\"name\":\"Kevin组\",\"organizationId\":\"100001\",\"parentId\":\"101927171227910394\",\"pos\":104097,\"resource\":\"INTERNAL\",\"resourceId\":null}'),('384244696471314432',_binary 'PK\0\0�\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zipm���0�\�\�f�^��esp �\�@c�@K\n8h\�|+\�\�\�\Z5z\�\��rp�+��X3Ԋ�<לAm�f��\�F2L78Op�_�27X(P*F�\�J\�\��;y� T\�\��\�~�N�G\�\�\�\�.�2���iM�~~3�J\�\\j��H{��\�\�2�h��\�6\�˺\�\�\�\��4E�\�\�\�\'PK�s��\0\0\0�\0\0\0',_binary '{\"id\":\"384244601982033920\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392759871,\"updateTime\":1780392770049,\"name\":\"管理层\",\"organizationId\":\"100001\",\"parentId\":\"101927171227910394\",\"pos\":104097,\"resource\":\"INTERNAL\",\"resourceId\":null}'),('384244722241118209',NULL,_binary '{\"id\":\"384244722241118208\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392773595,\"updateTime\":1780392773595,\"name\":\"Kevin组\",\"organizationId\":\"100001\",\"parentId\":\"101927171227910394\",\"pos\":108193,\"resource\":\"INTERNAL\",\"resourceId\":null}'),('384244782370660353',NULL,_binary '{\"id\":\"384244782370660352\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392780507,\"updateTime\":1780392780507,\"name\":\"Betty组\",\"organizationId\":\"100001\",\"parentId\":\"101927171227910394\",\"pos\":112289,\"resource\":\"INTERNAL\",\"resourceId\":null}'),('384244868270006286',NULL,_binary '{\"id\":\"384244868270006272\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392790935,\"updateTime\":1780392790935,\"name\":\"Simon\",\"phone\":\"13544411111\",\"email\":\"overseas.09@basenton.com\",\"password\":\"248a90ab746c05937cd0f8aaecbe7d64\",\"gender\":false,\"language\":\"zh_CN\",\"lastOrganizationId\":\"100001\"}'),('384244868270006287',NULL,_binary '{\"id\":\"384244868270006274\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392790935,\"updateTime\":1780392790935,\"name\":\"Kevin\",\"phone\":\"13888888888\",\"email\":\"overseas.08@basenton.com\",\"password\":\"21218cca77804d2ba1922c33e0151105\",\"gender\":false,\"language\":\"zh_CN\",\"lastOrganizationId\":\"100001\"}'),('384244868270006288',NULL,_binary '{\"id\":\"384244868270006276\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392790935,\"updateTime\":1780392790935,\"name\":\"Betty\",\"phone\":\"13888888881\",\"email\":\"overseas.01@basenton.com\",\"password\":\"930b7b631da8592e361bdb60b97a0580\",\"gender\":true,\"language\":\"zh_CN\",\"lastOrganizationId\":\"100001\"}'),('384244868270006289',NULL,_binary '{\"id\":\"384244868270006278\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392790935,\"updateTime\":1780392790935,\"name\":\"Tina\",\"phone\":\"13999999999\",\"email\":\"overseas.86@basenton.com\",\"password\":\"52c69e3a57331081823331c4e69d3f2e\",\"gender\":true,\"language\":\"zh_CN\",\"lastOrganizationId\":\"100001\"}'),('384244868270006290',NULL,_binary '{\"id\":\"384244868270006280\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392790935,\"updateTime\":1780392790935,\"name\":\"Yundy\",\"phone\":\"13999999991\",\"email\":\"Overseas.48@basenton.com\",\"password\":\"0ef26b9d4469882962b1bd35ef7556f4\",\"gender\":true,\"language\":\"zh_CN\",\"lastOrganizationId\":\"100001\"}'),('384244868270006291',NULL,_binary '{\"id\":\"384244868270006282\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392790935,\"updateTime\":1780392790935,\"name\":\"Cyan\",\"phone\":\"13999999910\",\"email\":\"Overseas.50@basenton.com\",\"password\":\"3138288551759ccc0fb1b7a187610739\",\"gender\":true,\"language\":\"zh_CN\",\"lastOrganizationId\":\"100001\"}'),('384244868270006292',NULL,_binary '{\"id\":\"384244868270006284\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392790935,\"updateTime\":1780392790935,\"name\":\"Anya\",\"phone\":\"13999999911\",\"email\":\"Overseas.51@basenton.com\",\"password\":\"219d70085bcf1f2ebf48532fd5c3ae89\",\"gender\":true,\"language\":\"zh_CN\",\"lastOrganizationId\":\"100001\"}'),('384245160327782403',NULL,_binary '{\"id\":\"384245160327782400\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392824160,\"updateTime\":1780392824160,\"organizationId\":\"100001\",\"name\":\"柏盛通国外公海\",\"scopeId\":\"[\\\"101927171227910394\\\"]\",\"ownerId\":\"[\\\"384244601982033920\\\"]\",\"enable\":true,\"auto\":false}'),('384266935811973120',_binary 'PK\0\0��\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zipm�1\�0E\�\�C�\�\�\�0Q�\�\Z	��B!�0�1Ё��1q���\���\�^�\�!�0�B�x��B�HH\� �̣.�W�\'B\�ScI�f���!�f��p�0TBu_��\��X[�Хq�\�3\ZN}V�p��\��~�\�M}m��fs��/d��\�;\�O)\�c��\�B��S�La@��[\�_\���l\Z	\�\r\��\�\�	�*}�\�t��\���\�PK��\�\0\0\0\0\0',_binary '{\"id\":\"384245160327782400\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392824160,\"updateTime\":1780395359093,\"organizationId\":\"100001\",\"name\":\"柏盛通国外公海\",\"scopeId\":\"[\\\"101927171227910394\\\"]\",\"ownerId\":\"[\\\"384244601982033920\\\"]\",\"enable\":true,\"auto\":true}'),('384267107610664960',_binary 'PK\0\0	�\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zipe�=\n\�@�\�2u����\�\�Z�Ś,����I�\�\�\�\�6��b\�q\��Ap�\�\�\�\�̬�f\��&b\�!�I�0AD��3\�M@Bgs\�P,ٿؒ};7Х2!\\1��/�;�y��\��0\�ήta�뽯��b�\�o�\��QU\�\���\�\��P\�.\�\��\�<\�\�qGh��I*)cRQ\�##\�΄/\��OtM\�xi!\�\�d���P�tY��߼\0PKx;\Zo\�\0\0\0\0\0',_binary '{\"id\":\"384245160327782400\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392824160,\"updateTime\":1780395379446,\"organizationId\":\"100001\",\"name\":\"柏盛通国外公海\",\"scopeId\":\"[\\\"101927171227910394\\\"]\",\"ownerId\":\"[\\\"384244601982033920\\\"]\",\"enable\":true,\"auto\":true}'),('384309567657353216',_binary 'PK\0\0՜\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zipe�=\n\�@�\�2u��3�\�\�Z�\�jY0��\� (�����)l,m\�\�\�D\��Ap�\�\�\�\�̬�\�O\ZΤL� \"�x��\�\�#�\�\�X�y�/�d\�\Z2*\�S�!\�\�G.S!\���*k�*g�\�+(���g\���q\��\�\�\�\�Է\�o�\��\�\�r\�\��\�\�DS&���ɔb�\�!��\��\�\"F4a�\�y���U\��\n�\��*��_�\0PK���\�\�\0\0\0\0\0',_binary '{\"id\":\"384245160327782400\",\"createUser\":\"admin\",\"updateUser\":\"admin\",\"createTime\":1780392824160,\"updateTime\":1780400322902,\"organizationId\":\"100001\",\"name\":\"柏盛通国外公海\",\"scopeId\":\"[\\\"101927171227910394\\\"]\",\"ownerId\":\"[\\\"384244601982033920\\\"]\",\"enable\":true,\"auto\":true}'),('384831088356237317',NULL,_binary '{\"id\":\"384831079766302720\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461034997,\"updateTime\":1780461034997,\"name\":\"Zahid Tractor & Heavy Machinery Co.Ltd\",\"owner\":\"384244868270006280\",\"collectionTime\":1780461034997,\"poolId\":null,\"inSharedPool\":false,\"organizationId\":\"100001\",\"follower\":null,\"followTime\":null,\"reasonId\":null,\"384238649157361809\":\"3\",\"384238649157361810\":\"1\",\"384238649157361811\":\"2\",\"384238649157361812\":\"1\",\"384238649157361813\":\"2\"}'),('384831337464340482',NULL,_binary '{\"id\":\"384831337464340480\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461064788,\"updateTime\":1780461064788,\"customerId\":\"384831079766302720\",\"owner\":\"384244868270006280\",\"name\":\"Customer\",\"phone\":\"1111\",\"enable\":true,\"disableReason\":null,\"organizationId\":\"100001\",\"384238649157361757\":\"info@zahidtractor.com\"}'),('384831827090612231',NULL,_binary '{\"id\":\"384831827090612224\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461121958,\"updateTime\":1780461121958,\"name\":\"Al-Futtaim Auto & Machinery Co.(FAMCO)\",\"owner\":\"384244868270006280\",\"collectionTime\":1780461121958,\"poolId\":null,\"inSharedPool\":false,\"organizationId\":\"100001\",\"follower\":null,\"followTime\":null,\"reasonId\":null,\"384238649157361809\":\"3\",\"384238649157361810\":\"1\",\"384238649157361811\":\"2\",\"384238649157361812\":\"1\",\"384238649157361813\":\"2\",\"384238649157361816\":\"KSA-\"}'),('384832093378584578',NULL,_binary '{\"id\":\"384832093378584576\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461152871,\"updateTime\":1780461152871,\"customerId\":\"384831827090612224\",\"owner\":\"384244868270006280\",\"name\":\"Customer\",\"phone\":\"+9665155\",\"enable\":true,\"disableReason\":null,\"organizationId\":\"100001\",\"384238649157361757\":\"sa.machinery@alfuttaim.com\"}'),('384832694674006018',NULL,_binary '{\"id\":\"384832694674006016\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461222707,\"updateTime\":1780461222707,\"name\":\"Yundy-Al-Futtaim Auto\",\"customerId\":\"384831827090612224\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000001\",\"approvalStatus\":\"NONE\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1746115200000,\"endTime\":1781712000000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":1}'),('384833381868773377',_binary 'PK\0\0ad\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�P=KA�/[���9�5���\�؈�l��s\�\�\���wr������B\��\��Nɿ\�\�D\�\�\�\�\�\�{�#6e#�0�c)&�\��܁=��\�{�R �\"Ǩ$P\��\�a�b�l?e�km0\�\�^�\�	�gX\�\rCy0S\�ޘ�$d\�����.!D�\\�\�t�N�\���\�D���B���6\�8��\�]��-�3͖�\'\�.\�:��5	86�\\�\�r�\�k\�\�|N6\�FnW�\�\�s�~�^\��9\�\�\�<KL	\�h\�\�Cf��;ҸY�W\��O�;/�:��{c\��/�rgF\�Hc|�|Wy�PK<���#\0\0\�\0\0',_binary '{\"id\":\"384244868270006281\",\"userId\":\"384244868270006280\",\"userName\":\"Yundy\",\"enable\":true,\"gender\":true,\"phone\":\"13999999991\",\"email\":\"Overseas.48@basenton.com\",\"departmentId\":\"384244722241118208\",\"departmentName\":\"Kevin组\",\"organizationId\":\"100001\",\"supervisorId\":\"384244868270006274\",\"supervisorName\":\"Kevin\",\"roles\":[{\"id\":\"sales_staff\",\"name\":\"销售专员\",\"userId\":\"384244868270006280\"}],\"employeeId\":\"5\",\"position\":\"业务员\",\"employeeType\":\"\",\"workCity\":null,\"onboardingDate\":null}'),('384833484947988481',_binary 'PK\0\0gd\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�P�JA~��C�\�\�&���V\�Dd\�M\�\�\�̱��!`ae\'�;_�:\�\�\�\�¹\\\"n\��\�7\�\�R\�T�T\�$:IL\�\�AE}=��*=�\�?U�W\�!G\�ǖ@$�d��+��fH)�7L�5\�\r\�W�\��f\�\��G\�]\�?��G\nL\�k\�Œb.\�BTh��8���\�/Ͼ\�\�-}}>�\�nd\�!X�]B,+D�(�,\�ͭ\�ݒTf\�!\�$5�\��\Z],�cyx\�L�C\�\�\�\�C��\�n^�\�\�n���7/2^ \�<�|(\�ۺ��\�\�zzorZ\�xQ\�S��cw{lâ-\�4ap��\�	�}\�\�PK��R�\0\0\�\0\0',_binary '{\"id\":\"384244868270006279\",\"userId\":\"384244868270006278\",\"userName\":\"Tina\",\"enable\":true,\"gender\":true,\"phone\":\"13999999999\",\"email\":\"overseas.86@basenton.com\",\"departmentId\":\"384244722241118208\",\"departmentName\":\"Kevin组\",\"organizationId\":\"100001\",\"supervisorId\":\"384244868270006274\",\"supervisorName\":\"Kevin\",\"roles\":[{\"id\":\"sales_staff\",\"name\":\"销售专员\",\"userId\":\"384244868270006278\"}],\"employeeId\":\"4\",\"position\":\"业务员\",\"employeeType\":\"\",\"workCity\":null,\"onboardingDate\":null}'),('384834730488504321',_binary 'PK\0\0�d\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip���N\�0D�\�Hk\�8nn�*��(8!�X��Ď�u ��u�\��f�gg��\�X\�\�Z\�P�J	��+�bo\�\Z�ϓ�!�\�J��\Z�Hc\��x<�����\Z�\�BP�?��\�&�\�%�\�\�\�\�]B4n�\�&\�4M�Kt��n`v�D�w�w&3�\�UP\�X\Z3||!@(P\�\�3;�1�L�G�i\"��ok\�\'4\�\�no�v\��ov-\�e\�܊:\�k1���\�ݥ-/�\"�~\n�{�f\n�U>\�=ŏG\�ݧA�\\��\�B\�\�PKw|��\0\0\0�\0\0',_binary '{\"id\":\"384832694674006016\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461222707,\"updateTime\":1780461459593,\"name\":\"Yundy-Al-Futtaim Auto\",\"customerId\":\"384831827090612224\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000001\",\"approvalStatus\":\"NONE\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1746115200000,\"endTime\":1781712000000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":null}'),('384837032590974977',NULL,_binary '{\"id\":\"384837032590974976\",\"createUser\":\"384244868270006272\",\"updateUser\":\"384244868270006272\",\"createTime\":1780461727843,\"updateTime\":1780461727843,\"organizationId\":\"100001\",\"name\":\"Ocean fee\",\"price\":null,\"status\":\"1\",\"pos\":4096}'),('384837187209797633',NULL,_binary '{\"id\":\"384837187209797632\",\"createUser\":\"384244868270006272\",\"updateUser\":\"384244868270006272\",\"createTime\":1780461745972,\"updateTime\":1780461745972,\"organizationId\":\"100001\",\"name\":\"Air Shipping\",\"price\":1,\"status\":\"1\",\"pos\":8192}'),('384837307468881920',_binary 'PK\0\0Se\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��1\�0E��<wp\'� j\r�T\�*Mw\'Qņ\�f����_G\��8r�\�\�G\�\�\�BC�P\�J\�	M\�ӌ�V��Ķ��\�q��^�C��5;2\�\�\�j\�\��\�3�8�S�OU#�\�K�\�p$�\�M�FK�C\�\�6M�%�mm�\�\�\�\"\�\��PK\�c��\0\0\0\�\0\0\0',_binary '{\"id\":\"384837032590974976\",\"createUser\":null,\"updateUser\":\"384244868270006272\",\"createTime\":null,\"updateTime\":1780461759319,\"organizationId\":\"100001\",\"name\":\"Ocean Shipping\",\"price\":1,\"status\":\"1\",\"pos\":null}'),('384847838728691719',NULL,_binary '{\"id\":\"384847838728691712\",\"currentVersionId\":\"384847838728691713\",\"number\":\"CTR-APV-00001\",\"name\":\"合同审批流程\",\"formType\":\"contract\",\"createExecute\":true,\"updateExecute\":false,\"enable\":false,\"description\":\"\",\"submitterCanRevoke\":true,\"allowBatchProcess\":false,\"allowWithdraw\":false,\"allowAddSign\":false,\"duplicateApproverRule\":\"FIRST_ONLY\",\"requireComment\":false,\"createUserName\":\"Administrator\",\"updateUserName\":\"Administrator\",\"createTime\":1780462985778,\"updateTime\":1780462985778,\"createUser\":\"admin\",\"updateUser\":\"admin\",\"permissions\":[{\"id\":\"CONTRACT:READ\",\"name\":\"查看\"},{\"id\":\"CONTRACT:ADD\",\"name\":\"添加\"},{\"id\":\"CONTRACT:UPDATE\",\"name\":\"编辑\"},{\"id\":\"CONTRACT:DELETE\",\"name\":\"删除\"},{\"id\":\"CONTRACT:EXPORT\",\"name\":\"导出\"},{\"id\":\"CONTRACT:STAGE\",\"name\":\"合同阶段变更\"},{\"id\":\"CONTRACT:PAYMENT\",\"name\":\"回款\"}],\"statusPermissions\":[{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true}],\"nodes\":[{\"id\":\"384847838728691714\",\"number\":\"PN001\",\"name\":\"开始\",\"nodeType\":\"START\",\"sort\":0},{\"id\":\"384847838728691715\",\"number\":\"PN002\",\"name\":\"审批人\",\"nodeType\":\"APPROVER\",\"sort\":1,\"approvalType\":\"MANUAL\",\"approvalTypeName\":null,\"multiApproverMode\":\"ALL\",\"multiApproverModeName\":null,\"emptyApproverAction\":\"AUTO_PASS\",\"fallbackApprover\":\"\",\"fallbackApproverName\":null,\"sameSubmitterAction\":\"SKIP\",\"approverType\":\"MULTIPLE_SUPERIOR\",\"approverDirection\":\"BOTTOM_UP\",\"approverList\":[\"1\"],\"approverSelectOptions\":[],\"ccType\":null,\"ccDirection\":\"BOTTOM_UP\",\"ccList\":[],\"ccSelectOptions\":null,\"passPostConfig\":null,\"rejectPostConfig\":null,\"fieldPermissions\":[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]},{\"id\":\"384847838728691716\",\"number\":\"PN003\",\"name\":\"结束\",\"nodeType\":\"END\",\"sort\":2}],\"links\":[{\"id\":\"384847838728691717\",\"fromNodeId\":\"384847838728691714\",\"toNodeId\":\"384847838728691715\"},{\"id\":\"384847838728691718\",\"fromNodeId\":\"384847838728691715\",\"toNodeId\":\"384847838728691716\"}],\"optionMap\":{}}'),('384847984757579776',_binary 'PK\0\0kh\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�V\�K\�MU�R\�N-\�\�S�\0PK��:\�\0\0\0\0\0\0',_binary '{\"name\":\"Kevin\"}'),('384848036297187330',_binary 'PK\0\0nh\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��\�J1�\�%\�Rfұ\r]	���;�r\�\\\�`&wHf*����\n]�\�\�\�y\�\�[x秥�\�\�r\�\�ws\�L\�XEOE2�T_\�A}98Qxtg��Q\�^@�\�\�D[�\�\�ذ��;\"A�\�[0��\�\�*\�\�\�TORІU��\���\�1x�9\�\�\r��1��,\�}f ��\�0T2P2�_*\�O\�K�\�G\�5ٚr� d\���\�T״�1�ZCjTG�^͚u1rqZ��\��r\�Y�=o\�?,n\�i9J�B\�[\�q~��\�rU�_�vu]\�/34E�3�d\�uՔ����\�\�z�\�F/�Y5��r\�\':�n[��X\�\�\���PK]\�\�B7\0\0\"\0\0',_binary '{\"id\":\"384244868270006275\",\"userId\":\"384244868270006274\",\"userName\":\"Kevin\",\"enable\":true,\"gender\":false,\"phone\":\"13888888888\",\"email\":\"overseas.08@basenton.com\",\"departmentId\":\"384244722241118208\",\"departmentName\":\"Kevin组\",\"organizationId\":\"100001\",\"supervisorId\":\"384244868270006272\",\"supervisorName\":\"Simon\",\"roles\":[{\"id\":\"org_admin\",\"name\":\"管理员\",\"userId\":\"384244868270006274\"},{\"id\":\"sales_manager\",\"name\":\"销售经理\",\"userId\":\"384244868270006274\"}],\"employeeId\":\"2\",\"position\":\"副总经理\",\"employeeType\":\"\",\"workCity\":null,\"onboardingDate\":null}'),('384848070656925696',_binary 'PK\0\0ph\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�V\�K\�MU�RrJ-)�T�\0PK��x�\0\0\0\0\0\0',_binary '{\"name\":\"Betty\"}'),('384848122196533249',_binary 'PK\0\0sh\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�P\�J\�@��9�e\�0	{\�\�œ7\�&�L��\�J\\<�W=\�w��=�{6Y�(ط��\�\�P�X�8O�$\�\�<ʤ�i�e\"�Es�\'�N\�4\��:\�3�\Z��g:D��Ds\�\�\�^\��T��h@Ռ\�\Z�E��`Q;ҋ{jXRb\�5ͼdyg2Me|�\�\�\r�\�\�T�\�8E��!\�\��]�f�,Rꮮ\�ظiD\r\�h\�\�f3~\��w\rh�8` \�x\�k\����\�o\��\�?\�\�\��\�mM=\�ၖ�\�.�:J��\�b\�\�\�\\\�\�\'��S*]]��|o�PK�hM\0\0\�\0\0',_binary '{\"id\":\"384244868270006277\",\"userId\":\"384244868270006276\",\"userName\":\"Betty\",\"enable\":true,\"gender\":true,\"phone\":\"13888888881\",\"email\":\"overseas.01@basenton.com\",\"departmentId\":\"384244782370660352\",\"departmentName\":\"Betty组\",\"organizationId\":\"100001\",\"supervisorId\":\"384244868270006272\",\"supervisorName\":\"Simon\",\"roles\":[{\"id\":\"sales_manager\",\"name\":\"销售经理\",\"userId\":\"384244868270006276\"}],\"employeeId\":\"3\",\"position\":\"销售经理\",\"employeeType\":\"\",\"workCity\":null,\"onboardingDate\":null}'),('384848397074440193',_binary 'PK\0\0�h\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��AK\�0���伅I��io�֥�*�<I�a	�II�����.xsx\�\�\�{_\�\��&�\�2g�\�\�\0� ;\�\�\n�i\�~%\�RHVLq\��!V�G3jR\�R�1\�\�\�/��\�wĪ$�\�h��l?d�1eƫ}.�\�9�Q�\����,\�	\�n�ΤFm 54<\�\��v6c��ң��&\�\�j8\�Pw\�5�\�A�R\����i�\�˱=t8׍[+\�D��툶��--\�*�~v�\�jv�\�6\�\�\'eͧ\n\�٥$\�\�LC\�\�PK\�r�,\0\0�\0\0',_binary '{\"id\":\"384832694674006016\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461222707,\"updateTime\":1780463050103,\"name\":\"Yundy-Al-Futtaim Auto\",\"customerId\":\"384831827090612224\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000001\",\"approvalStatus\":\"NONE\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1746115200000,\"endTime\":1781712000000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":null}'),('384848474383851521',_binary 'PK\0\0�h\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��AK\�0���伅�4�f{[�.�Tq\�\�I�\rK�MJ����ߝ�t\�\"\�2\�\�˛\��Xײ�\�J��˝��\0���m؛7:��\���\�B(�xDpDı��X<���B\"\�\�\�߫���o�\�Id\�Ѷپ\�nc��\�1�d\Z�\�\�\�KtLGw0�\"ܻ�;�\\���Pet,�3|\�lƁK����G\�κ?\�DPs\�T�OA�R\������\�˱>44��k+��[>�m��\��-�Ȥ�]\�>=9\�J��\����ݧ��sI\\\�B\�\�PKm3\�E\0\0�\0\0',_binary '{\"id\":\"384832694674006016\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461222707,\"updateTime\":1780463059791,\"name\":\"Yundy-Al-Futtaim Auto\",\"customerId\":\"384831827090612224\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000001\",\"approvalStatus\":\"NONE\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1746201600000,\"endTime\":1781712000000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":null}'),('384848921060450306',NULL,_binary '{\"id\":\"384848921060450304\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780463111066,\"updateTime\":1780463111066,\"name\":\"Yundy-Zahid Tractor\",\"customerId\":\"384831079766302720\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000002\",\"approvalStatus\":\"NONE\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1782316800000,\"endTime\":1813852800000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":2}'),('384849814413647878',_binary 'PK\0\0\�h\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��[�\�Fǿ���\�fﾙĠ�Ķl\'�\�\�kO�]\�:C\�j�\���T*�R\n�Z���\�\�\�4\�\�-:cǎ�xח$Oɹ�<s\�cQ�A\�RM�Ŷ�\�2\r��C3t��Qz\0!p\�@\�t�~f\\\�9�}\0 \�vU�\'�/\�\�&\�\�<}x�\�\�\�\�?f?�3�\��\�\�\�7q��\�\�_w5�KB�!�\�\0a��Q�g��\�\�8ځ��i\0_���\�J1��\��6��92�\�&<Ͳܻ�5�ߖ��\�O �纉nP��l\�C1o9�\��e\�x]�\�A\��r@VC]\�ˊ�/\n�x\r|�t]\�ƅLr�]�|\0��B�a��\�\�* R\�/��I�4\�\�[�\�\�f6\�\�t-���\ZA.]+e\�\0�M�;.\�ͣH$]QPe��\�\�<\�[\�\�\�_g\�Pǵ\�0�����\�\���Q#�ǩ�\"\�\�\���>?\�\�\�>8��\�˓?3��$QVS�\�N�?�d**w�_\�\�\�go?Ly<{�>#G\�ny!M��\�\�g\�xKi(\�\�i�@4K	�8C\�\�\�5��T\�\�F7\"Ւ��E�pB\�U%g����S\���\�vKa\�U-�\�\�$I\�}\�\�\�Z\�GVC>j]�\�\�%�	��*\�ik�\�VF\Z#!\�m�O`GV�nQ�V�a��QG\\\�Q\0VF/\��\�7\�@���*��<T	I\�\�\�!�U\\y�\�\��m��\�5�\n-bX��G�Q�^\�Q�7\�N\�ų\�\�)}mDk�G4IX\�N���\"\��\�\�1�\�\0�\�\�RO�\��\�Up#��ON�\�\�}\�	��%Ř�9a\�\r�e{49�e\�(;��O]C\�&\�\�X\�Ӏ\��{��\�\�\"7R\�}�S2�\�A\�@\�\�h�\\���>��\�sf\�T�\��d�\0\��\Z\rԾ4\�\���\�\�}QN�\�\�g_UU\�҈�\�	S4��0*�\�Ib8\�\�\�.]�.�N\�\�\�\���欀�dO\�}\�\�Q\�u&\�\�\n�\�8t\�>1�e�>�1~m\�h��\�\�f���w��>�и\�_\'����l\�ĝ��t�jb�Z\"۬X����غ`�{\�7�\�j\�h�\��O�Ξ�X\�\Z�n�4�iy�\�^\�\�H!&е\�\�~oE�\"r\�\���\�\�\�\�\�9\�N���\r�qCͣv����PK`|\0\0�\0\0',_binary '{\"id\":\"384847838728691712\",\"currentVersionId\":\"384849814413647872\",\"number\":\"CTR-APV-00001\",\"name\":\"合同审批流程\",\"formType\":\"contract\",\"createExecute\":true,\"updateExecute\":true,\"enable\":false,\"description\":\"\",\"submitterCanRevoke\":true,\"allowBatchProcess\":false,\"allowWithdraw\":false,\"allowAddSign\":false,\"duplicateApproverRule\":\"FIRST_ONLY\",\"requireComment\":false,\"createUserName\":\"Administrator\",\"updateUserName\":\"Administrator\",\"createTime\":1780462985778,\"updateTime\":1780463215244,\"createUser\":\"admin\",\"updateUser\":\"admin\",\"permissions\":[{\"id\":\"CONTRACT:READ\",\"name\":\"查看\"},{\"id\":\"CONTRACT:ADD\",\"name\":\"添加\"},{\"id\":\"CONTRACT:UPDATE\",\"name\":\"编辑\"},{\"id\":\"CONTRACT:DELETE\",\"name\":\"删除\"},{\"id\":\"CONTRACT:EXPORT\",\"name\":\"导出\"},{\"id\":\"CONTRACT:STAGE\",\"name\":\"合同阶段变更\"},{\"id\":\"CONTRACT:PAYMENT\",\"name\":\"回款\"}],\"statusPermissions\":[{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true}],\"nodes\":[{\"id\":\"384849814413647873\",\"number\":\"PN001\",\"name\":\"开始\",\"nodeType\":\"START\",\"sort\":0},{\"id\":\"384849814413647874\",\"number\":\"PN002\",\"name\":\"审批人\",\"nodeType\":\"APPROVER\",\"sort\":1,\"approvalType\":\"MANUAL\",\"approvalTypeName\":null,\"multiApproverMode\":\"ALL\",\"multiApproverModeName\":null,\"emptyApproverAction\":\"AUTO_PASS\",\"fallbackApprover\":\"\",\"fallbackApproverName\":null,\"sameSubmitterAction\":\"SKIP\",\"approverType\":\"ROLE\",\"approverDirection\":\"BOTTOM_UP\",\"approverList\":[\"org_admin\"],\"approverSelectOptions\":[{\"id\":\"org_admin\",\"name\":\"org_admin\"}],\"ccType\":null,\"ccDirection\":\"BOTTOM_UP\",\"ccList\":[],\"ccSelectOptions\":null,\"passPostConfig\":null,\"rejectPostConfig\":null,\"fieldPermissions\":[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]},{\"id\":\"384849814413647875\",\"number\":\"PN003\",\"name\":\"结束\",\"nodeType\":\"END\",\"sort\":2}],\"links\":[{\"id\":\"384849814413647876\",\"fromNodeId\":\"384849814413647873\",\"toNodeId\":\"384849814413647874\"},{\"id\":\"384849814413647877\",\"fromNodeId\":\"384849814413647874\",\"toNodeId\":\"384849814413647875\"}],\"optionMap\":{}}'),('384850011982143494',_binary 'PK\0\0\�h\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��[��Fǿώd6x߈M#+6 �N�j�b\�xC�[�!i�Z�}ʭRSU�%mR�U�P�/M�nV�4�����\�e���O\�9\��\�p\�ρ\�	e��=�\�Y�\�x�\�\Z|�Mst��Qf!p\���\�\�^\�\�\�i���\���:�\0bkGW�	\�\�Z�\�\�`8\0/O�=�>�z�\��\�\�fﾺ�\�)�M<\�\�|b7=A\�DdK\�/�\"lB05*\�\�\��5m�kb\��9�	-\�D1��\�б�c�*�\����m{\��ȼ�@\�A�B\"\�-\�C\��\�0k֑�\�/\�m\�\�i	��{\0�!Ɇ���j��,\�\�\� �<� \�x��\�\�\�9\0�\�	c\�r�\0y�J.�\n���[\�Hs|�m5\�|�\��$6kb\Zt���\�}1\� ȥ�2�>���S\�\��\�$\�HG�tU\�\�{�(t�;{�\�ū�\�im\�M\�f��~?}\�f�\�P\�\n��p�8���\�np\�}1\�8}\�\�㋟78��Y\�3��O�mp\�tᆸ*ӏ\����}7�\��\�\�b\�\�@��\��?\�~�@�\�c\�!���R;#�ak�G�\�H�)v�ʼ����ǱjI\"�A\���H}�@\�m�Sz�ۣ\�s\��&R\�>��@\�Y���\�\'\�\�^��\�j\�G�\�aں$���QE>mM\��\�Hc(ż]\��\�\�(�*\�-\n\�J4��2\�(�+\�6\n�\�\�C�\�N�F��0\�@%T��*!�<T=䱊�!�T���6��&Q�El+��(\� �׫� *\��\�\�zx\�Y���MhLvBS�\�\�\��\�\�d\Z#��4���\nx�,\�\�x\r̮�p4\��{v�̞_��\�\�ZZ��\�@��B�Z^�\� 7�\�\Z\�6���k�ل\�\'k�lp|\� 1\n\�|P��|��F&R<\�\Z\�q\�ϑ��Yf��ג93ej7{J�?�\�\�R徘Y\�\�0	�.\�<8f��x\�ÇJy\�\� �\�\�F\r\�8X��\�\�\�/|\�sX,��f�L��i^��iη�bVv��}#/@ϝXG\�*�a\�\�\��\�\�\�`-&_\Z\�b\�t�cZ4Wo-\�\�\n�z\�h\"�\"��\Z\�W\rlW�\�U�\�y�bqx�bqx\��kܿ��4W��<\���\����\n~��\r�Atn[\�\�U-�\�k=G͟�ȎȻ\�\�R��\�\�\�\�z3�[�\�>�wrz�?PK�q�\�.\0\0�\0\0',_binary '{\"id\":\"384847838728691712\",\"currentVersionId\":\"384850011982143488\",\"number\":\"CTR-APV-00001\",\"name\":\"合同审批流程\",\"formType\":\"contract\",\"createExecute\":true,\"updateExecute\":true,\"enable\":false,\"description\":\"\",\"submitterCanRevoke\":true,\"allowBatchProcess\":true,\"allowWithdraw\":true,\"allowAddSign\":true,\"duplicateApproverRule\":\"FIRST_ONLY\",\"requireComment\":true,\"createUserName\":\"Administrator\",\"updateUserName\":\"Administrator\",\"createTime\":1780462985778,\"updateTime\":1780463238543,\"createUser\":\"admin\",\"updateUser\":\"admin\",\"permissions\":[{\"id\":\"CONTRACT:READ\",\"name\":\"查看\"},{\"id\":\"CONTRACT:ADD\",\"name\":\"添加\"},{\"id\":\"CONTRACT:UPDATE\",\"name\":\"编辑\"},{\"id\":\"CONTRACT:DELETE\",\"name\":\"删除\"},{\"id\":\"CONTRACT:EXPORT\",\"name\":\"导出\"},{\"id\":\"CONTRACT:STAGE\",\"name\":\"合同阶段变更\"},{\"id\":\"CONTRACT:PAYMENT\",\"name\":\"回款\"}],\"statusPermissions\":[{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true}],\"nodes\":[{\"id\":\"384850011982143489\",\"number\":\"PN001\",\"name\":\"开始\",\"nodeType\":\"START\",\"sort\":0},{\"id\":\"384850011982143490\",\"number\":\"PN002\",\"name\":\"审批人\",\"nodeType\":\"APPROVER\",\"sort\":1,\"approvalType\":\"MANUAL\",\"approvalTypeName\":null,\"multiApproverMode\":\"ALL\",\"multiApproverModeName\":null,\"emptyApproverAction\":\"AUTO_PASS\",\"fallbackApprover\":\"\",\"fallbackApproverName\":null,\"sameSubmitterAction\":\"SKIP\",\"approverType\":\"ROLE\",\"approverDirection\":\"BOTTOM_UP\",\"approverList\":[\"org_admin\"],\"approverSelectOptions\":[{\"id\":\"org_admin\",\"name\":\"org_admin\"}],\"ccType\":null,\"ccDirection\":\"BOTTOM_UP\",\"ccList\":[],\"ccSelectOptions\":null,\"passPostConfig\":null,\"rejectPostConfig\":null,\"fieldPermissions\":[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]},{\"id\":\"384850011982143491\",\"number\":\"PN003\",\"name\":\"结束\",\"nodeType\":\"END\",\"sort\":2}],\"links\":[{\"id\":\"384850011982143492\",\"fromNodeId\":\"384850011982143489\",\"toNodeId\":\"384850011982143490\"},{\"id\":\"384850011982143493\",\"fromNodeId\":\"384850011982143490\",\"toNodeId\":\"384850011982143491\"}],\"optionMap\":{}}'),('384850183780835328',_binary 'PK\0\0\�h\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�VJ\�\�+)JL.	.ILOU�Rz��\��\�}\�\�nR�\0PK�O\� \0\0\0\0\0\0',_binary '{\"contractStage\":\"已签署\"}'),('384850218140573696',_binary 'PK\0\0\�h\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�VJ\�\�+)JL.	.ILOU�Rz�}\�\���\�ݤT\0PKWɓ� \0\0\0\0\0\0',_binary '{\"contractStage\":\"待签署\"}'),('384897428421091328',_binary 'PK\0\0\�t\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�VJ\�KL\�IU�JK\�)N�\0PK�e�\0\0\0\0\0\0',_binary '{\"enable\":true}'),('384898124205793281',_binary 'PK\0\0u\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zipu�QO\� ���\�yM.FY_�Y�R���bp�٤��\Z��\�\�%>H\�=�\�\�o\�iR&y�� ���\'+r\�F\�4v \�RH,@��䈣�\�(\�\�C*ZJ\��Q�Z\�\��\�&��*�\�9Z�Y��\�N\�\�:\�sd���opF�ܔB0H�\�}\�\�\�jp\�RA]PHUqx�ͷ\�(@�O�W\�\�\�I\���B����o\�OA3\�C\�\�5\�\�u\�l\�\��\'>\\vBF��\�V\�X��K\�\�\Z�\�:�h\�\�,�l\���\�\�v_*t\�\�K\�\�)}t	~PKE|�@	\0\0�\0\0',_binary '{\"id\":\"384848921060450304\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780463111066,\"updateTime\":1780468839335,\"name\":\"Yundy-Zahid Tractor\",\"customerId\":\"384831079766302720\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000002\",\"approvalStatus\":\"NONE\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1782316800000,\"endTime\":1813852800000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":null}'),('384898596652195846',_binary 'PK\0\01u\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��ݎ�V\�߅kG2\�6x\�M#+6 �N�j�b\�xC��I�\�J\�UӤRSU�R�mR�U{Q�7M�nVy�\�ۼE`0`���\�\�{f\�ǜ9�3\�Љ�b\�L�f(�n1\�I�-�Ah>��FS\0=ñ��_�\�$\�\�\"\�T�a��\�[\�\0bk_�n�\�\�F���A�\0^�?{<\�\��\�O�/�Y��\�귧\�6s��<r�\�\��\Z\n.	��\0\�	\�|�M��A����l\�\�L�Ӂ�A\�E8O\� \�?��\0쫶8���j�\�Û*\�\�\�р\�ewt_�\�\�\�\"�\�qb\'\�]\�\�pJ�\�B\���dB|0�d\�H\�G\�p|\�\�\�\�5�C��M<\0��6�n�\�\��#\�^�8D\��$\�4\�\�V�\�\�4ǦM\�a\�.��.F�2s�Ԣ�ex��\�\�|xɣ/\��\�\���c��]��\�\���\�y#\�\�\�^��?y��k\"X�[9^]~�߻�78��v�?~\����78rwEARR�\\\�?�\�\�(+\�-.�\�\�\��Z�~3�\��\�şbD\�ޘ\�\�\�?.~G�b�!�����\Z\�C5\�Њ#$n*\�\��2o(o�m=M�HePt\0	g��^=PrF�甜\�\�\�\��\�X\n�g�H1�EI��[�k�UZ\rŨu=\�B[�\�.�*�(��\�bXiL����>Q�UZ%X�E	Z��Q�VE%p\�\�F	Xy�?\�K\�(�F��*�P$Q����\"Vy1��?C\�\�&\�\�$j��`՟�\ZD�z�D\�ހ\�:m\�=��\��ᬗ\�D>;�]~:�5\�\�r\�Y�\��\'�f\�\n�\��yp+\�/.�\�\�>�O6�b,]\�,?aGDv=\Z�l\�4�\�Ȉ��1f\�Q�fI�\�E�b#�-�Dv�G\"+\��0�ǼcU;���2��fz��Ϙ	S�=��\\\�KF\\ju�\�\�8ঠ(\��h��\Z\�i*\����h*;\\e`\�`!�tSG�\�M\�a�HEӢd�\�5\��$4my�0&w�(\�U=Ot<\�w\�q�B\�v]_��\�\�Q�PhQL�\�#;4\�%\�f7s#,+8rwlK ]7��ثH6\�v\�2T\�\�0T\�\�0\�-{<�����\�B�>��f\�\�\�lW�OӤ�����}��%\��F5��\�c\�\�/Z��\"\�Z;\�}קO\�\�ι�N�w�\�qc\�%\�\�\��PK~hu\00\0\0�\0\0',_binary '{\"id\":\"384847838728691712\",\"currentVersionId\":\"384898596652195840\",\"number\":\"CTR-APV-00001\",\"name\":\"合同审批流程\",\"formType\":\"contract\",\"createExecute\":true,\"updateExecute\":true,\"enable\":true,\"description\":\"\",\"submitterCanRevoke\":true,\"allowBatchProcess\":true,\"allowWithdraw\":true,\"allowAddSign\":true,\"duplicateApproverRule\":\"FIRST_ONLY\",\"requireComment\":true,\"createUserName\":\"Administrator\",\"updateUserName\":\"Administrator\",\"createTime\":1780462985778,\"updateTime\":1780468894349,\"createUser\":\"admin\",\"updateUser\":\"admin\",\"permissions\":[{\"id\":\"CONTRACT:READ\",\"name\":\"查看\"},{\"id\":\"CONTRACT:ADD\",\"name\":\"添加\"},{\"id\":\"CONTRACT:UPDATE\",\"name\":\"编辑\"},{\"id\":\"CONTRACT:DELETE\",\"name\":\"删除\"},{\"id\":\"CONTRACT:EXPORT\",\"name\":\"导出\"},{\"id\":\"CONTRACT:STAGE\",\"name\":\"合同阶段变更\"},{\"id\":\"CONTRACT:PAYMENT\",\"name\":\"回款\"}],\"statusPermissions\":[{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true}],\"nodes\":[{\"id\":\"384898596652195841\",\"number\":\"PN001\",\"name\":\"开始\",\"nodeType\":\"START\",\"sort\":0},{\"id\":\"384898596652195842\",\"number\":\"PN002\",\"name\":\"审批人\",\"nodeType\":\"APPROVER\",\"sort\":1,\"approvalType\":\"MANUAL\",\"approvalTypeName\":null,\"multiApproverMode\":\"SEQUENTIAL\",\"multiApproverModeName\":null,\"emptyApproverAction\":\"AUTO_PASS\",\"fallbackApprover\":\"\",\"fallbackApproverName\":null,\"sameSubmitterAction\":\"SKIP\",\"approverType\":\"ROLE\",\"approverDirection\":\"BOTTOM_UP\",\"approverList\":[\"org_admin\"],\"approverSelectOptions\":[{\"id\":\"org_admin\",\"name\":\"org_admin\"}],\"ccType\":null,\"ccDirection\":\"BOTTOM_UP\",\"ccList\":[],\"ccSelectOptions\":null,\"passPostConfig\":null,\"rejectPostConfig\":null,\"fieldPermissions\":[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]},{\"id\":\"384898596652195843\",\"number\":\"PN003\",\"name\":\"结束\",\"nodeType\":\"END\",\"sort\":2}],\"links\":[{\"id\":\"384898596652195844\",\"fromNodeId\":\"384898596652195841\",\"toNodeId\":\"384898596652195842\"},{\"id\":\"384898596652195845\",\"fromNodeId\":\"384898596652195842\",\"toNodeId\":\"384898596652195843\"}],\"optionMap\":{}}'),('384898931659644929',_binary 'PK\0\0Fu\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��AO\� ���\�\�&�@{\�h\�\�R��O�lHZh(�Q\�Z�\�b\�B2\�c\��\�(ԠJPQVS\�)\0\�P�^��A?\�گ�T0A8$�HD�\�?\�\�\�`F�\Z\�P�	I\0\��UpY\�\Z\�\�,��h\�{�ʛ�4\�\�.�M\�ܨ}w��\�\�\Zs�\�f�\�$Gm@\r�%��,�/|\�lI�0`%\�3;Mޝ\�p2\�9A�m\�&}\�#޵�u\�\�ݾO\�:\�akEI��H[un�9&𣟜Q\�Z\�΢\�\�aH\��QZ\�!�qv)��<�K!\�\�7PK��\�-\0\0�\0\0',_binary '{\"id\":\"384832694674006016\",\"createUser\":\"384244868270006280\",\"updateUser\":\"384244868270006280\",\"createTime\":1780461222707,\"updateTime\":1780468933572,\"name\":\"Yundy-Al-Futtaim Auto\",\"customerId\":\"384831827090612224\",\"owner\":\"384244868270006280\",\"amount\":0,\"number\":\"Con-202606-000001\",\"approvalStatus\":\"NONE\",\"stage\":\"PENDING_SIGNING\",\"startTime\":1746201600000,\"endTime\":1781712000000,\"voidReason\":null,\"organizationId\":\"100001\",\"pos\":null}'),('384899713343692806',_binary 'PK\0\0vu\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��[��Vǿώd�6x߈M\"+6P�N�j�b\�\�.��h�R�Դ��T��Di�Tj\�>T\�KӪ�U>M\�m�E`0��\\\�}\��1gΟ�\�0\rb��\�\�bX�e(�\�%�\"\Z�@4\�7]g��u\�v�\�iSd�Ͷ�\�\�	\�C\0���\�\�8ir���\�Р\�\0/O�=�>{2}\�\�\�fo���\�1��\�Vz�]w5���@C�\0\�\0a�h�g�.G;�\��\�\�\�\�\�1\�m!\0{�#�{\�I\�Y�{���\��tu\��9\�m\�5�v?�\��b;\�\�\�2u�\�yн���7���\�\�N\0�\���k۸�Ih����׆3l\�1}�\�B\"\�\�1A5C#ɰ\�V�\�\�0l�5�l�E��\�\�b�\"s\�\�,z\0ڦ8.\�\'��<z��\�\\Oݓy��8\�٫_.�L�5�ݸ~\�\�\�wӯ_�\�\ZK}N\���\��\���5�}~\�g��^x\�\�\ZG�cI�Ռ\�\�/\�\�8**w�_V\�\�\�޼�>}>{�\���3\�,�右\�\�g�XnHC�/-\�N�\��YJd\�2?o\��\\�ה7ֶ�&L�2(>��s�Y~=PzF\�甞\�\��\��w�\�D\n\�g�H1��$Y���\�k�UZ\rŨU=lC[�\�6�*�(��\�bXi�����>Q�UZ%X�E	Z��Q�VE%p\�\�F	XyH�\�\�I\�(�F��*�P$Q����\"Vy1��?Cv\�&v\�$j��-`՟�\ZD�z�D\�ހ\�:\�=��\��\�\�g��\�.>��\Zb!d>�ᬣ�.\�K3}^S\�`*�\�\�\�\�\��>\�O6\�b\�]F�0\�D~=����\Z�X\�L��f�9\��qyQ\��C6\Z\�z�9}>+rcU<�8E	gR<\�j�I\���˫Y��+ɨ�2�[)\��\�\�\�\�Ϭ\�\�t�\\UU��QC<\�\�%\\x|g��,,FoF\�\�8K�bt=N&\�^\�7%�\�\�\�G1KW��=\�\�%\�G=\�92��U>Ů�\�G&��\��(ZL�+P4\�iu\�6CwH�\�\�\�\�\nN�\�h0�\"��\�\�\r\�\�$�u\�\�Y�fqX�fq\�\�C\�7\�z��Й�ﾝ�\�*\�\\\�C5\�+T�s\�tN�ꌭ𾆮-`\��[a�D\�f;ElN�]H�\n\�tt��\�7\�<b\�\�\�\�PK�\�\�u2\0\0�\0\0',_binary '{\"id\":\"384847838728691712\",\"currentVersionId\":\"384899713343692800\",\"number\":\"CTR-APV-00001\",\"name\":\"合同审批流程\",\"formType\":\"contract\",\"createExecute\":true,\"updateExecute\":true,\"enable\":true,\"description\":\"\",\"submitterCanRevoke\":true,\"allowBatchProcess\":true,\"allowWithdraw\":true,\"allowAddSign\":true,\"duplicateApproverRule\":\"FIRST_ONLY\",\"requireComment\":true,\"createUserName\":\"Administrator\",\"updateUserName\":\"Administrator\",\"createTime\":1780462985778,\"updateTime\":1780469024965,\"createUser\":\"admin\",\"updateUser\":\"admin\",\"permissions\":[{\"id\":\"CONTRACT:READ\",\"name\":\"查看\"},{\"id\":\"CONTRACT:ADD\",\"name\":\"添加\"},{\"id\":\"CONTRACT:UPDATE\",\"name\":\"编辑\"},{\"id\":\"CONTRACT:DELETE\",\"name\":\"删除\"},{\"id\":\"CONTRACT:EXPORT\",\"name\":\"导出\"},{\"id\":\"CONTRACT:STAGE\",\"name\":\"合同阶段变更\"},{\"id\":\"CONTRACT:PAYMENT\",\"name\":\"回款\"}],\"statusPermissions\":[{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true}],\"nodes\":[{\"id\":\"384899713343692801\",\"number\":\"PN001\",\"name\":\"开始\",\"nodeType\":\"START\",\"sort\":0},{\"id\":\"384899713343692802\",\"number\":\"PN002\",\"name\":\"审批人\",\"nodeType\":\"APPROVER\",\"sort\":1,\"approvalType\":\"MANUAL\",\"approvalTypeName\":null,\"multiApproverMode\":\"ALL\",\"multiApproverModeName\":null,\"emptyApproverAction\":\"AUTO_PASS\",\"fallbackApprover\":\"\",\"fallbackApproverName\":null,\"sameSubmitterAction\":\"SKIP\",\"approverType\":\"MULTIPLE_SUPERIOR\",\"approverDirection\":\"BOTTOM_UP\",\"approverList\":[\"2\"],\"approverSelectOptions\":[],\"ccType\":null,\"ccDirection\":\"BOTTOM_UP\",\"ccList\":[],\"ccSelectOptions\":null,\"passPostConfig\":null,\"rejectPostConfig\":null,\"fieldPermissions\":[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]},{\"id\":\"384899713343692803\",\"number\":\"PN003\",\"name\":\"结束\",\"nodeType\":\"END\",\"sort\":2}],\"links\":[{\"id\":\"384899713343692804\",\"fromNodeId\":\"384899713343692801\",\"toNodeId\":\"384899713343692802\"},{\"id\":\"384899713343692805\",\"fromNodeId\":\"384899713343692802\",\"toNodeId\":\"384899713343692803\"}],\"optionMap\":{}}'),('384900185790095366',_binary 'PK\0\0�u\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��ݎ�V\�߅kG2`\�;b\�Ȋ\r�\�(Z�X8�\�嫇C\�h�R{մ�\�D��DI�Tj\�^T\�MӪ�U��\�6o\��w��}e���1g\�\�\�	a�\�A��ð4\�Pl�#�\"Z�B\\40�<w��qC\�t�\�q\�nc?7t\�־�\\\�\�\�6���Aw\0^�=y4{\�\�\�\�O\�����\�\�\�\�v\�AG{\�Gv\�s\�\r]\�3`��A�}s}�����2A`@\�G8OĠ <t,�\0\�\�\�{Ǚ�n\�ރ\�:2\�\�\�3@�,tτ��\�\"o��u\�\�.��e\��x߇\�}\0�0ʄ�h��ځ$�n\� �4� \�{��k��&��\0�Imxӱ\\+��G$ҽ^\�4+2�\�\�\�(�\�2�\�\�M\\�\�p�n���G\�µr�>��D�s\�$�G_5�\�k{���;\�\�\�\�\�\�ikՍ\��~7��\���<\�5a\�xq��\�np#!\�8{\��\�\�78\n˒�\��8�}y��Q\��ªB?<�k�\�\�\�\�g\�n���\�cA\�\�_�8��=q��\�t\�J\�\�X��\�V�S\�0(�yCym��h�Dj��\�8G�4eg�}N\�)n�\�\�y;L��}VK���xYV�\�P���\�Q�\�P�Z\�\�6�uIlC���rښ.��Ց\�DLx�\�X�\�Q�U�[T�\�hhu\�QW�mT�Ց�,���\�2Pea��j��UCe�:z(cUC��=dmbwM�A�\�V��Q�A4�WuA4\�\r��\�\�\�ܳ|J_\�\��p&�š\��\�ٯ\� A�\�:.@\�A<���G\�50�\n�r\�x\��\�\�\�^\�S\�\�d++\�\�e̋~Dד1\�\rm�E8���t\�\Zcv\�Ek�|p|\�05\�\�bH\�\'�t \�\Z\r�x\�;ԍ\�\�)�!WW\�\�\0W\�3c�7�r�?�\�&#m(��u\"\�PRr.<#�\�\�%M�\��<b�G?|\�E\�/U`\� )w�\�\�&\�H.�dg�q\rcA�cV@I���\��\�G\�\�t�O�\����lsu\��\�\�\�:\�e\�ɴ{�/*4\n�\�\�@�i \�4�kH��v��t\�\�t\�Ⱍ+\��y\�W��\�}7�\�U�k\�e\�0��\�ٖ{|U\�\�D�[\�9\"fl~c\�@\�]n��\�\�\�ҩ:�.\�\�\�X\����\�\��PK\�\�X*\0\0�\0\0',_binary '{\"id\":\"384847838728691712\",\"currentVersionId\":\"384900185790095360\",\"number\":\"CTR-APV-00001\",\"name\":\"合同审批流程\",\"formType\":\"contract\",\"createExecute\":true,\"updateExecute\":true,\"enable\":true,\"description\":\"\",\"submitterCanRevoke\":true,\"allowBatchProcess\":true,\"allowWithdraw\":true,\"allowAddSign\":true,\"duplicateApproverRule\":\"FIRST_ONLY\",\"requireComment\":true,\"createUserName\":\"Administrator\",\"updateUserName\":\"Administrator\",\"createTime\":1780462985778,\"updateTime\":1780469079922,\"createUser\":\"admin\",\"updateUser\":\"admin\",\"permissions\":[{\"id\":\"CONTRACT:READ\",\"name\":\"查看\"},{\"id\":\"CONTRACT:ADD\",\"name\":\"添加\"},{\"id\":\"CONTRACT:UPDATE\",\"name\":\"编辑\"},{\"id\":\"CONTRACT:DELETE\",\"name\":\"删除\"},{\"id\":\"CONTRACT:EXPORT\",\"name\":\"导出\"},{\"id\":\"CONTRACT:STAGE\",\"name\":\"合同阶段变更\"},{\"id\":\"CONTRACT:PAYMENT\",\"name\":\"回款\"}],\"statusPermissions\":[{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true}],\"nodes\":[{\"id\":\"384900185790095361\",\"number\":\"PN001\",\"name\":\"开始\",\"nodeType\":\"START\",\"sort\":0},{\"id\":\"384900185790095362\",\"number\":\"PN002\",\"name\":\"审批人\",\"nodeType\":\"APPROVER\",\"sort\":1,\"approvalType\":\"MANUAL\",\"approvalTypeName\":null,\"multiApproverMode\":\"SEQUENTIAL\",\"multiApproverModeName\":null,\"emptyApproverAction\":\"AUTO_PASS\",\"fallbackApprover\":\"\",\"fallbackApproverName\":null,\"sameSubmitterAction\":\"SKIP\",\"approverType\":\"MULTIPLE_SUPERIOR\",\"approverDirection\":\"BOTTOM_UP\",\"approverList\":[\"2\"],\"approverSelectOptions\":[],\"ccType\":null,\"ccDirection\":\"BOTTOM_UP\",\"ccList\":[],\"ccSelectOptions\":null,\"passPostConfig\":null,\"rejectPostConfig\":null,\"fieldPermissions\":[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]},{\"id\":\"384900185790095363\",\"number\":\"PN003\",\"name\":\"结束\",\"nodeType\":\"END\",\"sort\":2}],\"links\":[{\"id\":\"384900185790095364\",\"fromNodeId\":\"384900185790095361\",\"toNodeId\":\"384900185790095362\"},{\"id\":\"384900185790095365\",\"fromNodeId\":\"384900185790095362\",\"toNodeId\":\"384900185790095363\"}],\"optionMap\":{}}'),('384906001175814150',_binary 'PK\0\0�v\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip��[�\�Tǿ��Sɗ$�\�\�ML5��/i+�Zy\���Y\�8�{\�j%x��H!��-Py� ��~\Z��߂c;v\�$��$y\�왙�\�\��g\�\�	f�\�F1]�K3C�L�%h�\�:�A\�p\n``y\�h\�\�\�8�\�h\�\�Q}���s �T�\Z\'M�\�\�C\�\�hy\�\�\�\�ٗ�\�?Ϳ�g�泋ߞ\"ۑ\��\�\r\�\r�n�\�%!\�C�?F\"S#\��\"\�\\_�~h\��� 0�\�(OD� :t�0p��2�\�箺m{�\�qO����d�e�\�L�?(-r��Xw\��b�o[J�\�}\�\�P�\�L�F���\��J\0�O\"��\�8��Yh�?-\0PHkÙ�\�Z\�\�A,\�\�)A�b#A3x�O�\�8h&�-�X�fY�,^!\�Y�Va\�б���Qa>:I\�1U\�\�\�s\�\��\�_�r\��S촳\�\�\r�^��=y��K���\�//ο�\�\�\����/:\��z�\�\��ے(�\�?\�g��mpTT\���\�\�\����~3�\���şb$\�΄�\�?\���\�#��z\�J\�\�D��$V!\�S\�&?,�yCySm��h\�D\Z�\�\�9G��\�g�}N�)n�\�\�y;̤�}VK�T�8I�\�\�H����Q�\�P�Z\�\�6�uIlCk��jښ.��5��&��]\�\Z�\�\��j\�-j\�\Z4�\Z�&ꨁ�\�6j��\�C\�\�N�F��0�@\rTQ�j �*T=T�ꋡ�\����6��&ѢElk~�h\� \�׫� Z\�\�\�\�zh\�Y>��\rgDq8��\�Pv�\�\�\�x�!�Ae� \� �X\��x\rL��\�8�\��=;+���s<\�ɋ�p�p�ƍ�\�z:��mw0\'�C+�&�\�\���\��5�b4p�\�Qf\�Ŭ\�i�x q�Ϥh\�;ԍ\�\�)%WW�\�\0}W�Q3g*7GR�\r\0�\�icu$��E�xy$\��!\Z�\�뢪�����	4Fb�\�E\�(HL�\�X\�d\�\�\�\�\�2�a,�I\�\n(\r\�\� �� x\�u7[�\�c亾~d\�\\��\�\�I1�.K\�h�K\Z\�\���\�t\�\�J�+鶁L\�@�e ��\r\�d��\�a��\�a�W\�q�\��A�\��\�\�\�7\�^���i\�}��;�m�\�Wu�n����# \�\�Wq+�\�\�$vy��J:YA���^\�\�>�wrz�?PK��/\0\0�\0\0',_binary '{\"id\":\"384847838728691712\",\"currentVersionId\":\"384906001175814144\",\"number\":\"CTR-APV-00001\",\"name\":\"合同审批流程\",\"formType\":\"contract\",\"createExecute\":true,\"updateExecute\":true,\"enable\":true,\"description\":\"\",\"submitterCanRevoke\":true,\"allowBatchProcess\":true,\"allowWithdraw\":true,\"allowAddSign\":true,\"duplicateApproverRule\":\"FIRST_ONLY\",\"requireComment\":true,\"createUserName\":\"Administrator\",\"updateUserName\":\"Administrator\",\"createTime\":1780462985778,\"updateTime\":1780469756703,\"createUser\":\"admin\",\"updateUser\":\"admin\",\"permissions\":[{\"id\":\"CONTRACT:READ\",\"name\":\"查看\"},{\"id\":\"CONTRACT:ADD\",\"name\":\"添加\"},{\"id\":\"CONTRACT:UPDATE\",\"name\":\"编辑\"},{\"id\":\"CONTRACT:DELETE\",\"name\":\"删除\"},{\"id\":\"CONTRACT:EXPORT\",\"name\":\"导出\"},{\"id\":\"CONTRACT:STAGE\",\"name\":\"合同阶段变更\"},{\"id\":\"CONTRACT:PAYMENT\",\"name\":\"回款\"}],\"statusPermissions\":[{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"REVOKED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":false},{\"approvalStatus\":\"APPROVING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"UNAPPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":false},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"PENDING\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:READ\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:ADD\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:UPDATE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:DELETE\",\"enabled\":false},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:EXPORT\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:STAGE\",\"enabled\":true},{\"approvalStatus\":\"APPROVED\",\"permission\":\"CONTRACT:PAYMENT\",\"enabled\":true}],\"nodes\":[{\"id\":\"384906001175814145\",\"number\":\"PN001\",\"name\":\"开始\",\"nodeType\":\"START\",\"sort\":0},{\"id\":\"384906001175814146\",\"number\":\"PN002\",\"name\":\"审批人\",\"nodeType\":\"APPROVER\",\"sort\":1,\"approvalType\":\"MANUAL\",\"approvalTypeName\":null,\"multiApproverMode\":\"ANY\",\"multiApproverModeName\":null,\"emptyApproverAction\":\"AUTO_PASS\",\"fallbackApprover\":\"\",\"fallbackApproverName\":null,\"sameSubmitterAction\":\"SKIP\",\"approverType\":\"ROLE\",\"approverDirection\":\"BOTTOM_UP\",\"approverList\":[\"org_admin\"],\"approverSelectOptions\":[{\"id\":\"org_admin\",\"name\":\"org_admin\"}],\"ccType\":null,\"ccDirection\":\"BOTTOM_UP\",\"ccList\":[],\"ccSelectOptions\":null,\"passPostConfig\":null,\"rejectPostConfig\":null,\"fieldPermissions\":[{\"fieldId\":\"384238649157361706\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361707\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361708\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361709\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361710\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361715\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361837\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361838\",\"permissionType\":\"VIEW\"},{\"fieldId\":\"384238649157361840\",\"permissionType\":\"VIEW\"}]},{\"id\":\"384906001175814147\",\"number\":\"PN003\",\"name\":\"结束\",\"nodeType\":\"END\",\"sort\":2}],\"links\":[{\"id\":\"384906001175814148\",\"fromNodeId\":\"384906001175814145\",\"toNodeId\":\"384906001175814146\"},{\"id\":\"384906001175814149\",\"fromNodeId\":\"384906001175814146\",\"toNodeId\":\"384906001175814147\"}],\"optionMap\":{}}'),('385629866373996551',NULL,_binary '{\"id\":\"385629866373996544\",\"createUser\":\"384244868270006278\",\"updateUser\":\"384244868270006278\",\"createTime\":1780554025768,\"updateTime\":1780554025768,\"name\":\"Tuwaiq & Han\",\"owner\":\"384244868270006278\",\"collectionTime\":1780554025768,\"poolId\":null,\"inSharedPool\":false,\"organizationId\":\"100001\",\"follower\":null,\"followTime\":null,\"reasonId\":null,\"384238649157361809\":\"3\",\"384238649157361810\":\"1\",\"384238649157361811\":\"2\",\"384238649157361812\":\"1\",\"384238649157361813\":\"2\",\"384238649157361816\":\"KSA-\"}'),('385630055352557570',NULL,_binary '{\"id\":\"385630055352557568\",\"createUser\":\"384244868270006278\",\"updateUser\":\"384244868270006278\",\"createTime\":1780554047855,\"updateTime\":1780554047855,\"customerId\":\"385629866373996544\",\"owner\":\"384244868270006278\",\"name\":\"Fahad Alaqil (CEO)\",\"phone\":\"+966564673363\",\"enable\":true,\"disableReason\":null,\"organizationId\":\"100001\",\"384238649157361757\":\"info@tuwaiqwahan.com\"}'),('385630338820399111',NULL,_binary '{\"id\":\"385630338820399104\",\"createUser\":\"384244868270006278\",\"updateUser\":\"384244868270006278\",\"createTime\":1780554080620,\"updateTime\":1780554080620,\"name\":\"PORTMNT\",\"owner\":\"384244868270006278\",\"collectionTime\":1780554080620,\"poolId\":null,\"inSharedPool\":false,\"organizationId\":\"100001\",\"follower\":null,\"followTime\":null,\"reasonId\":null,\"384238649157361809\":\"3\",\"384238649157361810\":\"1\",\"384238649157361811\":\"2\",\"384238649157361812\":\"1\",\"384238649157361813\":\"2\",\"384238649157361816\":\"KSA-\"}'),('385630459079483394',NULL,_binary '{\"id\":\"385630459079483392\",\"createUser\":\"384244868270006278\",\"updateUser\":\"384244868270006278\",\"createTime\":1780554094942,\"updateTime\":1780554094942,\"customerId\":\"385630338820399104\",\"owner\":\"384244868270006278\",\"name\":\"Procurement Team\",\"phone\":\"+966547178046\",\"enable\":true,\"disableReason\":null,\"organizationId\":\"100001\",\"384238649157361757\":\"info@portmnt.com\"}'),('385630828446670850',NULL,_binary '{\"id\":\"385630828446670848\",\"createUser\":\"384244868270006278\",\"updateUser\":\"384244868270006278\",\"createTime\":1780554137808,\"updateTime\":1780554137808,\"customerId\":\"385630338820399104\",\"owner\":\"384244868270006278\",\"name\":\"Procurement Team 1\",\"phone\":\"+966547178045\",\"enable\":true,\"disableReason\":null,\"organizationId\":\"100001\",\"384238649157361757\":\"sales@portmnt.com\"}'),('385652689830223872',_binary 'PK\0\0�x\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip\�V\�OA�_\�\\�\�Jo��H���[=B��\�\�ٙe~X�\�\�	5\�A�\�\'�&\"�gh���3��\�E�\�\��\���\�\�LwA#\�\nP|��� [\�Mg3����lvfj6�@��t�s\���w\�y��w\�UG1��SH��t�Б����\�|�4\�Tȝ�|�8o\�o\�*\�5���>k`�Ò+�\�c�\�@$	:\�c\�\�HE�\�\0	�\�@bF�GЅ��X�\�=®\�\� �\�\����\�f84G[\ns\�\�z4��YpF֢��KC	L�1ϘಫY�X�~n���஛�S\�AK��.�A�jئ\�J؅\�\�z;Rɪ\�\�\�jiM�;\�o\�\�5�\�\�q\��K�g�\�\�\0�ts8\�x��+\�\����\�zg0\�Όڅ��]8x�a\��MQ�\��\rX.W\�\��\�=�h]u=!40T\�n�\�\�\�75�\"\�!$\n\��\�%ZGݯɸ�������?�\������\�CL�c\�\�]�;��\�7\n�\�\�/�\�\�:����z�\�U�oH\�~�<�j&	)���hw?eAL\��/Wc�\ZqZ�b�M�KM�<�xy�\�\�\�l�	�M߶|߄\�\�\�Bxg��w�\�\��\�\�\�Aa)\��uaԉ�b�%��\�.��d�5�\�.x�Q���\Z����\�{Ɣ�{�~՘��7����v\�qe�\\�4�k�=�Y�6\�\�B}%\�6u\�\�C\�\�@45\�l\�P�\���w~\�;?잞w^|\Z(oB\"\�;�o�\'{W\�֣�<a\�h�&��ziîlX��=o\�\�PN�ۨ\�`ܐ\�n���\�-Ps\�Fo�ۿ\0PK)�J\�\0\0]\n\0\0',_binary '{\"fields\":[{\"id\":\"384238649157361755\",\"name\":\"客户名称\",\"internalKey\":\"contactCustomer\",\"pos\":0,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"customerId\",\"disabledProps\":[],\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"CUSTOMER\",\"combineSearch\":null,\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null},{\"id\":\"384238649157361756\",\"name\":\"姓名\",\"internalKey\":\"contactName\",\"pos\":1,\"type\":\"INPUT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"name\",\"disabledProps\":[\"readable\",\"mobile\",\"rules.required\"],\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"defaultValueType\":\"custom\",\"formula\":null},{\"id\":\"384238649157361757\",\"name\":\"邮箱\",\"internalKey\":\"contactEmail\",\"pos\":2,\"type\":\"INPUT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"defaultValueType\":\"custom\",\"formula\":null},{\"id\":\"384238649157361758\",\"name\":\"手机号\",\"internalKey\":\"contactPhone\",\"pos\":3,\"type\":\"PHONE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"unique\"}],\"showControlRules\":null,\"businessKey\":\"phone\",\"disabledProps\":[],\"resourceFieldId\":null,\"subTableFieldId\":null,\"format\":\"255\"},{\"id\":\"384238649157361759\",\"name\":\"负责人\",\"internalKey\":\"contactOwner\",\"pos\":4,\"type\":\"MEMBER\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"owner\",\"disabledProps\":[\"readable\",\"mobile\",\"rules.required\"],\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"hasCurrentUser\":true,\"initialOptions\":[]}],\"formProp\":{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":{\"clue-CLUE_TO_CONTACT\":[{\"current\":\"384238649157361756\",\"link\":\"384238649157361748\",\"enable\":true},{\"current\":\"384238649157361758\",\"link\":\"384238649157361749\",\"enable\":true}]}}}'),('385656581070594048',_binary 'PK\0\0�y\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip\�U\�OA�_\�\\��Jo��H���[=B��\�t\�tf�$�xB��\�\�x\�h\��	�	���\��\�\�n,��Ǿ\���\�}\�\�y;��q(>\�\�E�+\�\'s�\��lvj&7����@a\����{\�z\�\�����J\�)$\�ѶN:�J\�HK	\�ڈ\�\�4\�\��۞�\�=�^�\�W��N�Y�\\�-\�Y�\rD�@�q5R\�z	�cObFA�*B2�#\�\�F�\\,��=Įl�bvBአpԍ�2G�\ns\�\�ZH�\�3pFVú�KC	L�є\�xK�ᄅ\�\�V9\�\�\�$�\�Z4�uQ\"T\�6��\�.��\�ۡFV�fWVJ�\Z\�a\�n\\C�;�G�\\��\�\rL7F#Nw�J�`!�\�Jo\'���M�ڄ�\�z\r\�v�l�\"����K\�j\����\�P�=�3D*j77���@M��|\0�B\�Ţm	�Q\�k2\�V�\���\��O��_\�,�!&\'\�\��\���6\�֠\�xQH�\�={\�{w\�\�Qm1\ZP�؎\�Jy\\�RE\�\�\�\���\�\�\�o�\�J�8�OU�޳�\�G.�>����\�]\�\�\�\�c�WJ+\��\�<���Ƣ��\�ւ\�R�#*\�\�h��)��J�O�f$c�!�;\�1F�\Z~b<mH\�ˤ�S28/\�h_5V�\�\r��d�]\�]2O\�K\Z\�5	ں\�Y\'\�4�@_��\�:�\��\��&Ƙ�\Z\��ߎ�g����\�ə��\�Py1\\\�\�\�\�^\�[\�`RG�u\�Z��\�\�ʺU)\�s��rB\�\�β��&�/\\\���\�\rP�W�w�ݟPK�CQ=\�\0\0@\n\0\0',_binary '{\"fields\":[{\"id\":\"384238649157361755\",\"name\":\"客户名称\",\"internalKey\":\"contactCustomer\",\"pos\":0,\"type\":\"DATA_SOURCE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"customerId\",\"disabledProps\":[],\"resourceFieldId\":null,\"subTableFieldId\":null,\"dataSourceType\":\"CUSTOMER\",\"combineSearch\":null,\"showFields\":null,\"refFields\":null,\"linkFields\":null,\"childLinkFields\":null,\"listDisplayFields\":null},{\"id\":\"384238649157361756\",\"name\":\"姓名\",\"internalKey\":\"contactName\",\"pos\":1,\"type\":\"INPUT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"name\",\"disabledProps\":[\"readable\",\"mobile\",\"rules.required\"],\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"defaultValueType\":\"custom\",\"formula\":null},{\"id\":\"384238649157361757\",\"name\":\"邮箱\",\"internalKey\":\"contactEmail\",\"pos\":2,\"type\":\"INPUT\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"unique\"}],\"showControlRules\":null,\"businessKey\":null,\"disabledProps\":null,\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"defaultValueType\":\"custom\",\"formula\":null},{\"id\":\"384238649157361758\",\"name\":\"手机号\",\"internalKey\":\"contactPhone\",\"pos\":3,\"type\":\"PHONE\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"unique\"}],\"showControlRules\":null,\"businessKey\":\"phone\",\"disabledProps\":[],\"resourceFieldId\":null,\"subTableFieldId\":null,\"format\":\"255\"},{\"id\":\"384238649157361759\",\"name\":\"负责人\",\"internalKey\":\"contactOwner\",\"pos\":4,\"type\":\"MEMBER\",\"mobile\":true,\"showLabel\":true,\"placeholder\":\"\",\"description\":null,\"readable\":true,\"editable\":true,\"fieldWidth\":1.0,\"rules\":[{\"key\":\"required\"}],\"showControlRules\":null,\"businessKey\":\"owner\",\"disabledProps\":[\"readable\",\"mobile\",\"rules.required\"],\"resourceFieldId\":null,\"subTableFieldId\":null,\"defaultValue\":null,\"hasCurrentUser\":true,\"initialOptions\":[]}],\"formProp\":{\"viewSize\":\"small\",\"layout\":1,\"labelPos\":\"top\",\"inputWidth\":\"custom\",\"optBtnPos\":\"flex-row\",\"optBtnContent\":[{\"text\":\"保存\",\"enable\":true},{\"text\":\"保存并继续添加\",\"enable\":false},{\"text\":\"取消\",\"enable\":true}],\"linkProp\":{\"clue-CLUE_TO_CONTACT\":[{\"current\":\"384238649157361756\",\"link\":\"384238649157361748\",\"enable\":true},{\"current\":\"384238649157361758\",\"link\":\"384238649157361749\",\"enable\":true}]}}}');
/*!40000 ALTER TABLE `sys_operation_log_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_organization`
--

DROP TABLE IF EXISTS `sys_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_organization` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='组织架构';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_organization`
--

LOCK TABLES `sys_organization` WRITE;
/*!40000 ALTER TABLE `sys_organization` DISABLE KEYS */;
INSERT INTO `sys_organization` VALUES ('100001','default',1736152274610,1736152274610,'admin','admin');
/*!40000 ALTER TABLE `sys_organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_organization_config`
--

DROP TABLE IF EXISTS `sys_organization_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_organization_config` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置类型',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '企业id',
  `sync` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否同步（只对同步企业生效）',
  `sync_resource` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '同步来源',
  `enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否开启',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_organizationId` (`organization_id`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='企业设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_organization_config`
--

LOCK TABLES `sys_organization_config` WRITE;
/*!40000 ALTER TABLE `sys_organization_config` DISABLE KEYS */;
INSERT INTO `sys_organization_config` VALUES ('384244413003472896','THIRD','100001',_binary '\0','WECOM',_binary '\0',1780392737646,1780392737646,'admin','admin');
/*!40000 ALTER TABLE `sys_organization_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_organization_config_detail`
--

DROP TABLE IF EXISTS `sys_organization_config_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_organization_config_detail` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `config_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置id',
  `type` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置内容类型',
  `enable` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否启用',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NONE' COMMENT '配置名称',
  `content` blob NOT NULL COMMENT '配置内容',
  `description` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '描述',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_config_id` (`config_id`),
  KEY `idx_type` (`type`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='企业设置详情表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_organization_config_detail`
--

LOCK TABLES `sys_organization_config_detail` WRITE;
/*!40000 ALTER TABLE `sys_organization_config_detail` DISABLE KEYS */;
INSERT INTO `sys_organization_config_detail` VALUES ('384244413003472897','384244413003472896','TENDER',_binary '','三方设置',_binary 'PK\0\0�\�\\\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0zip�Q\n� \0л�\�h�BDG��rS6,�{\�PY�m\'2v�\0�\�\��\"E]��\�Η\�\�\��\�\�\�$Ma�\�&\�P�\�\�PK��*J\0\0\0L\0\0\0',NULL,1780392737651,1780392737651,'admin','admin');
/*!40000 ALTER TABLE `sys_organization_config_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_organization_user`
--

DROP TABLE IF EXISTS `sys_organization_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_organization_user` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `department_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '部门id',
  `resource_user_id` varchar(64) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '三方唯一id',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户id',
  `enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否启用',
  `employee_id` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '工号',
  `position` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '职位',
  `employee_type` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '员工类型',
  `supervisor_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '直属上级',
  `work_city` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '' COMMENT '工作城市',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `onboarding_date` bigint DEFAULT NULL COMMENT '入职时间',
  PRIMARY KEY (`id`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_department_id` (`department_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='组织成员';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_organization_user`
--

LOCK TABLES `sys_organization_user` WRITE;
/*!40000 ALTER TABLE `sys_organization_user` DISABLE KEYS */;
INSERT INTO `sys_organization_user` VALUES ('384244868270006273','100001','384244601982033920',NULL,'384244868270006272',_binary '','1','总经理','',NULL,NULL,1780392790935,1780392790935,'admin','admin',NULL),('384244868270006275','100001','384244722241118208',NULL,'384244868270006274',_binary '','2','副总经理','','384244868270006272',NULL,1780392790935,1780463008982,'admin','admin',NULL),('384244868270006277','100001','384244782370660352',NULL,'384244868270006276',_binary '','3','销售经理','','384244868270006272',NULL,1780392790935,1780463018042,'admin','admin',NULL),('384244868270006279','100001','384244722241118208',NULL,'384244868270006278',_binary '','4','业务员','','384244868270006274',NULL,1780392790935,1780461314414,'admin','admin',NULL),('384244868270006281','100001','384244722241118208',NULL,'384244868270006280',_binary '','5','业务员','','384244868270006274',NULL,1780392790935,1780461302942,'admin','admin',NULL),('384244868270006283','100001','384244782370660352',NULL,'384244868270006282',_binary '','6','业务员','',NULL,NULL,1780392790935,1780392790935,'admin','admin',NULL),('384244868270006285','100001','384244782370660352',NULL,'384244868270006284',_binary '','7','业务员','',NULL,NULL,1780392790935,1780392790935,'admin','admin',NULL);
/*!40000 ALTER TABLE `sys_organization_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_parameter`
--

DROP TABLE IF EXISTS `sys_parameter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_parameter` (
  `param_key` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'key',
  `param_value` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'value',
  `type` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'text' COMMENT 'type',
  PRIMARY KEY (`param_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统参数';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_parameter`
--

LOCK TABLES `sys_parameter` WRITE;
/*!40000 ALTER TABLE `sys_parameter` DISABLE KEYS */;
INSERT INTO `sys_parameter` VALUES ('advance.search.setting','false','text'),('delete.extra.modules','done','text'),('handler.contract.approval.status','done','text'),('handler.contract.invoice.approval.status','done','text'),('handler.order.approval.status','done','text'),('handler.quotation.approval.status','done','text'),('init.contact.form.link.rules','done','text'),('init.ext.fields.v1.5.0','done','text'),('init.ext.fields.v1.5.1','done','text'),('init.form','done','text'),('init.invoice.form.scenario','done','text'),('init.invoice.show.fields','done','text'),('init.module','done','text'),('init.order.fields','done','text'),('init.order.form.link.rules','done','text'),('init.order.form.scenario','done','text'),('init.record.form.scenario','done','text'),('init.upgrade.form.v1.4.0','done','text'),('init.upgrade.form.v1.5.0','done','text'),('init.upgrade.form.v1.5.1','done','text'),('init.upgrade.form.v1.6.0','done','text'),('modify.field.mobile','done','text'),('modify.form.date','done','text'),('modify.form.link','done','text'),('modify.form.prop','done','text'),('modify.internal.calc.formula','done','text'),('modify.internal.sum.column','done','text'),('modify.quotation.product.sum.column','done','text'),('process.old.link.data','done','text'),('process.transferred.clue','done','text'),('refresh.formula.old.referenced.id','done','text'),('refresh.plan.field.pos','done','text'),('set.default.option.source','done','text'),('welltrans.api.key','9f82d71e6c4b0a3596fc27d904be58ac7d2f691e8350cb62954e1df37825f1c','text'),('welltrans.api.url','https://welltrans-logistics.com/crm/api/crm_push_emails.php','text'),('welltrans.auto.push.enabled','true','text'),('welltrans.manual.push.enabled','true','text');
/*!40000 ALTER TABLE `sys_parameter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色名称',
  `internal` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否是内置角色',
  `data_scope` varchar(30) COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据范围（全部数据权限/指定部门权限/本部门数据权限/本部门及以下数据权限/仅本人数据）',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `description` varchar(1000) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '描述',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES ('org_admin','org_admin',_binary '','ALL',1780392056000,1780392056000,'admin','admin','','100001'),('sales_manager','sales_manager',_binary '','DEPT_AND_CHILD',1780392056001,1780392056001,'admin','admin','','100001'),('sales_staff','sales_staff',_binary '','SELF',1780392056002,1780392056002,'admin','admin','','100001');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_permission`
--

DROP TABLE IF EXISTS `sys_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_permission` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `role_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色id',
  `permission_id` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '权限id',
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='角色权限';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_permission`
--

LOCK TABLES `sys_role_permission` WRITE;
/*!40000 ALTER TABLE `sys_role_permission` DISABLE KEYS */;
INSERT INTO `sys_role_permission` VALUES ('101927171227910414','org_admin','OPPORTUNITY_MANAGEMENT:RESIGN'),('101927171227910415','org_admin','CUSTOMER_MANAGEMENT:EXPORT'),('101927171227910416','org_admin','OPPORTUNITY_MANAGEMENT:EXPORT'),('101927171227910417','org_admin','CLUE_MANAGEMENT:EXPORT'),('101927171227910418','sales_manager','CUSTOMER_MANAGEMENT:EXPORT'),('101927171227910419','sales_manager','OPPORTUNITY_MANAGEMENT:EXPORT'),('101927171227910420','sales_manager','CLUE_MANAGEMENT:EXPORT'),('101927171227910422','sales_staff','OPPORTUNITY_MANAGEMENT:EXPORT'),('101927171227910423','sales_staff','CLUE_MANAGEMENT:EXPORT'),('101927171227910426','org_admin','DASHBOARD:READ'),('101927171227910427','org_admin','DASHBOARD:ADD'),('101927171227910428','org_admin','DASHBOARD:UPDATE'),('101927171227910429','org_admin','DASHBOARD:DELETE'),('101927171227910430','org_admin','LICENSE:READ'),('101927171227910431','org_admin','LICENSE:EDIT'),('101927171227910437','org_admin','CLUE_MANAGEMENT:IMPORT'),('101927171227910438','sales_staff','CUSTOMER_MANAGEMENT_POOL:EXPORT'),('101927171227910439','sales_manager','CUSTOMER_MANAGEMENT_POOL:EXPORT'),('101927171227910440','org_admin','CUSTOMER_MANAGEMENT_POOL:EXPORT'),('101927171227910441','sales_staff','CLUE_MANAGEMENT_POOL:EXPORT'),('101927171227910442','sales_manager','CLUE_MANAGEMENT_POOL:EXPORT'),('101927171227910443','org_admin','CLUE_MANAGEMENT_POOL:EXPORT'),('101927171227910444','sales_staff','CUSTOMER_MANAGEMENT_CONTACT:EXPORT'),('101927171227910445','sales_manager','CUSTOMER_MANAGEMENT_CONTACT:EXPORT'),('101927171227910446','org_admin','CUSTOMER_MANAGEMENT_CONTACT:EXPORT'),('101927171227910450','org_admin','CUSTOMER_MANAGEMENT:IMPORT'),('101927171227910451','org_admin','CUSTOMER_MANAGEMENT_CONTACT:IMPORT'),('101927171227910452','org_admin','OPPORTUNITY_MANAGEMENT:IMPORT'),('101927171227910453','org_admin','PERSONAL_API_KEY:READ'),('101927171227910454','org_admin','PERSONAL_API_KEY:ADD'),('101927171227910455','org_admin','PERSONAL_API_KEY:UPDATE'),('101927171227910456','org_admin','PERSONAL_API_KEY:DELETE'),('101927171227910459','org_admin','AGENT:READ'),('101927171227910460','org_admin','AGENT:ADD'),('101927171227910461','org_admin','AGENT:UPDATE'),('101927171227910462','org_admin','AGENT:DELETE'),('101927171227910463','org_admin','PRODUCT_MANAGEMENT:IMPORT'),('101927171227910470','org_admin','CUSTOMER_MANAGEMENT_POOL:UPDATE'),('101927171227910471','org_admin','CLUE_MANAGEMENT_POOL:UPDATE'),('101927171227910473','org_admin','CUSTOMER_MANAGEMENT:MERGE'),('101927171227910474','org_admin','CUSTOMER_MANAGEMENT:TRANSFER'),('101927171227910475','org_admin','OPPORTUNITY_MANAGEMENT:TRANSFER'),('101927171227910476','org_admin','CLUE_MANAGEMENT:TRANSFER'),('101927171227910477','sales_manager','CUSTOMER_MANAGEMENT:TRANSFER'),('101927171227910478','sales_manager','OPPORTUNITY_MANAGEMENT:TRANSFER'),('101927171227910479','sales_manager','CLUE_MANAGEMENT:TRANSFER'),('101927171227910480','sales_staff','CUSTOMER_MANAGEMENT:TRANSFER'),('101927171227910481','sales_staff','OPPORTUNITY_MANAGEMENT:TRANSFER'),('101927171227910482','sales_staff','CLUE_MANAGEMENT:TRANSFER'),('101927171227910487','org_admin','OPPORTUNITY_QUOTATION:READ'),('101927171227910488','org_admin','OPPORTUNITY_QUOTATION:ADD'),('101927171227910489','org_admin','OPPORTUNITY_QUOTATION:UPDATE'),('101927171227910490','org_admin','OPPORTUNITY_QUOTATION:DELETE'),('101927171227910491','org_admin','OPPORTUNITY_QUOTATION:DOWNLOAD'),('101927171227910492','org_admin','OPPORTUNITY_QUOTATION:APPROVAL'),('101927171227910493','org_admin','OPPORTUNITY_QUOTATION:VOIDED'),('101927171227910494','org_admin','TENDER:READ'),('101927171227910495','sales_manager','OPPORTUNITY_QUOTATION:READ'),('101927171227910496','sales_manager','OPPORTUNITY_QUOTATION:ADD'),('101927171227910497','sales_manager','OPPORTUNITY_QUOTATION:UPDATE'),('101927171227910498','sales_manager','OPPORTUNITY_QUOTATION:DOWNLOAD'),('101927171227910499','org_admin','OPPORTUNITY_QUOTATION:APPROVAL'),('101927171227910500','sales_manager','OPPORTUNITY_QUOTATION:VOIDED'),('101927171227910501','sales_manager','TENDER:READ'),('101927171227910502','sales_staff','OPPORTUNITY_QUOTATION:READ'),('101927171227910503','sales_staff','OPPORTUNITY_QUOTATION:ADD'),('101927171227910504','sales_staff','OPPORTUNITY_QUOTATION:UPDATE'),('101927171227910505','sales_staff','OPPORTUNITY_QUOTATION:DOWNLOAD'),('101927171227910506','sales_staff','OPPORTUNITY_QUOTATION:VOIDED'),('101927171227910507','sales_staff','TENDER:READ'),('101927171227910508','org_admin','PRICE:READ'),('101927171227910509','org_admin','PRICE:ADD'),('101927171227910510','org_admin','PRICE:UPDATE'),('101927171227910511','org_admin','PRICE:DELETE'),('101927171227910512','org_admin','PRICE:IMPORT'),('101927171227910513','org_admin','PRICE:EXPORT'),('101927171227910514','org_admin','CONTRACT:READ'),('101927171227910515','org_admin','CONTRACT:ADD'),('101927171227910516','org_admin','CONTRACT:UPDATE'),('101927171227910517','org_admin','CONTRACT:EXPORT'),('101927171227910520','org_admin','CONTRACT:APPROVAL'),('101927171227910521','sales_manager','CONTRACT:READ'),('101927171227910522','sales_manager','CONTRACT:ADD'),('101927171227910523','sales_manager','CONTRACT:UPDATE'),('101927171227910524','sales_manager','CONTRACT:EXPORT'),('101927171227910526','sales_manager','CONTRACT:APPROVAL'),('101927171227910527','sales_staff','CONTRACT:READ'),('101927171227910528','sales_staff','CONTRACT:ADD'),('101927171227910529','sales_staff','CONTRACT:UPDATE'),('101927171227910530','sales_staff','CONTRACT:EXPORT'),('101927171227910532','org_admin','CONTRACT_PAYMENT_PLAN:READ'),('101927171227910533','org_admin','CONTRACT_PAYMENT_PLAN:ADD'),('101927171227910534','org_admin','CONTRACT_PAYMENT_PLAN:UPDATE'),('101927171227910535','org_admin','CONTRACT_PAYMENT_PLAN:DELETE'),('101927171227910536','org_admin','CONTRACT_PAYMENT_PLAN:EXPORT'),('101927171227910537','sales_manager','CONTRACT_PAYMENT_PLAN:READ'),('101927171227910538','sales_manager','CONTRACT_PAYMENT_PLAN:ADD'),('101927171227910539','sales_manager','CONTRACT_PAYMENT_PLAN:UPDATE'),('101927171227910540','sales_manager','CONTRACT_PAYMENT_PLAN:EXPORT'),('101927171227910541','sales_staff','CONTRACT_PAYMENT_PLAN:READ'),('101927171227910542','sales_staff','CONTRACT_PAYMENT_PLAN:ADD'),('101927171227910543','sales_staff','CONTRACT_PAYMENT_PLAN:UPDATE'),('101927171227910544','sales_staff','CONTRACT_PAYMENT_PLAN:EXPORT'),('101927171227910545','org_admin','CONTRACT:STAGE'),('101927171227910546','org_admin','CONTRACT:DELETE'),('101927171227910572','org_admin','CONTRACT_PAYMENT_RECORD:READ'),('101927171227910573','org_admin','CONTRACT_PAYMENT_RECORD:ADD'),('101927171227910574','org_admin','CONTRACT_PAYMENT_RECORD:UPDATE'),('101927171227910575','org_admin','CONTRACT_PAYMENT_RECORD:DELETE'),('101927171227910576','org_admin','CONTRACT_PAYMENT_RECORD:IMPORT'),('101927171227910577','org_admin','CONTRACT_PAYMENT_RECORD:EXPORT'),('101927171227910578','org_admin','CONTRACT_BUSINESS_TITLE:READ'),('101927171227910579','org_admin','CONTRACT_BUSINESS_TITLE:ADD'),('101927171227910580','org_admin','CONTRACT_BUSINESS_TITLE:UPDATE'),('101927171227910581','org_admin','CONTRACT_BUSINESS_TITLE:DELETE'),('101927171227910582','org_admin','CONTRACT_BUSINESS_TITLE:EXPORT'),('101927171227910583','org_admin','CONTRACT_BUSINESS_TITLE:IMPORT'),('101927171227910584','sales_manager','CONTRACT_PAYMENT_RECORD:READ'),('101927171227910585','sales_manager','CONTRACT_PAYMENT_RECORD:ADD'),('101927171227910586','sales_manager','CONTRACT_PAYMENT_RECORD:UPDATE'),('101927171227910587','sales_manager','CONTRACT_PAYMENT_RECORD:IMPORT'),('101927171227910588','sales_manager','CONTRACT_PAYMENT_RECORD:EXPORT'),('101927171227910589','sales_manager','CONTRACT_BUSINESS_TITLE:READ'),('101927171227910590','sales_manager','CONTRACT_BUSINESS_TITLE:ADD'),('101927171227910591','sales_manager','CONTRACT_BUSINESS_TITLE:UPDATE'),('101927171227910592','sales_staff','CONTRACT_PAYMENT_RECORD:READ'),('101927171227910593','sales_staff','CONTRACT_PAYMENT_RECORD:ADD'),('101927171227910594','sales_staff','CONTRACT_PAYMENT_RECORD:UPDATE'),('101927171227910595','sales_staff','CONTRACT_PAYMENT_RECORD:IMPORT'),('101927171227910596','sales_staff','CONTRACT_PAYMENT_RECORD:EXPORT'),('101927171227910597','sales_staff','CONTRACT_BUSINESS_TITLE:READ'),('101927171227910598','sales_staff','CONTRACT_BUSINESS_TITLE:ADD'),('101927171227910599','sales_staff','CONTRACT_BUSINESS_TITLE:UPDATE'),('101927171227910600','org_admin','CONTRACT_INVOICE:READ'),('101927171227910601','org_admin','CONTRACT_INVOICE:ADD'),('101927171227910602','org_admin','CONTRACT_INVOICE:UPDATE'),('101927171227910603','org_admin','CONTRACT_INVOICE:DELETE'),('101927171227910604','org_admin','CONTRACT_INVOICE:EXPORT'),('101927171227910605','org_admin','CONTRACT_INVOICE:APPROVAL'),('101927171227910606','sales_manager','CONTRACT_INVOICE:READ'),('101927171227910607','sales_manager','CONTRACT_INVOICE:ADD'),('101927171227910608','sales_manager','CONTRACT_INVOICE:UPDATE'),('101927171227910609','sales_manager','CONTRACT_INVOICE:DELETE'),('101927171227910610','sales_manager','CONTRACT_INVOICE:EXPORT'),('101927171227910611','sales_staff','CONTRACT_INVOICE:READ'),('101927171227910612','sales_staff','CONTRACT_INVOICE:ADD'),('101927171227910613','sales_staff','CONTRACT_INVOICE:UPDATE'),('101927171227910614','sales_staff','CONTRACT_INVOICE:EXPORT'),('101927171227910615','org_admin','CONTRACT:PAYMENT'),('101927171227910616','sales_manager','CONTRACT:PAYMENT'),('101927171227910617','sales_staff','CONTRACT:PAYMENT'),('101927171227910623','org_admin','ORDER:READ'),('101927171227910624','org_admin','ORDER:ADD'),('101927171227910625','org_admin','ORDER:UPDATE'),('101927171227910626','org_admin','ORDER:DELETE'),('101927171227910627','org_admin','ORDER:DOWNLOAD'),('101927171227910628','sales_manager','ORDER:READ'),('101927171227910629','sales_manager','ORDER:ADD'),('101927171227910630','sales_manager','ORDER:UPDATE'),('101927171227910631','sales_manager','ORDER:DOWNLOAD'),('101927171227910632','sales_staff','ORDER:READ'),('101927171227910633','sales_staff','ORDER:ADD'),('101927171227910634','sales_staff','ORDER:UPDATE'),('101927171227910635','sales_staff','ORDER:DOWNLOAD'),('101927171227910644','org_admin','PROCESS_SETTING:READ'),('101927171227910645','org_admin','PROCESS_SETTING:ADD'),('101927171227910646','org_admin','PROCESS_SETTING:UPDATE'),('101927171227910647','org_admin','PROCESS_SETTING:DELETE'),('1076902920142848','org_admin','SYS_ORGANIZATION:READ'),('1076902920142849','org_admin','SYS_ORGANIZATION:ADD'),('1076902920142850','org_admin','SYS_ORGANIZATION:UPDATE'),('1076902920142851','org_admin','SYS_ORGANIZATION:DELETE'),('1076902920142852','org_admin','SYS_ORGANIZATION:IMPORT'),('1076902920142853','org_admin','SYS_ORGANIZATION:SYNC'),('1076902920142854','org_admin','SYS_ORGANIZATION_USER:RESET_PASSWORD'),('1076902920142855','org_admin','SYSTEM_ROLE:READ'),('1076902920142856','org_admin','SYSTEM_ROLE:ADD'),('1076902920142857','org_admin','SYSTEM_ROLE:UPDATE'),('1076902920142858','org_admin','SYSTEM_ROLE:DELETE'),('1076902920142859','org_admin','SYSTEM_ROLE:ADD_USER'),('1076902920142860','org_admin','SYSTEM_ROLE:REMOVE_USER'),('1076902920142861','org_admin','MODULE_SETTING:READ'),('1076902920142862','org_admin','MODULE_SETTING:UPDATE'),('1076902920142863','org_admin','SYSTEM_NOTICE:READ'),('1076902920142864','org_admin','SYSTEM_NOTICE:ADD'),('1076902920142865','org_admin','SYSTEM_NOTICE:UPDATE'),('1076902920142866','org_admin','SYSTEM_NOTICE:DELETE'),('1076902920142867','org_admin','SYSTEM_SETTING:READ'),('1076902920142868','org_admin','SYSTEM_SETTING:UPDATE'),('1076902920142869','org_admin','CUSTOMER_MANAGEMENT:READ'),('1076902920142870','org_admin','CUSTOMER_MANAGEMENT:ADD'),('1076902920142871','org_admin','CUSTOMER_MANAGEMENT:UPDATE'),('1076902920142872','org_admin','CUSTOMER_MANAGEMENT:RECYCLE'),('1076902920142873','org_admin','CUSTOMER_MANAGEMENT:DELETE'),('1076902920142874','org_admin','CUSTOMER_MANAGEMENT_POOL:READ'),('1076902920142875','org_admin','CUSTOMER_MANAGEMENT_POOL:PICK'),('1076902920142876','org_admin','CUSTOMER_MANAGEMENT_POOL:ASSIGN'),('1076902920142877','org_admin','CUSTOMER_MANAGEMENT_POOL:DELETE'),('1076902920142878','org_admin','CUSTOMER_MANAGEMENT_CONTACT:READ'),('1076902920142879','org_admin','CUSTOMER_MANAGEMENT_CONTACT:ADD'),('1076902920142880','org_admin','CUSTOMER_MANAGEMENT_CONTACT:UPDATE'),('1076902920142881','org_admin','CUSTOMER_MANAGEMENT_CONTACT:DELETE'),('1076902920142882','org_admin','CLUE_MANAGEMENT:READ'),('1076902920142883','org_admin','CLUE_MANAGEMENT:ADD'),('1076902920142884','org_admin','CLUE_MANAGEMENT:UPDATE'),('1076902920142885','org_admin','CLUE_MANAGEMENT:RECYCLE'),('1076902920142886','org_admin','CLUE_MANAGEMENT:DELETE'),('1076902920142887','org_admin','CLUE_MANAGEMENT_POOL:READ'),('1076902920142888','org_admin','CLUE_MANAGEMENT_POOL:PICK'),('1076902920142889','org_admin','CLUE_MANAGEMENT_POOL:ASSIGN'),('1076902920142890','org_admin','CLUE_MANAGEMENT_POOL:DELETE'),('1076902920142891','org_admin','OPPORTUNITY_MANAGEMENT:READ'),('1076902920142892','org_admin','OPPORTUNITY_MANAGEMENT:ADD'),('1076902920142893','org_admin','OPPORTUNITY_MANAGEMENT:UPDATE'),('1076902920142894','org_admin','OPPORTUNITY_MANAGEMENT:DELETE'),('1076902920142895','org_admin','PRODUCT_MANAGEMENT:READ'),('1076902920142896','org_admin','PRODUCT_MANAGEMENT:ADD'),('1076902920142897','org_admin','PRODUCT_MANAGEMENT:UPDATE'),('1076902920142898','org_admin','PRODUCT_MANAGEMENT:DELETE'),('1076902920142899','org_admin','OPERATION_LOG:READ'),('1076902920142900','org_admin','SYSTEM_SETTING:ADD'),('1076902920142901','org_admin','SYSTEM_SETTING:DELETE'),('1117962807492608','sales_staff','CUSTOMER_MANAGEMENT:READ'),('1117962807492609','sales_staff','CUSTOMER_MANAGEMENT:ADD'),('1117962807492610','sales_staff','CUSTOMER_MANAGEMENT:UPDATE'),('1117962807492611','sales_staff','CUSTOMER_MANAGEMENT:RECYCLE'),('1117962807492612','sales_staff','CUSTOMER_MANAGEMENT_POOL:READ'),('1117962807492613','sales_staff','CUSTOMER_MANAGEMENT_POOL:PICK'),('1117962807492614','sales_staff','CUSTOMER_MANAGEMENT_CONTACT:READ'),('1117962807492615','sales_staff','CUSTOMER_MANAGEMENT_CONTACT:ADD'),('1117962807492616','sales_staff','CUSTOMER_MANAGEMENT_CONTACT:UPDATE'),('1117962807492617','sales_staff','CLUE_MANAGEMENT:READ'),('1117962807492618','sales_staff','CLUE_MANAGEMENT:ADD'),('1117962807492619','sales_staff','CLUE_MANAGEMENT:UPDATE'),('1117962807492620','sales_staff','CUSTOMER_MANAGEMENT:RECYCLE'),('1117962807492621','sales_staff','CLUE_MANAGEMENT_POOL:READ'),('1117962807492622','sales_staff','CLUE_MANAGEMENT_POOL:PICK'),('1117962807492623','sales_staff','OPPORTUNITY_MANAGEMENT:READ'),('1117962807492624','sales_staff','OPPORTUNITY_MANAGEMENT:ADD'),('1117962807492625','sales_staff','OPPORTUNITY_MANAGEMENT:UPDATE'),('1117962807492626','sales_staff','CLUE_MANAGEMENT:RECYCLE'),('1117962807492627','sales_staff','CUSTOMER_MANAGEMENT:EXPORT'),('1120642867085312','sales_manager','CUSTOMER_MANAGEMENT:READ'),('1120642867085313','sales_manager','CUSTOMER_MANAGEMENT:ADD'),('1120642867085314','sales_manager','CUSTOMER_MANAGEMENT:UPDATE'),('1120642867085315','sales_manager','CUSTOMER_MANAGEMENT:RECYCLE'),('1120642867085316','sales_manager','CUSTOMER_MANAGEMENT_POOL:READ'),('1120642867085317','sales_manager','CUSTOMER_MANAGEMENT_POOL:PICK'),('1120660046954496','sales_manager','CUSTOMER_MANAGEMENT_CONTACT:READ'),('1120660046954497','sales_manager','CUSTOMER_MANAGEMENT_CONTACT:ADD'),('1120660046954498','sales_manager','CUSTOMER_MANAGEMENT_CONTACT:UPDATE'),('1120660046954499','sales_manager','CLUE_MANAGEMENT:READ'),('1120660046954500','sales_manager','CLUE_MANAGEMENT:ADD'),('1120660046954501','sales_manager','CLUE_MANAGEMENT:UPDATE'),('1120660046954502','sales_manager','CUSTOMER_MANAGEMENT:RECYCLE'),('1120660046954503','sales_manager','CLUE_MANAGEMENT_POOL:READ'),('1120660046954504','sales_manager','CLUE_MANAGEMENT_POOL:PICK'),('1120660046954505','sales_manager','OPPORTUNITY_MANAGEMENT:READ'),('1120660046954506','sales_manager','OPPORTUNITY_MANAGEMENT:ADD'),('1120660046954507','sales_manager','OPPORTUNITY_MANAGEMENT:UPDATE'),('1120660046954508','sales_manager','CLUE_MANAGEMENT:RECYCLE');
/*!40000 ALTER TABLE `sys_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_scope_dept`
--

DROP TABLE IF EXISTS `sys_role_scope_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_role_scope_dept` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'ID',
  `role_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色ID',
  `department_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '部门ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='角色与部门的关联表，角色 data_scope 为指定部门时使用';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_scope_dept`
--

LOCK TABLES `sys_role_scope_dept` WRITE;
/*!40000 ALTER TABLE `sys_role_scope_dept` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_role_scope_dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_search_field_mask_config`
--

DROP TABLE IF EXISTS `sys_search_field_mask_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_search_field_mask_config` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '搜索字段id',
  `type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '类型',
  `business_key` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '业务字段key',
  `data_source_type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '数据源对应类型',
  `module_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '搜索模块(customer/lead/等)',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_module_type` (`module_type`),
  KEY `idx_organization_id` (`organization_id`),
  KEY `idx_field_id` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='搜索字段脱敏配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_search_field_mask_config`
--

LOCK TABLES `sys_search_field_mask_config` WRITE;
/*!40000 ALTER TABLE `sys_search_field_mask_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_search_field_mask_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_ui_settings`
--

DROP TABLE IF EXISTS `sys_ui_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_ui_settings` (
  `param_key` varchar(100) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'key',
  `param_value` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'value',
  `type` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'text' COMMENT 'type',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织ID',
  PRIMARY KEY (`param_key`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='界面设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_ui_settings`
--

LOCK TABLES `sys_ui_settings` WRITE;
/*!40000 ALTER TABLE `sys_ui_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_ui_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '名称',
  `phone` varchar(11) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '手机号',
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '邮箱',
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '密码',
  `language` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '语言',
  `last_organization_id` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '当前组织ID',
  `gender` bit(1) NOT NULL DEFAULT b'0' COMMENT '性别(0-男/1-女)',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_email` (`email` DESC),
  KEY `idx_create_time` (`create_time` DESC),
  KEY `idx_update_time` (`update_time`),
  KEY `idx_create_user` (`create_user`),
  KEY `idx_update_user` (`update_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户(员工)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES ('384244868270006272','Simon','13544411111','overseas.09@basenton.com','248a90ab746c05937cd0f8aaecbe7d64','zh_CN','100001',_binary '\0',1780392790935,1780392790935,'admin','admin'),('384244868270006274','Kevin','13888888888','overseas.08@basenton.com','21218cca77804d2ba1922c33e0151105','zh_CN','100001',_binary '\0',1780392790935,1780463008983,'admin','admin'),('384244868270006276','Betty','13888888881','overseas.01@basenton.com','930b7b631da8592e361bdb60b97a0580','zh_CN','100001',_binary '',1780392790935,1780463018043,'admin','admin'),('384244868270006278','Tina','13999999999','overseas.86@basenton.com','52c69e3a57331081823331c4e69d3f2e','zh_CN','100001',_binary '',1780392790935,1780461314415,'admin','admin'),('384244868270006280','Yundy','13999999991','Overseas.48@basenton.com','0ef26b9d4469882962b1bd35ef7556f4','zh_CN','100001',_binary '',1780392790935,1780461302944,'admin','admin'),('384244868270006282','Cyan','13999999910','Overseas.50@basenton.com','3138288551759ccc0fb1b7a187610739','zh_CN','100001',_binary '',1780392790935,1780392790935,'admin','admin'),('384244868270006284','Anya','13999999911','Overseas.51@basenton.com','219d70085bcf1f2ebf48532fd5c3ae89','zh_CN','100001',_binary '',1780392790935,1780392790935,'admin','admin'),('admin','Administrator','4000520755','admin@cordys-crm.io','4706261da78b85ec9553be61a15f924c','zh_CN','100001',_binary '',1716175907000,1729752373360,'717345437786112','admin');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_extend`
--

DROP TABLE IF EXISTS `sys_user_extend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_extend` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户id',
  `avatar` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '头像内容',
  `platform_info` longblob COMMENT '对接平台信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户扩展内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_extend`
--

LOCK TABLES `sys_user_extend` WRITE;
/*!40000 ALTER TABLE `sys_user_extend` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_extend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_role`
--

DROP TABLE IF EXISTS `sys_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_role` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `role_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '角色id',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_role_id` (`role_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户关联角色';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_role`
--

LOCK TABLES `sys_user_role` WRITE;
/*!40000 ALTER TABLE `sys_user_role` DISABLE KEYS */;
INSERT INTO `sys_user_role` VALUES ('384825668107509760','org_admin','384244868270006272',1780460404100,1780460404100,'admin','admin'),('384825848496136193','sales_staff','384244868270006282',1780460425283,1780460425283,'admin','admin'),('384825848496136194','sales_staff','384244868270006284',1780460425283,1780460425283,'admin','admin'),('384833381868773376','sales_staff','384244868270006280',1780461302947,1780461302947,'admin','admin'),('384833484947988480','sales_staff','384244868270006278',1780461314417,1780461314417,'admin','admin'),('384848036297187329','sales_manager','384244868270006274',1780463008984,1780463008984,'admin','admin'),('384848122196533248','sales_manager','384244868270006276',1780463018044,1780463018044,'admin','admin');
/*!40000 ALTER TABLE `sys_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_search_config`
--

DROP TABLE IF EXISTS `sys_user_search_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_search_config` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `field_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '搜索字段id',
  `type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL COMMENT '字段类型',
  `business_key` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '业务字段key',
  `data_source_type` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '数据源对应类型',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户id',
  `module_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '搜索模块(customer/lead/等)',
  `sort_setting` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '模块顺序设置["customer","clue"]',
  `result_display` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否展示有搜索结果的列表',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `ids_module_type` (`module_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户全局搜索配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_search_config`
--

LOCK TABLES `sys_user_search_config` WRITE;
/*!40000 ALTER TABLE `sys_user_search_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_search_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_view`
--

DROP TABLE IF EXISTS `sys_user_view`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_view` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `user_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '视图名称',
  `fixed` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否固定',
  `resource_type` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '资源类型(客户/线索/商机)',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `pos` bigint NOT NULL COMMENT '排序',
  `enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '状态',
  `search_mode` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'AND' COMMENT '匹配模式(AND/OR)',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_name` (`name`),
  KEY `idx_resource_type` (`resource_type`),
  KEY `idx_organization_id` (`organization_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户视图';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_view`
--

LOCK TABLES `sys_user_view` WRITE;
/*!40000 ALTER TABLE `sys_user_view` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_view` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user_view_condition`
--

DROP TABLE IF EXISTS `sys_user_view_condition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user_view_condition` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `sys_user_view_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '视图id',
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL COMMENT '参数名称',
  `value` text COLLATE utf8mb4_general_ci COMMENT '参数值',
  `value_type` text COLLATE utf8mb4_general_ci COMMENT '参数值类型',
  `type` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '类型',
  `multiple_value` bit(1) NOT NULL DEFAULT b'0' COMMENT '是否是多选值',
  `operator` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '操作符',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  `children_value` text COLLATE utf8mb4_general_ci COMMENT '包含新增子部门集合',
  PRIMARY KEY (`id`),
  KEY `idx_sys_user_view_id` (`sys_user_view_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户视图详情';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user_view_condition`
--

LOCK TABLES `sys_user_view_condition` WRITE;
/*!40000 ALTER TABLE `sys_user_view_condition` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_user_view_condition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_welltrans_push_log`
--

DROP TABLE IF EXISTS `sys_welltrans_push_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_welltrans_push_log` (
  `id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'id',
  `organization_id` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '组织id',
  `trigger_type` varchar(16) COLLATE utf8mb4_general_ci NOT NULL COMMENT '触发类型: AUTO / MANUAL',
  `total_count` int NOT NULL DEFAULT '0' COMMENT '推送总数',
  `success_count` int NOT NULL DEFAULT '0' COMMENT '成功数',
  `fail_count` int NOT NULL DEFAULT '0' COMMENT '失败数',
  `response_body` text COLLATE utf8mb4_general_ci COMMENT 'API响应内容',
  `error_message` text COLLATE utf8mb4_general_ci COMMENT '错误信息',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `update_time` bigint NOT NULL COMMENT '更新时间',
  `create_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '创建人',
  `update_user` varchar(32) COLLATE utf8mb4_general_ci NOT NULL COMMENT '更新人',
  PRIMARY KEY (`id`),
  KEY `idx_org_create_time` (`organization_id`,`create_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_welltrans_push_log`
--

LOCK TABLES `sys_welltrans_push_log` WRITE;
/*!40000 ALTER TABLE `sys_welltrans_push_log` DISABLE KEYS */;
INSERT INTO `sys_welltrans_push_log` VALUES ('385605805967196160','100001','MANUAL',1,0,1,'{\"success\":false,\"totalCount\":1,\"successCount\":0,\"failCount\":1,\"message\":null,\"warnings\":null,\"errorMessage\":\"推送失败: 401 Unauthorized on POST request for \\\"https://welltrans-logistics.com/crm/api/crm_push_emails.php\\\": [no body]\"}','推送失败: 401 Unauthorized on POST request for \"https://welltrans-logistics.com/crm/api/crm_push_emails.php\": [no body]',1780551224636,1780551224636,'admin','admin'),('385609181811490816','100001','MANUAL',1,0,1,'{\"success\":false,\"totalCount\":1,\"successCount\":0,\"failCount\":1,\"message\":null,\"warnings\":null,\"errorMessage\":\"推送失败: 401 Unauthorized on POST request for \\\"https://welltrans-logistics.com/crm/api/crm_push_emails.php\\\": [no body]\"}','推送失败: 401 Unauthorized on POST request for \"https://welltrans-logistics.com/crm/api/crm_push_emails.php\": [no body]',1780551617388,1780551617388,'admin','admin'),('385610822489006080','100001','MANUAL',1,1,0,'{\"success\":true,\"totalCount\":1,\"successCount\":1,\"failCount\":0,\"message\":\"CRM 客户数据接收成功\",\"warnings\":[],\"errorMessage\":null}',NULL,1780551808209,1780551808209,'admin','admin'),('385611140316585984','100001','MANUAL',1,1,0,'{\"success\":true,\"totalCount\":1,\"successCount\":1,\"failCount\":0,\"message\":\"CRM 客户数据接收成功\",\"warnings\":[],\"errorMessage\":null}',NULL,1780551845727,1780551845727,'admin','admin'),('385616835443220480','100001','MANUAL',1,1,0,'{\"success\":true,\"totalCount\":1,\"successCount\":1,\"failCount\":0,\"message\":\"CRM 客户数据接收成功\",\"warnings\":[],\"errorMessage\":null}',NULL,1780552508622,1780552508622,'admin','admin'),('385625090370363392','100001','MANUAL',1,1,0,'{\"success\":true,\"totalCount\":1,\"successCount\":1,\"failCount\":0,\"message\":\"CRM 客户数据接收成功\",\"warnings\":[],\"errorMessage\":null}',NULL,1780553469684,1780553469684,'admin','admin'),('385631111914512384','100001','MANUAL',4,4,0,'{\"success\":true,\"totalCount\":4,\"successCount\":4,\"failCount\":0,\"message\":\"CRM 客户数据接收成功\",\"warnings\":[],\"errorMessage\":null}',NULL,1780554170455,1780554170455,'admin','admin'),('385634084031889408','100001','MANUAL',4,4,0,'{\"success\":true,\"totalCount\":4,\"successCount\":4,\"failCount\":0,\"message\":\"CRM 客户数据接收成功\",\"warnings\":[],\"errorMessage\":null}',NULL,1780554516225,1780554516225,'admin','admin'),('385634350319861760','100001','MANUAL',4,4,0,'{\"success\":true,\"totalCount\":4,\"successCount\":4,\"failCount\":0,\"message\":\"CRM 客户数据接收成功\",\"warnings\":[],\"errorMessage\":null}',NULL,1780554547992,1780554547992,'admin','admin'),('385637743344033792','100001','MANUAL',8,8,0,'{\"success\":true,\"totalCount\":8,\"successCount\":8,\"failCount\":0,\"message\":\"CRM 客户数据接收成功\",\"warnings\":[],\"errorMessage\":null}',NULL,1780554942173,1780554942173,'admin','admin');
/*!40000 ALTER TABLE `sys_welltrans_push_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_key`
--

DROP TABLE IF EXISTS `user_key`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_key` (
  `id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'user_key ID',
  `create_user` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户ID',
  `access_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'access_key',
  `secret_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'secret key',
  `create_time` bigint NOT NULL COMMENT '创建时间',
  `enable` bit(1) NOT NULL DEFAULT b'1' COMMENT '状态',
  `forever` bit(1) NOT NULL DEFAULT b'1' COMMENT '是否永久有效',
  `expire_time` bigint DEFAULT NULL COMMENT '到期时间',
  `description` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ak` (`access_key`),
  KEY `idx_create_user` (`create_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户api key';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_key`
--

LOCK TABLES `user_key` WRITE;
/*!40000 ALTER TABLE `user_key` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_key` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `worker_node`
--

DROP TABLE IF EXISTS `worker_node`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `worker_node` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'auto increment id',
  `host_name` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'host name',
  `port` varchar(64) COLLATE utf8mb4_general_ci NOT NULL COMMENT 'port',
  `type` int NOT NULL COMMENT 'node type: ACTUAL or CONTAINER',
  `launch_date` bigint NOT NULL COMMENT 'launch date',
  `modified` bigint NOT NULL COMMENT 'modified time',
  `created` bigint NOT NULL COMMENT 'created time',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='DB WorkerID Assigner for UID Generator';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `worker_node`
--

LOCK TABLES `worker_node` WRITE;
/*!40000 ALTER TABLE `worker_node` DISABLE KEYS */;
INSERT INTO `worker_node` VALUES (1,'172.18.0.6','1780392062829-2125557356',2,1780392062832,1780392062832,1780392062832),(2,'172.18.0.6','1780392066231-1274906354',2,1780392066231,1780392066231,1780392066231),(3,'172.18.0.7','1780393142312-1662575629',2,1780393142316,1780393142316,1780393142316),(4,'172.18.0.7','1780393145665-1925265875',2,1780393145665,1780393145665,1780393145665),(5,'172.18.0.6','1780548125742-1984236510',2,1780548125745,1780548125745,1780548125745),(6,'172.18.0.6','1780548129562-1543771453',2,1780548129562,1780548129562,1780548129562),(7,'172.18.0.6','1780548363792-1047858452',2,1780548363794,1780548363794,1780548363794),(8,'172.18.0.6','1780548367110-1268626626',2,1780548367110,1780548367110,1780548367110),(9,'172.18.0.6','1780549540930-1601415747',2,1780549540933,1780549540933,1780549540933),(10,'172.18.0.6','1780549544267-314505341',2,1780549544267,1780549544267,1780549544267),(11,'172.18.0.6','1780551146135-375285123',2,1780551146146,1780551146146,1780551146146),(12,'172.18.0.6','1780551149641-765923493',2,1780551149641,1780551149641,1780551149641),(13,'172.18.0.6','1780551702382-424137598',2,1780551702385,1780551702385,1780551702385),(14,'172.18.0.6','1780551705575-54452105',2,1780551705575,1780551705575,1780551705575),(15,'172.18.0.6','1780554495479-1790963255',2,1780554495483,1780554495483,1780554495483),(16,'172.18.0.6','1780554498914-1113995111',2,1780554498914,1780554498914,1780554498914),(17,'172.18.0.6','1780554925224-603894743',2,1780554925228,1780554925228,1780554925228),(18,'172.18.0.6','1780554928758-1570898931',2,1780554928758,1780554928758,1780554928758);
/*!40000 ALTER TABLE `worker_node` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'cordys-crm-1.7.0'
--

--
-- Dumping routines for database 'cordys-crm-1.7.0'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-04  8:23:29
